package main
import (
 "encoding/json"
 "os"
 "github.com/delgado-jacob/spl-toolkit/pkg/analysis"
)
func main() {
 for _, query := range []string{`tstats aggregates=[count()] predicate=(flag=true) byfields=[host]`, `tstats aggregates=[count()] predicate=(flag="true") byfields=[host]`, `FROM main | where flag=true`, `FROM main | where flag="true"`} {
  name := "flag"
  session, err := analysis.PrepareRewrite(analysis.QueryDocument{Language:"spl2", Text:query}, []analysis.RewriteFactProbe{{Kind:"field", Identity:analysis.RewriteIdentity{Name:&name}}})
  if err != nil { panic(err) }
  for _, site := range session.Evidence().Sites {
   if site.Kind=="field" && site.Identity.Name!=nil && *site.Identity.Name==name {
    if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"query":query,"status":session.Evidence().Analysis.Status,"site":site}); err != nil {panic(err)}
   }
  }
 }
}
