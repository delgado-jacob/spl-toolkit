import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path.cwd(); evidence=root/'.superpowers/sdd/milestone-6-implementation-plan/task-2-producer-followup-evidence'
name=sys.argv[1]; command=['/opt/homebrew/Cellar/go/1.25.5/libexec/bin/go']+sys.argv[2:]
envadd={'GOCACHE':'/private/tmp/spl-toolkit-go-cache','GOMODCACHE':'/private/tmp/spl-toolkit-remaining-gomodcache','GOPROXY':'off','GOTOOLCHAIN':'local'}
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files'],text=True).splitlines();paths=[p for p in paths if p.endswith('.go') or p in ['go.mod','go.sum']]
source={p:sha(p) for p in paths}
diff=subprocess.check_output(['git','diff','--binary','0b8dd62068be0638e470a532544acd1cc0a48507','--','pkg/analysis'])
(evidence/(name+'.diff')).write_bytes(diff)
started=time.time();r=subprocess.run(command,env={**os.environ,**envadd},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(evidence/(name+'.stdout')).write_bytes(r.stdout);(evidence/(name+'.stderr')).write_bytes(r.stderr)
receipt={'command':command,'cwd':str(root),'environment':envadd,'observed_exit':r.returncode,'elapsed_seconds':time.time()-started,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'go_binary_sha256':sha(command[0]),'source_sha256':source,'source_unchanged_during_run':source=={p:sha(p) for p in paths},'diff_sha256':hashlib.sha256(diff).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
if command[1]=='run':receipt['probe_sha256']=sha(command[-1])
(evidence/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(r.stdout.decode(errors='replace'),end='');print(r.stderr.decode(errors='replace'),end='');print('OBSERVED_EXIT='+str(r.returncode));sys.exit(r.returncode)
