### Spec Compliance

- ❌ Issues found. The facade and surgical canonical hooks are implemented, but five Important defects violate the original-fact, malformed-Unicode, typed-owner, composite-effect, or source-identity contracts. See I1–I5 below.
- Reviewed immutable BASE `3a29058949b5b0000e4b90d9406764dbe11ce2ee` → HEAD `02c2e3217df6edef01cada136d9e623da0de7a93`, using the complete 3,296-line `review-3a29058..02c2e32.diff` (SHA256 `32e7ecde097af683f1df3fc73a54407b03b2decdd0a8bb674f0b5d9f2b467a30`). All 22 changed paths match the owned source manifest, and their current bytes matched that manifest before and after each focused probe. The supplied coordinator identity reconciliation also matches committed bytes. No Git command was rerun.
- ⚠️ Cannot verify from this diff: text capability and OpenAPI exposure required by `task-2-brief.md:133`. This task changes the analysis manifest only (`pkg/analysis/model.go:128`, `pkg/analysis/capabilities.go:51`, `pkg/analysis/spl2_capabilities.go:15`). The controller should reconcile that exact requirement against the later text formatter and OpenAPI/schema implementation and its evidence; this review does not close that integration obligation.
- ⚠️ Cannot verify from this diff: later whole-request grouping, condition authorization, destination-validation completeness, and apply commit behavior. These remain the consuming tasks' obligations under `task-2-brief.md:93` and `task-2-brief.md:148`. This verdict covers the canonical bridge and does not certify downstream apply behavior.

### Strengths

- The approved facade shapes, private session authority, and copied snapshots are present in `pkg/analysis/rewrite_evidence.go:12–173`. Rendering provenance and exact candidate-document matching are enforced at `pkg/analysis/rewrite_correspondence.go:273–306`; mutable exported snapshots cannot replace the private rendering.
- The byte coordinate helper uses exact ordered lookups in the existing source index, rejects invalid ranges without partial results, and preserves canonical positions (`pkg/analysis/rewrite_evidence.go:298–325`). Focused Unicode, CRLF, tab, EOF, mid-rune, and all-or-error cases are implemented at `pkg/analysis/rewrite_evidence_test.go:96–117`. The read-only `source.go` hash remains the approved `c0421ed1db6a70c689396801a40d515fa2c887f273571cd704baa9af314c628b`.
- Evidence is attached to actual canonical reference/read/create/remove callbacks, with stage and reference finalization hooks rather than a second parser or transfer engine (`pkg/analysis/transfers.go:44–103`, `pkg/analysis/references.go:169–181`, `pkg/analysis/spl2_scopes.go:215–227`). SQL phase tests verify physical SELECT read reuse and later scheduling (`pkg/analysis/rewrite_evidence_test.go:216–237`).
- Exact navigation refusals, explicit alias boundaries, linked SPL implicit consumers, conservative SPL2 implicit-name handling, and lookup `AS` insertion are represented directly (`pkg/analysis/rewrite_render_spl2.go:157–178`, `pkg/analysis/rewrite_correspondence.go:44–92`, `pkg/analysis/rewrite_correspondence.go:151–157`). Their focused tests exercise real analysis and candidate correspondence rather than mocks (`pkg/analysis/rewrite_evidence_test.go:156–194`, `pkg/analysis/rewrite_evidence_test.go:239–275`).
- Correspondence checks references, mapped origins, direct alias bindings, typed owner locations, phases, field state, transitions, scopes, and located diagnostics (`pkg/analysis/rewrite_correspondence.go:310–439`). The durable 19-form corpus exercises the public facade and all six nonfield mapping kinds (`pkg/analysis/rewrite_forms_test.go:11–68`, `testdata/rewrite/forms.json:4–22`). Ordinary Analyze/Evidence JSON parity is checked at `pkg/analysis/rewrite_evidence_test.go:11–26` and `pkg/analysis/rewrite_forms_test.go:32–38`.

### Issues

#### Critical (Must Fix)

- None found in this bounded review.

#### Important (Should Fix)

**I1 — Quoted search wildcard patterns become definite literal facts.**

- Location: `pkg/analysis/rewrite_facts.go:116–130`, `pkg/analysis/rewrite_facts.go:358–373`.
- The quoted-string branch decodes a value without applying the search-pattern restriction used by the unquoted branch. `rewritePredicateFacts` then advertises that decoded pattern as a complete exact literal guarantee. In both SPL and SPL2, `search tag="x*" | lookup people user OUTPUT label` supplies `GuaranteedValues=[{Kind:string, Value:"x*"}]`, `LiteralComplete=true`, and `ReferenceState=true` to the eligible lookup site. The same defect occurs for `search index="main*" ...` with an index probe.
- These are wildcard search predicates, so an equals/contains rule may be authorized from a literal the query does not establish. The postverification gate does not catch the false condition: the probe's people→accounts candidate receives `Verify.Proven=true` in all four cases. The gate correctly checks structural correspondence, but cannot repair an incorrect original guarantee.
- Fix: require the canonical search-value form to prove an exact static literal before publishing equality evidence, including quoted values. Preserve expression-string semantics for contexts where `"x*"` really is a literal, and do not confuse a pattern dependency with an exact source-reference fact. Add field and dependency probes for quoted patterns in both dialects.
- Evidence: `task-2-review-evidence/probe.log:1–2` and `task-2-review-evidence/probe.log:6–7`; source and command identity in `task-2-review-evidence/probe-receipt.json`.

**I2 — Render sanitizes malformed UTF-8 before checking the caller's target.**

- Location: `pkg/analysis/rewrite_correspondence.go:14–25`, with the lossy copy at `pkg/analysis/rewrite_evidence.go:112–116`.
- Render first JSON-copies `changes`, then validates `r.changes`. JSON encoding replaces invalid UTF-8 with U+FFFD, so `rewriteValidIdentity` never sees the malformed original. A target consisting of byte `ff` is accepted with `err=nil`, becomes the logical name U+FFFD, and receives `Verify.Proven=true` in both dialects.
- This violates the explicit request-error requirement (`task-2-brief.md:140`) and changes the requested identity. It is not merely a render refusal or a display issue: the private effect and candidate proof use the substituted identity.
- Fix: validate every original replacement before any potentially normalizing copy, and preserve already-valid identity bytes in the private copy. Add direct facade tests for invalid UTF-8 in target Name and Path values.
- Evidence: `task-2-review-evidence/probe.log:3` and `task-2-review-evidence/probe.log:8`. The additional control-character cases in that log did not expose a defect and are not findings.

**I3 — The null-test role can erase the frontend's unsupported-owner refusal.**

- Location: `pkg/analysis/rewrite_evidence.go:203–205`; the refusal being overwritten is at `pkg/analysis/rewrite_render_spl2.go:41–50`.
- The SPL2 owner walker deliberately clears the role when an enclosing function is unknown or an argument context is unproved. `rewriteReference` then unconditionally replaces that result with `null_test`, removing the only marker used to create `unproved_owner`. In `FROM main | where unknown(isnull(user))=1`, the user operand is consequently eligible even though its owner location is the unknown outer call. Render changes it to account with no requirement limitation, and Verify returns `Proven=true`.
- This defeats the task's conservative unknown-context boundary and the intent of `TestRewriteEvidenceUnknownOwners` (`pkg/analysis/rewrite_evidence_test.go:386–404`). The corresponding SPL probe remains refused; the reproduced defect is SPL2.
- Fix: preserve render-owner proof/refusal independently of the semantic null-test role, or only specialize the role when the frontend owner is already proved. Cover a known null-inspection expression nested under an unknown function and an unmodeled named argument.
- Evidence: `task-2-review-evidence/null-owner-probe.log:2`; SPL refusal control at line 1; command, hashes, and observed exit in `task-2-review-evidence/null-owner-probe-receipt.json`.

**I4 — Model-only edits produce incorrect normalization effects for quoted dataset components.**

- Location: `pkg/analysis/rewrite_correspondence.go:207–231`.
- The enclosing-effect loop starts with the raw dataset token and prepends the selected model name. For `datamodel Traffic 'All'`, Traffic→Network renders the correct `datamodel Network 'All'`, but reports the dataset effect as `Network.'All'` instead of `Network.All`. Double-quoted `"All"` has the same defect. Candidate correspondence consequently fails with `reference_correspondence`, even though the typed component and unchanged quote boundaries are supported.
- This loses the required logical identity of the composite effect and unnecessarily withholds a supported mapping. A located semantic effect must contain decoded identity, not grammar quoting. The durable quoted dataset test currently selects the dataset itself, so it does not cover a model-only normalization effect.
- Fix: derive composite effects from the retained typed/decoded component identity while rendering from the original token. Add model-only edits with single- and double-quoted dataset components, asserting `Network.All` and successful correspondence.
- Evidence: `task-2-review-evidence/composite-epoch-probe.log:1–2`; receipt at `task-2-review-evidence/composite-epoch-probe-receipt.json`. Both documents retain the expected unrelated incomplete datamodel semantics; the reported failure is the incorrect effect, not that incompleteness.

**I5 — Aggregation can invent a new source epoch for an unchanged grouping binding.**

- Location: `pkg/analysis/transfers.go:292–308`, interacting with lazy initialization at `pkg/analysis/rewrite_evidence.go:181–189`.
- Aggregation clones `s.env.rewrite` before reading its grouping operands. When that grouping read is the first evidence-producing read, the clone is nil; the read initializes the input sidecar, then installing the output environment discards it. The subsequent output creation initializes another epoch.
- For valid SPL `stats count BY host | table host`, the grouping host is `SourceEpochID=source-1`, `BindingID=source-1:field:host`; the later passthrough host is `source-2`, `source-2:field:host`. Canonical lineage retains the same `ref-1` origin throughout, and no source reset occurred. The bridge therefore reports two source identities for one binding, undermining the source/flow grouping contract expected by consumers.
- Fix: establish and clone the actual input rewrite state after the grouping reads have contributed their provenance, while keeping output field filtering/invalidation in the canonical aggregation transfer. Add a first-read grouping case that asserts stable SourceEpochID/BindingID and retained supporting references after aggregation.
- Evidence: `task-2-review-evidence/composite-epoch-probe.log:3`, including the exact canonical lineage; source/command receipt in `task-2-review-evidence/composite-epoch-probe-receipt.json`.

#### Minor (Nice to Have)

**M1 — The requested lexical negative-control matrix is incomplete.**

- Location: `pkg/analysis/rewrite_evidence_test.go:78–95`; requirement at `task-2-brief.md:6`.
- The new lexical-control test covers a string value and a same-spelled lookup catalog name, but has no same-text comment or option-value case. Its remote column label is `remote`, so it also does not prove that a same-spelled remote label remains fixed when a different local alias is present. These cases are not present elsewhere in the new tests/corpus.
- Add focused cases for comments, an option value, and a remote column label whose text matches a proposed source mapping. This is a concrete requested coverage gap; no additional runtime defect is inferred from the absence.

### Evidence Checks and Review Boundaries

- **Immutable/source identity:** inspected `task-2-candidate-identity.json`, `task-2-evidence/final-source.json`, and retained `task-2-evidence/final-git.json`. Independently hashed all 22 owned current source files, read-only `source.go`, and the exact Go binary. All matched the recorded identities. Before/after hashes for each probe also matched. The original Git/ancestry/owned-status evidence is retained evidence, not a new live Git check.
- **Retained test evidence:** read the 23 log records and observed exits in `task-2-evidence/runs.json`, inspected their raw-log heads/tails and all warning/panic matches, and preserved hashes/counts/excerpts in `task-2-review-evidence/retained-logs-check.json`. Thirteen evolving RED runs and ten successful runs are retained. Initial `red.log` fails for absent facade symbols as required. The earlier malformed tstats/held-wildcard corpus setup and syntax typo are recorded in the report and resolved in later evidence; no final warning or unresolved test-output failure was found.
- **Final reported checks:** `task-2-evidence/final-focused-3.log:1` is the clean analysis focused suite (`0.511s`), with recorded exit 0. `task-2-evidence/final-affected-packages.log:1–3` records clean analysis (`1.804s`), validation (`9.294s`), and rewrite (`0.882s`) results, with recorded exit 0. These suites were not rerun.
- **New checks only:** three standalone facade probes exercised the specific uncovered risks identified above. Each used the recorded Go 1.25.5 binary and `GOCACHE=/private/tmp/spl-toolkit-go-cache`, `GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache`, `GOPROXY=off`, `GOTOOLCHAIN=local`, with `go run -mod=readonly` and the single explicit probe file. Raw output and actual exit 0 are retained in the three `*-receipt.json` files. Exit 0 means the observational harness completed; its recorded outputs demonstrate the defects and are not passing regression assertions.
- **Bounded source checks outside the diff:** the reference/read hunk was cut through `readAt`; inspected `pkg/analysis/transfers.go:54–84` to verify actual binding/origin assignment. For the named lookup-barrier risk, inspected `pkg/analysis/commands.go:229–263` and `pkg/analysis/transfers.go:317–331`; the unknown-output diagnostic reaches the new uncertainty hook. For implicit-label ownership, inspected `pkg/analysis/commands.go:175–225`; the existing frontend derives the label. For the named child-predicate traversal risk, inspected `grammar/SPL2Parser.g4:215–245` and `grammar/SPL2Parser.g4:270–290`; no additional finding was established. A preliminary exact-path grammar lookup returned exit 2 because two alternative paths did not exist; the real grammar path was available and read, leaving no evidence gap.
- **Scope/ownership:** all five new bridge files, both focused test files, `forms.json`, and all fourteen surgical hook/capability files are present in the diff and were reviewed. The only `dependencies.go` change is the approved private owner registration beside existing qualifiedCatalog emissions. No source, index, HEAD, branch, or user-owned work was changed. No root oracle or unrelated report was read. This reviewer owns only this report and the narrowly justified `task-2-review-evidence` artifacts. No subagents, broad scans, covered-suite reruns, shared build-all, or Git mutation occurred.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The canonical integration and retained tests provide a solid structure, but the public bridge can publish false guarantees, accept a different identity from the malformed one requested, and erase an unsupported-owner refusal. The quoted composite and aggregate-epoch defects further break the exact identity contract; all five require correction and focused regression evidence before this bridge is released to consumers.
