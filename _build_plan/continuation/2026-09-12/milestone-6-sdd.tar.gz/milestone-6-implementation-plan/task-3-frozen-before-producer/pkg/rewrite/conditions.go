package rewrite

import (
	"bytes"
	"encoding/json"
	"math/big"
	"sort"
	"strings"

	"github.com/delgado-jacob/spl-toolkit/pkg/analysis"
)

// evaluateConditionAtSite consumes only original canonical facts. It deliberately
// does not source-match the site: linked render requirements must independently
// evaluate the originating condition at their own original flow point.
// Conditions and probes have already passed request preparation.
func evaluateConditionAtSite(condition *Condition, probes []analysis.RewriteFactProbe, site analysis.RewriteSite) ConditionEvaluation {
	if condition == nil {
		return conditionResult("true", nil, nil)
	}
	c := *condition
	if c.All != nil || c.Any != nil {
		children := c.All
		if c.Any != nil {
			children = c.Any
		}
		evaluations := make([]ConditionEvaluation, 0, len(children))
		ids := []string{}
		seen := map[string]bool{}
		for i := range children {
			child := evaluateConditionAtSite(&children[i], probes, site)
			evaluations = append(evaluations, child)
			ids = append(ids, child.ReferenceIDs...)
			seen[child.State] = true
		}
		state := "unknown"
		if c.All != nil {
			if seen["false"] {
				state = "false"
			} else if !seen["unknown"] {
				state = "true"
			}
		} else {
			if seen["true"] {
				state = "true"
			} else if !seen["unknown"] {
				state = "false"
			}
		}
		return conditionResult(state, ids, evaluations)
	}
	for probeIndex, probe := range probes {
		if c.Identity == nil || c.Kind != probe.Kind || !conditionIdentityEqual(*c.Identity, probe.Identity) {
			continue
		}
		for _, fact := range site.Facts {
			if fact.ProbeIndex != probeIndex {
				continue
			}
			if c.Fact == "source_reference_present" {
				state := fact.ReferenceState
				if state != "true" && state != "false" {
					state = "unknown"
				}
				return conditionResult(state, fact.ReferenceIDs, nil)
			}
			wantedKind, wanted, understood := conditionScalar(c.Value)
			complete := fact.LiteralComplete && understood
			for _, scalar := range fact.GuaranteedValues {
				kind, value, ok := conditionScalar(scalar.Value)
				if !ok || kind != scalar.Kind {
					complete = false
					continue
				}
				if !understood || kind != wantedKind {
					continue
				}
				match := c.Operator == "equals" && value == wanted
				if c.Operator == "contains" && kind == "string" {
					match = strings.Contains(value, wanted)
				}
				if match {
					return conditionResult("true", fact.ReferenceIDs, nil)
				}
			}
			if complete {
				return conditionResult("false", fact.ReferenceIDs, nil)
			}
			return conditionResult("unknown", fact.ReferenceIDs, nil)
		}
	}
	return conditionResult("unknown", nil, nil)
}

func conditionResult(state string, ids []string, children []ConditionEvaluation) ConditionEvaluation {
	reason := "condition_true"
	if state == "false" {
		reason = ReasonConditionFalse
	}
	if state == "unknown" {
		reason = ReasonConditionUnknown
	}
	return ConditionEvaluation{State: state, Reason: reason, ReferenceIDs: conditionReferenceIDs(ids), Children: append([]ConditionEvaluation{}, children...)}
}

func conditionReferenceIDs(ids []string) []string {
	out := append([]string{}, ids...)
	sort.Strings(out)
	unique := out[:0]
	for _, id := range out {
		if id != "" && (len(unique) == 0 || unique[len(unique)-1] != id) {
			unique = append(unique, id)
		}
	}
	return unique
}

func conditionIdentityEqual(a Identity, b analysis.RewriteIdentity) bool {
	if (a.Name == nil) != (b.Name == nil) || len(a.Path) != len(b.Path) {
		return false
	}
	if a.Name != nil && *a.Name != *b.Name {
		return false
	}
	for i := range a.Path {
		if a.Path[i] != b.Path[i] {
			return false
		}
	}
	return true
}

// conditionScalar normalizes JSON scalar data, never query expressions. Numeric
// equality retains every digit and distinguishes numbers from all other kinds.
func conditionScalar(raw json.RawMessage) (kind, value string, ok bool) {
	if !json.Valid(raw) {
		return "", "", false
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var decoded any
	if decoder.Decode(&decoded) != nil {
		return "", "", false
	}
	switch v := decoded.(type) {
	case string:
		return "string", v, true
	case json.Number:
		return "number", conditionNumber(string(v)), true
	case bool:
		if v {
			return "boolean", "true", true
		}
		return "boolean", "false", true
	case nil:
		return "null", "null", true
	default:
		return "", "", false
	}
}

// Normalize a valid JSON number as coefficient * 10^exponent without expanding
// the exponent. Even very large accepted exponents require only input-sized
// storage, unlike converting the decimal into a rational numerator/denominator.
func conditionNumber(number string) string {
	sign := ""
	if strings.HasPrefix(number, "-") {
		sign, number = "-", number[1:]
	}
	exponent := new(big.Int)
	if i := strings.IndexAny(number, "eE"); i >= 0 {
		exponent.SetString(number[i+1:], 10)
		number = number[:i]
	}
	if i := strings.IndexByte(number, '.'); i >= 0 {
		exponent.Sub(exponent, big.NewInt(int64(len(number)-i-1)))
		number = number[:i] + number[i+1:]
	}
	number = strings.TrimLeft(number, "0")
	if number == "" {
		return "0"
	}
	coefficient := strings.TrimRight(number, "0")
	exponent.Add(exponent, big.NewInt(int64(len(number)-len(coefficient))))
	return sign + coefficient + "e" + exponent.String()
}

// ruleProposal leaves target conflicts to candidate construction while retaining
// every originating rule for independent linked-member condition evaluation.
type ruleProposal struct {
	SiteID               string
	Target               Identity
	RuleIDs              []string
	EvidenceReferenceIDs []string
}
type ruleSelection struct {
	Evaluations []RuleEvaluation
	Proposals   []ruleProposal
	Incomplete  bool
}

func conditionProbes(rules []Rule) []analysis.RewriteFactProbe { return nil }
func selectRules(rules []Rule, probes []analysis.RewriteFactProbe, evidence analysis.RewriteEvidence) ruleSelection {
	return ruleSelection{}
}
