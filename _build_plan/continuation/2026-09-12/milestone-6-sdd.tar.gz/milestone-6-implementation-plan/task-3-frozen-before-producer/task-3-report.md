# Task 3 partial checkpoint — frozen for canonical producer correction

Status: PARTIAL, no Task3 commit. Production/test activity stopped after the red-selection command, as requested by coordinator. All work is in the assigned worktree. No source files outside Task3 ownership were edited.

Current BASE: `0b8dd62068be0638e470a532544acd1cc0a48507`.
Tool: `go version go1.25.5 darwin/arm64`.

Owned untracked production/test files:

- `pkg/rewrite/conditions.go`: SHA256 `6721f6ea136eee71c2497fe04425bc1620864ace075c34e415ed244cdfcb9361`
- `pkg/rewrite/conditions_test.go`: SHA256 `8d7d3743c8694871666d900254af62bbd674be9c297a747933fc859a5ad850ae`
- `testdata/rewrite/conditions.json`: SHA256 `9aaa221e3c3ef42caef7f3d5ae6025443d82b88ed970abf716a9100ddb48500f`

Owned ignored task artifacts: `task-3-report.md`; `task-3-evidence/probe.go`, `producer-probe.json`, `producer-probe.stdout`, `producer-probe.stderr`, `run.py`, and `{red-unit,green-unit,red-selection}.{json,stdout,stderr}`.

## Observed evidence

- `producer-probe`: exit 0. Canonical real-query evidence establishes the coordinator-confirmed completeness gap; see retained raw stdout.
- `red-unit`: exit 1. Minimal evaluator stub caused expected truth-table, typed-scalar, evidence-retention and absence failures.
- `green-unit`: exit 0. `/opt/homebrew/bin/go test -mod=readonly ./pkg/rewrite -run '^TestCondition'` passed against the implemented pure evaluator. Later new probe tests did not exist at this green checkpoint.
- `red-selection`: exit 1. `/opt/homebrew/bin/go test -mod=readonly ./pkg/rewrite -run 'TestConditionProbe|TestRewriteCondition'` failed as expected with newly added probe/selection stubs. Canonical integration tests consequently receive no probes at this checkpoint; these failures are feature RED, not a fresh producer diagnosis. All raw stdout/stderr, exit codes, source hashes and tool/environment identity are retained in matching artifacts. Stderr is empty for these checks.

## Implemented and pending

Implemented: pure `evaluateConditionAtSite` over canonical facts, full child evidence retention for all/any, source-reference truth, typed scalar equals/contains, exact decimal numeric normalization including very large exponents without expanding their magnitude, copied condition evaluations and evidence IDs.

Pending: implement `conditionProbes` and `selectRules` (currently explicit stubs); reconcile real-query fixtures against the reviewed canonical producer correction without weakening approved expectations; add targeted remaining selection/evidence-ownership checks if needed; self-review, affected/package verification, exact-owned commit, final report.

Proposed private API, accepted by coordinator:

```go
conditionProbes(rules []Rule) []analysis.RewriteFactProbe
evaluateConditionAtSite(condition *Condition, probes []analysis.RewriteFactProbe, site analysis.RewriteSite) ConditionEvaluation
selectRules(rules []Rule, probes []analysis.RewriteFactProbe, evidence analysis.RewriteEvidence) ruleSelection
```

`ruleSelection` contains Evaluations, Proposals, Incomplete. `ruleProposal` contains SiteID, Target, RuleIDs, EvidenceReferenceIDs. Planned selection coalesces identical site targets and preserves all originating RuleIDs; Task4 can independently re-evaluate those rules at canonical RequiredChanges sites. No renderer/transfer/query parser is implemented here.

Coordinator confirmed completeness gap for supported OR/NOT and absent earlier facts. A serial original-Task2-writer correction plus review will supply a new BASE. This Task3 worker is frozen until coordinator followup. No commit or success claim is made.
