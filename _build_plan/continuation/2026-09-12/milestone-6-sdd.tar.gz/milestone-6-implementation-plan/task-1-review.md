### Spec Compliance

- ❌ Issues found: the field-list candidate report serializes the full destination catalog, contrary to the binding no-repeated-catalog requirement in `task-1-brief.md:32`. See Important finding I1 at `pkg/rewrite/target.go:39`.
- ✅ The remaining Task 1 contract scope is implemented across exactly the eight authorized paths: strict decoding and shared Go preparation (`pkg/rewrite/request.go:31,115,132,148,319,331,343`), the request/result models (`pkg/rewrite/model.go:20-132`), target delegation (`pkg/rewrite/target.go:42-67,156-165`), input-error classification/reason constants (`pkg/rewrite/diagnostics.go:9,13,18`), focused contract tests (`pkg/rewrite/request_test.go:21,111,162,196,219,274,293`; `pkg/rewrite/model_test.go:12,77`; `pkg/rewrite/target_test.go:11,71,94`) and the independently specified corpus (`testdata/rewrite/requests.json:2-15`). No legacy mapper, shared helper, frontend, transport, native signature or engine implementation appears in the immutable diff.
- ⚠️ Cannot verify from this contract-only diff: later operations must call shared preparation, complete semantic target compilation before publishing a result or partial batch, and implement the rule/coverage/commit semantics. Those are explicitly deferred by `task-1-brief.md:4,109`, and are not missing Task 1 engine work. `pkg/rewrite/target.go:152-165` performs structural preparation only; `task-1-report.md:34` records the coordinator ruling. This review does not grade later integration gates.

### Strengths

- Strict presence checks precede typed decoding, with duplicate/unknown keys rejected and JSON null distinguished from omission. Raw literal scalars are checked with `UseNumber` and copied without float64 conversion; exact neighboring integers are asserted independently (`pkg/rewrite/request.go:31-104,257-313,441-510`; `pkg/rewrite/request_test.go:111-160`).
- Atom/path identities remain distinct, meaningful strings remain unchanged, and direct Go preparation copies pointer/slice/raw-message storage while applying the same rule/condition checks. The ownership tests mutate caller storage and inspect the prepared value (`pkg/rewrite/request.go:385-510`; `pkg/rewrite/request_test.go:274-291`; `pkg/rewrite/target_test.go:94-127`).
- The result contract separates original/candidate/authoritative text and candidate inclusion from commitment; absent references can have rule-level evidence without invented locations. Public collection marshaling emits arrays without changing caller slice values (`pkg/rewrite/model.go:79-184`; `pkg/rewrite/model_test.go:12-75`).
- Canonical document and target decoders retain authority; the target adapter preserves non-nil empty union members rather than hiding them through omitempty (`pkg/rewrite/request.go:124-129,141-145,364-381`; `pkg/rewrite/target.go:42-69,76-150`; `pkg/rewrite/target_test.go:71-92`).

### Issues

#### Critical (Must Fix)

- None found in this task-scoped review.

#### Important (Should Fix)

- **I1 — Repeated full field catalogs in candidate reports.** `pkg/rewrite/target.go:19-22,38-39` directly marshals the embedded `validation.Report`. Its canonical `Target` embeds `FieldCatalog`, including both `fields` and `optional_fields` (`pkg/validation/model.go:7-16,32-35`), and the validation package has no MarshalJSON override to suppress them. Consequently every field-list candidate result carries the entire destination catalog, multiplying response size for ordered batches. This violates `task-1-brief.md:32`; merely excluding Request.ValidationTarget from Result does not remove the nested copy. The test at `pkg/rewrite/model_test.go:77-97` uses a zero-value target and only checks evidence/tag presence, so it does not catch the requirement.
  - **Observed focused reproduction:** marshaling CandidateValidation with Fields = ["user"] and OptionalFields = ["extra"] emitted `field_list.target.fields=["user"]` and `field_list.target.optional_fields=["extra"]`.
  - **Fix:** settle the wire factoring with the coordinator, retain the original Go report and its analysis/outcomes/diagnostics/status/coverage, and serialize only destination target metadata rather than repeating its catalog. Add a nonempty-catalog serialization test that proves both catalog arrays are absent while all report evidence remains. The existing schema-report branch already uses SchemaTargetInfo and need not be expanded into a new schema format.

#### Minor (Nice to Have)

- None raised.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** Request, rule and target input contracts are coherent and well covered, with exact scalar preservation and proper canonical delegation. The field-list result wire contract still violates an explicit payload requirement and should be corrected before the engine builds on it.

### Evidence and review boundary

- Reviewed Base `237e62ac063755559207870b45744db6b2544a17` to Head `f90d364c3cf1ab0bebb62c263a0183cd440076b3` through `review-237e62a..f90d364.diff` only. Its SHA256 is `556bbc68912082d4f15062b81545899bfeb7080878342c587c8aefbbb5c82e7c`. Deterministic extraction of each added file from the immutable diff matched all eight retained tested-source SHA256 values in `task-1-evidence/04-source-identity.json:28-37`.
- Inspected retained RED command/environment/exit `task-1-evidence/01-red.json:2-16` and full log `01-red.log:1-14`: expected missing definitions, Go exit 1. Inspected focused GREEN `02-focused.json:2-16`, `02-focused.log:1`: Go exit 0, 0.377s. Inspected fresh package GREEN `05-package-green.json:2-15`, `05-package-green.log:1`: Go exit 0, 0.359s. No warning or unexpected post-implementation failure appears in those retained test logs. No covered tests were rerun.
- `task-1-evidence/08-final-checks.json` records final HEAD, exact changed paths, no owned diff, base ancestry and source-hash agreement. These are retained implementer observations, not fresh reviewer Git checks. No Git commands were rerun.
- **Focused unchanged-code check, named risk: canonical target adaptation and report payload compatibility.** Read only the FieldCatalog/Target/Report/Coverage and SchemaTarget/OCSFSelection/SchemaTargetInfo/SchemaReport declarations, plus the existing DecodeSchemaTarget/selection decoding boundary, to check for omitted adapter fields and unexpected inherited report payload. A targeted search for validation MarshalJSON methods found none (rg exit 1, no matches). This confirms the adapter fields are compatible and establishes I1; no parser/engine/source-transfer or unrelated milestone code was inspected.
- **One focused new probe for I1:** from the approved worktree, `GOCACHE=/private/tmp/spl-toolkit-go-cache GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache GOPROXY=off GOTOOLCHAIN=local /opt/homebrew/bin/go run -mod=readonly /private/tmp/spl-m6-task1-review-catalog.go`. Observed exit 0, stdout exactly:
  ```text
  field_list.target.fields=["user"]
  field_list.target.optional_fields=["extra"]
  ```
  The probe marshals a populated CandidateValidation and reads only the nested target catalog members. The full probe is retained at `/private/tmp/spl-m6-task1-review-catalog.go`; no product file was added or changed.
- The first combined input read exceeded tool output capacity; missing brief/report/diff spans were recovered with bounded reads. One reviewer log-read shell command failed with `zsh:1: command not found: nl` because the loop variable `path` altered zsh command lookup; independent read commands then recovered all six logs/metadata files. No test was rerun to recover evidence, and neither reviewer tooling issue is a product finding.
- No subagents, source mutations, index/HEAD/branch changes, root private-oracle/aggregate reads, whole-plan reads, broad predecessor tests or generators. The only worktree write is this authorized review artifact.

