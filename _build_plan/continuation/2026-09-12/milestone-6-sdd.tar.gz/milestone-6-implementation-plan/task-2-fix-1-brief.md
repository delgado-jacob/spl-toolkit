# Task2 fix round 1 of 5

Resume the original Task2 implementation at immutable reviewed HEAD 02c2e3217df6edef01cada136d9e623da0de7a93. This is one consolidated correction of the five Important findings and root-included Minor M1 below. The full independent report is task-2-review.md. All three retained standalone probe files/logs/receipts are in task-2-review-evidence; inspect these exact public reproductions without rerunning them merely for orientation. Reviewer observational exit 0 means the harness ran, not that a product regression assertion passed.

The current task-2-brief.md and approved design/ownership remain binding. Root confirmed these findings fit existing contracts and require no new architecture/API gate. Both current delegation files were read and remain unchanged; the original explicit Astra/XHigh/default assignment remains eligible. You are not alone: preserve all others, root private inputs/aggregate, source.go, M5 artifacts, coordinator plan/ledger and the original checkout. No subagents or self-dispatched review.

Own only necessary changes in pkg/analysis/rewrite_facts.go, rewrite_correspondence.go, rewrite_evidence.go, rewrite_render_spl.go, rewrite_render_spl2.go, transfers.go and their existing rewrite_evidence_test.go/rewrite_forms_test.go/form fixture coverage. This list permits a minimal fix, not an instruction to change every file. If another path is demonstrably required, send the exact scope gap before editing. Preserve ordinary Analyze reports and accepted M5 semantics; no blanket token/string policy, second parser/flow engine or scope expansion.

Add meaningful RED regressions in pkg/analysis/rewrite_evidence_test.go (and existing forms coverage only if needed), including pattern/exact-string controls across both dialects, malformed Name and Path original bytes, known null inspection under unknown/unmodeled named ownership, quoted model-only effects and first-read aggregate binding/source epoch continuity. Retain raw RED, focused GREEN and appropriate affected analysis/validation/rewrite results for actual amended source. Do not repeat unchanged preflights/baselines or reviewer probes for status. Keep original evidence immutable; append the fix report to task-2-report.md with commands, observed exits, failures/warnings, tested source hashes and exact commit. Use existing offline Go environment and exact-owned-path authorized escalated commit. Return concise commit/test/concern/report receipt; same reviewer will perform scoped rereview.

Root explicitly includes M1 in this same current fix round: add only its three requested controls (same-text comment, option value, and remote lookup label with a different local alias) in the already owned test file. This supersedes the earlier deferred-Minor entry and the generic SDD routing default; no broader lexical matrix or feature is authorized. Cover all six findings with the same affected verification and scoped rereview. Text capability/OpenAPI and downstream engine cannot-verify items remain at Tasks6/8 and Tasks3–5; they add no Task2 source scope.

## Root contract confirmation

Pattern filters must not supply unsupported exact literal guarantees; invalid target bytes must be rejected before any copying/encoding can sanitize them. Continue original eligible writer scoped fixes and same-reviewer rereview once full report is ready. Include the retained narrow probe path; root will consume the report without rerunning the probe.

Preserve the existing typed-context distinction: pattern-valued search/dependency slots must not yield exact literal facts, while an asterisk in a proven exact string-comparison context must not be rejected merely by spelling. The approved plan distinguishes role-specific literal punctuation and conclusive empty facts versus unknown literal evidence. Keep scoped corrections in canonical owners; no blanket text filter or altered ordinary Analyze behavior. Other confirmed composite-effect/epoch findings fit the existing bridge contract.

## Open Important findings (verbatim independent review)

**I1 — Quoted search wildcard patterns become definite literal facts.**

- Location: `pkg/analysis/rewrite_facts.go:116–130`, `pkg/analysis/rewrite_facts.go:358–373`.
- The quoted-string branch decodes a value without applying the search-pattern restriction used by the unquoted branch. `rewritePredicateFacts` then advertises that decoded pattern as a complete exact literal guarantee. In both SPL and SPL2, `search tag="x*" | lookup people user OUTPUT label` supplies `GuaranteedValues=[{Kind:string, Value:"x*"}]`, `LiteralComplete=true`, and `ReferenceState=true` to the eligible lookup site. The same defect occurs for `search index="main*" ...` with an index probe.
- These are wildcard search predicates, so an equals/contains rule may be authorized from a literal the query does not establish. The postverification gate does not catch the false condition: the probe's people→accounts candidate receives `Verify.Proven=true` in all four cases. The gate correctly checks structural correspondence, but cannot repair an incorrect original guarantee.
- Fix: require the canonical search-value form to prove an exact static literal before publishing equality evidence, including quoted values. Preserve expression-string semantics for contexts where `"x*"` really is a literal, and do not confuse a pattern dependency with an exact source-reference fact. Add field and dependency probes for quoted patterns in both dialects.
- Evidence: `task-2-review-evidence/probe.log:1–2` and `task-2-review-evidence/probe.log:6–7`; source and command identity in `task-2-review-evidence/probe-receipt.json`.

**I2 — Render sanitizes malformed UTF-8 before checking the caller's target.**

- Location: `pkg/analysis/rewrite_correspondence.go:14–25`, with the lossy copy at `pkg/analysis/rewrite_evidence.go:112–116`.
- Render first JSON-copies `changes`, then validates `r.changes`. JSON encoding replaces invalid UTF-8 with U+FFFD, so `rewriteValidIdentity` never sees the malformed original. A target consisting of byte `ff` is accepted with `err=nil`, becomes the logical name U+FFFD, and receives `Verify.Proven=true` in both dialects.
- This violates the explicit request-error requirement (`task-2-brief.md:140`) and changes the requested identity. It is not merely a render refusal or a display issue: the private effect and candidate proof use the substituted identity.
- Fix: validate every original replacement before any potentially normalizing copy, and preserve already-valid identity bytes in the private copy. Add direct facade tests for invalid UTF-8 in target Name and Path values.
- Evidence: `task-2-review-evidence/probe.log:3` and `task-2-review-evidence/probe.log:8`. The additional control-character cases in that log did not expose a defect and are not findings.

**I3 — The null-test role can erase the frontend's unsupported-owner refusal.**

- Location: `pkg/analysis/rewrite_evidence.go:203–205`; the refusal being overwritten is at `pkg/analysis/rewrite_render_spl2.go:41–50`.
- The SPL2 owner walker deliberately clears the role when an enclosing function is unknown or an argument context is unproved. `rewriteReference` then unconditionally replaces that result with `null_test`, removing the only marker used to create `unproved_owner`. In `FROM main | where unknown(isnull(user))=1`, the user operand is consequently eligible even though its owner location is the unknown outer call. Render changes it to account with no requirement limitation, and Verify returns `Proven=true`.
- This defeats the task's conservative unknown-context boundary and the intent of `TestRewriteEvidenceUnknownOwners` (`pkg/analysis/rewrite_evidence_test.go:386–404`). The corresponding SPL probe remains refused; the reproduced defect is SPL2.
- Fix: preserve render-owner proof/refusal independently of the semantic null-test role, or only specialize the role when the frontend owner is already proved. Cover a known null-inspection expression nested under an unknown function and an unmodeled named argument.
- Evidence: `task-2-review-evidence/null-owner-probe.log:2`; SPL refusal control at line 1; command, hashes, and observed exit in `task-2-review-evidence/null-owner-probe-receipt.json`.

**I4 — Model-only edits produce incorrect normalization effects for quoted dataset components.**

- Location: `pkg/analysis/rewrite_correspondence.go:207–231`.
- The enclosing-effect loop starts with the raw dataset token and prepends the selected model name. For `datamodel Traffic 'All'`, Traffic→Network renders the correct `datamodel Network 'All'`, but reports the dataset effect as `Network.'All'` instead of `Network.All`. Double-quoted `"All"` has the same defect. Candidate correspondence consequently fails with `reference_correspondence`, even though the typed component and unchanged quote boundaries are supported.
- This loses the required logical identity of the composite effect and unnecessarily withholds a supported mapping. A located semantic effect must contain decoded identity, not grammar quoting. The durable quoted dataset test currently selects the dataset itself, so it does not cover a model-only normalization effect.
- Fix: derive composite effects from the retained typed/decoded component identity while rendering from the original token. Add model-only edits with single- and double-quoted dataset components, asserting `Network.All` and successful correspondence.
- Evidence: `task-2-review-evidence/composite-epoch-probe.log:1–2`; receipt at `task-2-review-evidence/composite-epoch-probe-receipt.json`. Both documents retain the expected unrelated incomplete datamodel semantics; the reported failure is the incorrect effect, not that incompleteness.

**I5 — Aggregation can invent a new source epoch for an unchanged grouping binding.**

- Location: `pkg/analysis/transfers.go:292–308`, interacting with lazy initialization at `pkg/analysis/rewrite_evidence.go:181–189`.
- Aggregation clones `s.env.rewrite` before reading its grouping operands. When that grouping read is the first evidence-producing read, the clone is nil; the read initializes the input sidecar, then installing the output environment discards it. The subsequent output creation initializes another epoch.
- For valid SPL `stats count BY host | table host`, the grouping host is `SourceEpochID=source-1`, `BindingID=source-1:field:host`; the later passthrough host is `source-2`, `source-2:field:host`. Canonical lineage retains the same `ref-1` origin throughout, and no source reset occurred. The bridge therefore reports two source identities for one binding, undermining the source/flow grouping contract expected by consumers.
- Fix: establish and clone the actual input rewrite state after the grouping reads have contributed their provenance, while keeping output field filtering/invalidation in the canonical aggregation transfer. Add a first-read grouping case that asserts stable SourceEpochID/BindingID and retained supporting references after aggregation.
- Evidence: `task-2-review-evidence/composite-epoch-probe.log:3`, including the exact canonical lineage; source/command receipt in `task-2-review-evidence/composite-epoch-probe-receipt.json`.


## Root-included M1 (verbatim independent review)

**M1 — The requested lexical negative-control matrix is incomplete.**

- Location: `pkg/analysis/rewrite_evidence_test.go:78–95`; requirement at `task-2-brief.md:6`.
- The new lexical-control test covers a string value and a same-spelled lookup catalog name, but has no same-text comment or option-value case. Its remote column label is `remote`, so it also does not prove that a same-spelled remote label remains fixed when a different local alias is present. These cases are not present elsewhere in the new tests/corpus.
- Add focused cases for comments, an option value, and a remote column label whose text matches a proposed source mapping. This is a concrete requested coverage gap; no additional runtime defect is inferred from the absence.

