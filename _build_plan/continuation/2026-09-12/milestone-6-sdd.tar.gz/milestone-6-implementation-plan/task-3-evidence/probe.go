package main
import (
 "encoding/json"
 "fmt"
 "github.com/delgado-jacob/spl-toolkit/pkg/analysis"
)
func main() {
 for _, q := range []string{`search sourcetype=a src=x | table src`, `search (sourcetype=a OR sourcetype=b) src=x | table src`, `search NOT sourcetype=a src=x | table src`, `search src=x | where EventCode=1 | table src`} {
  fmt.Println(q)
  probes := []analysis.RewriteFactProbe{}
  for _, p := range []struct{k,n string}{{"sourcetype","a"},{"field","EventCode"}} { n:=p.n; probes=append(probes,analysis.RewriteFactProbe{Kind:p.k,Identity:analysis.RewriteIdentity{Name:&n}}) }
  s,e:=analysis.PrepareRewrite(analysis.QueryDocument{Text:q},probes); if e!=nil {panic(e)}
  for _, site:=range s.Evidence().Sites {if site.Identity.Name!=nil && *site.Identity.Name=="src" {b,_:=json.Marshal(site);fmt.Println(string(b))}}
 }
}
