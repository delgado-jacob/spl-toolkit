import os, subprocess, pathlib, json, hashlib, sys
root=pathlib.Path('.superpowers/sdd/milestone-6-implementation-plan/task-3-evidence')
label=sys.argv[1]
cmd=['/opt/homebrew/bin/go','test','-mod=readonly']+sys.argv[2:]
env=dict(os.environ,GOCACHE='/private/tmp/spl-toolkit-go-cache',GOMODCACHE='/private/tmp/spl-toolkit-remaining-gomodcache',GOPROXY='off',GOTOOLCHAIN='local')
paths=['pkg/rewrite/conditions.go','pkg/rewrite/conditions_test.go','testdata/rewrite/conditions.json']
meta={'command':cmd,'env':{k:env[k] for k in ['GOCACHE','GOMODCACHE','GOPROXY','GOTOOLCHAIN']},'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tool':subprocess.check_output(['/opt/homebrew/bin/go','version'],text=True).strip(),'sha256':{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in paths if pathlib.Path(p).exists()}}
r=subprocess.run(cmd,env=env,capture_output=True)
(root/(label+'.stdout')).write_bytes(r.stdout);(root/(label+'.stderr')).write_bytes(r.stderr)
meta['exit']=r.returncode
(root/(label+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(r.stdout.decode());print(r.stderr.decode());print('Observed exit:',r.returncode)
sys.exit(r.returncode)
