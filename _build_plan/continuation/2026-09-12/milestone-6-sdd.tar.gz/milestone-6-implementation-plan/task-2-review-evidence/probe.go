package main

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/delgado-jacob/spl-toolkit/pkg/analysis"
)

func atom(name string) analysis.RewriteIdentity { return analysis.RewriteIdentity{Name: &name} }
func emit(value any) { _ = json.NewEncoder(os.Stdout).Encode(value) }
func must(err error) { if err != nil { panic(err) } }
func apply(text string, edits []analysis.RewriteTextEdit) string {
	for i := len(edits)-1; i >= 0; i-- { e := edits[i]; text = text[:e.Location.Start.Offset]+e.After+text[e.Location.End.Offset:] }
	return text
}
func main() {
	for _, language := range []string{"spl", "spl2"} {
		for _, tc := range []struct{query, kind, name string}{
			{`search tag="x*" | lookup people user OUTPUT label`, "field", "tag"},
			{`search index="main*" | lookup people user OUTPUT label`, "index", "main*"},
		} {
			doc := analysis.QueryDocument{Language: language, Text: tc.query}
			s, err := analysis.PrepareRewrite(doc, []analysis.RewriteFactProbe{{Kind: tc.kind, Identity: atom(tc.name)}}); must(err)
			e := s.Evidence()
			for _, site := range e.Sites {
				if site.Kind == "lookup" && site.Identity.Name != nil && *site.Identity.Name == "people" {
					r, err := s.Render([]analysis.RewriteReplacement{{SiteID:site.ID, Target:atom("accounts")}}); must(err)
					doc.Text = apply(doc.Text, r.Edits())
					candidate, err := analysis.PrepareRewrite(doc, nil); must(err)
					emit(map[string]any{"case":"quoted-search-wildcard", "language":language, "query":tc.query, "probe_kind":tc.kind, "status":e.Analysis.Status, "site":site, "candidate":doc.Text, "proof":s.Verify(candidate,r)})
				}
			}
		}
		query := `search index=main | where user=1`
		if language == "spl2" { query = `FROM main | where user=1` }
		s, err := analysis.PrepareRewrite(analysis.QueryDocument{Language:language,Text:query}, nil); must(err)
		for _, site := range s.Evidence().Sites {
			if site.Kind != "field" || site.Identity.Name == nil || *site.Identity.Name != "user" { continue }
			for _, target := range []string{string([]byte{0xff}), "a\x01b", "a\x00b"} {
				r, err := s.Render([]analysis.RewriteReplacement{{SiteID:site.ID,Target:atom(target)}})
				result := map[string]any{"case":"target-validation", "language":language, "target_bytes":fmt.Sprintf("%x",[]byte(target)), "error":fmt.Sprint(err)}
				if err == nil {
					result["edits"], result["requirements"] = r.Edits(), r.Requirements()
					candidateText := apply(query,r.Edits())
					candidate, candidateErr := analysis.PrepareRewrite(analysis.QueryDocument{Language:language, Text:candidateText},nil); must(candidateErr)
					result["candidate"], result["candidate_status"], result["proof"] = candidateText, candidate.Evidence().Analysis.Status, s.Verify(candidate,r)
				}
				emit(result)
			}
		}
	}
}
