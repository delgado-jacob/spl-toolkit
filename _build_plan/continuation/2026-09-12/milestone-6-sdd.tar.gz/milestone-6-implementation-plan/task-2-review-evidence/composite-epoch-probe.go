package main

import (
	"encoding/json"
	"os"

	"github.com/delgado-jacob/spl-toolkit/pkg/analysis"
)

func main() {
	for _, query := range []string{`datamodel Traffic 'All'`, `datamodel Traffic "All"`} {
		doc := analysis.QueryDocument{Language:"spl", Text:query}
		s, err := analysis.PrepareRewrite(doc,nil); if err != nil { panic(err) }
		for _, site := range s.Evidence().Sites {
			if site.Kind != "data_model" { continue }
			target := "Network"
			r, err := s.Render([]analysis.RewriteReplacement{{SiteID:site.ID,Target:analysis.RewriteIdentity{Name:&target}}}); if err != nil { panic(err) }
			edits := r.Edits()
			for i:=len(edits)-1; i>=0; i-- { e:=edits[i]; doc.Text=doc.Text[:e.Location.Start.Offset]+e.After+doc.Text[e.Location.End.Offset:] }
			candidate, err := analysis.PrepareRewrite(doc,nil); if err != nil { panic(err) }
			_ = json.NewEncoder(os.Stdout).Encode(map[string]any{"case":"quoted-dataset-normalization","query":query,"candidate":doc.Text,"status":candidate.Evidence().Analysis.Status,"effects":r.Effects(),"requirements":r.Requirements(),"proof":s.Verify(candidate,r)})
		}
	}
	query := `stats count BY host | table host`
	s,err := analysis.PrepareRewrite(analysis.QueryDocument{Language:"spl",Text:query},nil); if err != nil { panic(err) }
	e := s.Evidence(); sites := []analysis.RewriteSite{}
	for _,site := range e.Sites { if site.Kind=="field" && site.Identity.Name!=nil && *site.Identity.Name=="host" { sites=append(sites,site) } }
	_ = json.NewEncoder(os.Stdout).Encode(map[string]any{"case":"aggregate-first-read-source-epoch","query":query,"status":e.Analysis.Status,"host_sites":sites,"lineage":e.Analysis.Lineage})
}
