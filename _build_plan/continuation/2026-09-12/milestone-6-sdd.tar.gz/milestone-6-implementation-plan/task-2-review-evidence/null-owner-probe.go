package main

import (
	"encoding/json"
	"os"

	"github.com/delgado-jacob/spl-toolkit/pkg/analysis"
)

func main() {
	for _, language := range []string{"spl","spl2"} {
		query:=`search index=main | where unknown(isnull(user))=1`
		if language=="spl2" { query=`FROM main | where unknown(isnull(user))=1` }
		doc:=analysis.QueryDocument{Language:language,Text:query}
		s,err:=analysis.PrepareRewrite(doc,nil); if err!=nil {panic(err)}
		for _,site:=range s.Evidence().Sites {
			if site.Kind!="field" || site.Identity.Name==nil || *site.Identity.Name!="user" {continue}
			target:="account"; r,err:=s.Render([]analysis.RewriteReplacement{{SiteID:site.ID,Target:analysis.RewriteIdentity{Name:&target}}}); if err!=nil {panic(err)}
			edits:=r.Edits(); for i:=len(edits)-1;i>=0;i-- {e:=edits[i];doc.Text=doc.Text[:e.Location.Start.Offset]+e.After+doc.Text[e.Location.End.Offset:]}
			c,err:=analysis.PrepareRewrite(doc,nil);if err!=nil {panic(err)}
			_ = json.NewEncoder(os.Stdout).Encode(map[string]any{"language":language,"query":query,"original_status":s.Evidence().Analysis.Status,"site":site,"candidate":doc.Text,"requirements":r.Requirements(),"proof":s.Verify(c,r)})
		}
	}
}
