# Task8 carried review observations

Task2 Minor M1: complete the requested lexical negative-control matrix with same-text comments, option values and a remote lookup column label matching a source mapping when a different local alias is present. Source: task-2-review.md, Minor M1, rewrite_evidence_test.go:78–95. No runtime defect inferred. Carry to corpus coverage and final broad review; do not silently discard. Task8 also closes documented capability/form truth after Task6 text/OpenAPI integration.

Superseding root direction during Task2 fix round1: M1 is now included in that current original-writer correction and same scoped rereview, because the three controls belong to the existing brief/test file. It is no longer deferred to Task8; carry only any actual unresolved rereview outcome. The capability documentation/corpus obligation remains.

Task2 scoped rereview observation O1 (non-blocking, unprobed): check metric field Boolean scalar-kind dispatch at rewrite_facts.go:373 with tstats aggregates=[count()] predicate=(flag=true) byfields=[host], comparing with ordinary exact-expression typing. This behavior predates Task2 fix round1; do not reopen its closed I1 or substitute scalar coercion in rewrite. Carry the specific check into broad triage.

Superseding root timing: O1's single bounded canonical check moves to the next stable gap after Task3 acceptance, before downstream engine acceptance, using the original eligible Task2 writer serially. Final broad review will consume the resulting check/fix/review evidence, rather than being the first check. No runtime reproduction has yet been run for O1.

Final O1 disposition: root moved the check into the serial producer follow-up before Task3 real-query acceptance. Retained pre-fix probe confirmed the metric Boolean/string mismatch; canonical fix 5745041676c8d6cddfb7b769c2aaa2630d3ab8a2 passed affected analysis/validation and independent review (task-2-producer-followup-review.md SHA f07bd46f). O1 is closed, with no new findings. Broad review consumes that evidence; no unchanged probe rerun or consumer coercion is required.
