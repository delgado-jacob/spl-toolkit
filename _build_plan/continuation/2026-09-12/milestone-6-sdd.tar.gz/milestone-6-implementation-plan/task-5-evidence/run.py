import datetime, hashlib, json, os, pathlib, subprocess, sys
root = pathlib.Path(__file__).resolve().parents[4]
evidence = pathlib.Path(__file__).resolve().parent
label, *args = sys.argv[1:]
env = dict(os.environ, GOCACHE='/private/tmp/spl-toolkit-go-cache', GOMODCACHE='/private/tmp/spl-toolkit-remaining-gomodcache', GOPROXY='off', GOTOOLCHAIN='local')
paths = sorted({*root.glob('pkg/rewrite/*.go'), *root.glob('pkg/analysis/*.go'), *root.glob('pkg/validation/*.go'), *root.glob('testdata/rewrite/*'), root/'go.mod', root/'go.sum', root/'testdata/schemas/ocsf/1.6.0/base.json.gz'})
meta = {'command': args, 'cwd': str(root), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'environment': {k: env[k] for k in ('GOCACHE','GOMODCACHE','GOPROXY','GOTOOLCHAIN')}, 'head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip(), 'go_version': subprocess.check_output(['/opt/homebrew/bin/go','version'], env=env, text=True).strip(), 'tool_sha256': hashlib.sha256(pathlib.Path('/opt/homebrew/bin/go').read_bytes()).hexdigest(), 'files': {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}}
with (evidence/(label+'.stdout')).open('wb') as out, (evidence/(label+'.stderr')).open('wb') as err:
    result = subprocess.run(args, cwd=root, env=env, stdout=out, stderr=err)
meta.update(exit_code=result.returncode, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(evidence/(label+'.json')).write_text(json.dumps(meta, indent=2)+'\n')
print(json.dumps({'label': label, 'exit_code': result.returncode, 'stdout': str(evidence/(label+'.stdout')), 'stderr': str(evidence/(label+'.stderr'))}))
print((evidence/(label+'.stdout')).read_text()[-15000:])
print((evidence/(label+'.stderr')).read_text()[-5000:])
sys.exit(result.returncode)
