## Task 5: Canonical post-verification, apply policy and ordered batches


Own pkg/rewrite/verify.go, rewrite.go, batch.go, focused tests and durable testdata/rewrite/cases.json. Consume the accepted canonical evidence bridge, candidate edits and real public validation APIs. Produce Rewrite/RewriteBatch and complete canonical Result/BatchResult values. Any necessary narrow canonical proof helper is reviewed with analysis ownership rather than implemented as a second flow engine in verify.go.

1. Write TestRewritePreviewApply with the explicit-alias example and an independently reviewed full report. Preview returns candidate_applied true for included edits, committed false and authoritative original text. Apply returns candidate text and committed true only after proof. Empty/no-match/no-change rules yield unchanged bytes, committed false and no fabricated applied entries. Reanalyze an unchanged candidate or safely reuse equal original analysis; still evaluate an explicitly requested target.

2. Reanalyze each candidate with identical dialect/profile/version/source_id and build original-to-candidate reference correspondence from the real edit translation and canonical identities. Compare affected roles, scopes, binding provenance, origin chains, transitions and SQL phases under the requested mapping. Parser success is insufficient. Check explicit aliases unchanged, implicit generated-name consumers moved consistently, and no newly introduced capture/unavailable bindings or affected uncertainty. Unchanged unsupported evidence is compared by translated locations and semantic ownership, never diagnostic counts alone.

3. Add TestRewritePostVerificationFailure for original syntax damage, invalid candidate syntax induced at the internal edit-test seam, a syntactically valid but wrong binding/capture, lost implicit linkage and newly uncertain affected flow. The test seam supplies an internal malformed proposed edit only in package tests; no caller API bypass exists. Failed apply retains original text, keeps candidate analysis/text as evidence, and changes previously proposed applied entries to skipped/post_verification_failed with candidate_applied true and committed false. Do not silently publish a second reduced candidate.

4. Add TestRewriteDestinationValidation covering field-list missing target field, JSON Schema missing/conditional/unresolved cases, and a real local OCSF catalog target from accepted durable fixtures. Validation describes destination inputs, so old source names absent from the target do not pre-reject a valid migration. Require the final validation report status valid for commit, including complete analysis/schema coverage. Preserve original canonical validation report data. Without a target, unrelated incomplete scope evidence may remain if edited groups are independently proven; with an incomplete target report, commit fails. A definite validation error yields invalid; otherwise unknown validation/rewrite evidence yields incomplete.

5. Implement batches in two phases: prepare/validate request shapes and rules, then form ordered candidate documents and call existing ValidateBatch or ValidateSchemaBatch once if requested. Attach each returned canonical report at its original index, run per-document gates and only publish the batch after all input/internal operations succeed. Invalid query syntax is a per-query invalid result; malformed options, target, empty batch or internal failure rejects the whole request without a partial report. There are no external mutation transactions: each successful apply result commits only its returned string. Aggregate invalid outranks incomplete outranks valid.

6. Add TestRewriteBatchOrderAndAtomicErrors and TestRewriteConcurrentOwnership for mixed dialect/status documents, safe groups beside ambiguous groups, caller mutation after request preparation and repeated/concurrent equality. Run `go test -mod=readonly ./pkg/rewrite ./pkg/analysis ./pkg/validation` with targeted race tests in this task if root's stable window permits. Commit/review Task 5, then reserve a Go-only acceptance window with immutable input identity before dispatching adapters.


## Preserved Task1 target-preparation obligation

Task1 prepares strict request/target structure through the existing DecodeSchemaTarget boundary. Semantic schema/catalog compilation is private in canonical validation and is not duplicated by rewrite. Root acknowledged this boundary after reviewing Task1's declarations. Task5 must complete canonical semantic target preparation before publishing any single result or any partial batch. A structurally accepted target may still return the existing validation input error; wrap/preserve classification through rewrite.IsInputError. Do not use an empty-query validation proxy or a second schema compiler. The unchanged candidate still undergoes requested destination validation, including no-op requests.

This is preparation only: do not dispatch or execute Task5 until reviewed Tasks1–4 supply their immutable accepted interfaces. Root's Go-only acceptance window begins after reviewed Task5 and before CLI/HTTP/native adapter production. The coordinator will supply those exact predecessor interfaces and complete execution ownership/evidence instructions at dispatch.

## Execution and evidence boundary

This brief is not released until its accepted predecessor and immutable BASE are supplied by the coordinator. Work only in /Users/jacobdelgado/repos/spl-toolkit/.worktrees/remaining-milestones. Own only the task files explicitly listed above and this task report/evidence; request a concrete ownership ruling for any additional necessary source file before editing it. You are not alone: preserve other source changes, coordinator living plan/ledger, root aggregate and private acceptance oracles, all M5 artifacts/history and the user's original checkout. Never inspect other milestone SDD directories or private root acceptance inputs. No subagents, self-dispatched reviewer, branch/worktree creation, merge, push, publication, cleanup or downstream task implementation.

Read current /Users/jacobdelgado/.codex/AGENTS.md and /Users/jacobdelgado/.codex/skills/efficient-delegation/SKILL.md. Use TDD and verification-before-completion. Do not reread the full plan or redo accepted design/preflight/baseline research. Inspect only accepted producer interfaces and canonical source needed for this task. Capture meaningful RED, affected GREEN and appropriate package verification with exact source/tool identities, raw stdout/stderr and observed exit status, including every relevant failure/warning. Do not rerun tests merely to regenerate a summary.

Use GOCACHE=/private/tmp/spl-toolkit-go-cache, GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache, GOPROXY=off and GOTOOLCHAIN=local with /opt/homebrew/bin/go. No dependency/toolchain/network changes or shared build-all for orientation. Root authorizes exact-owned-file commits; use require_escalated for exact-path git add/commit because the shared .git is read-only in the default sandbox. Do not repeat the known index-lock denial or use add -A/reset/stash/clean. Self-review and commit only owned files. Record the immutable commit, tested hashes, implementation, test commands/results, raw evidence and concerns in the task report; return concise status/commits/test outcome/concerns/report path.

## Accepted preview/apply context (verbatim approved design)


Preview builds the candidate from independently eligible, unambiguous groups, then reparses and reanalyzes it in the same document language/profile/version. If requested, validate that destination candidate through the existing canonical field-list or schema validator. Retain original analysis, candidate analysis and validation evidence. Do not apply from syntax-damaged original input where exact token/binding evidence cannot be established; the conservative default for original syntax errors is no edits and an invalid report with original bytes retained.

Verification is stronger than parser success. Map original reference identities and locations through the edit map, and prove preservation of the intended static binding/lineage relationships under the selected mapping. Check changed implicit outputs, capture, scope boundaries and SQL phases. New uncertainty is assessed by affected scopes, identities, transitions and translated source evidence, never by diagnostic counts alone. An uncertainty barrier touching an edited group fails its proof.

Apply uses one whole-request verification gate after safe-group selection. It publishes the candidate only if candidate parsing succeeds, static relationship checks succeed, no new relevant uncertainty is introduced, and candidate analysis has no definite errors. Without requested schema validation, unrelated preexisting semantic incompleteness may remain when every edited group is independently proven. A supplied validation target is a strict additional gate: its resulting validation report must be conclusive and error-free. Invalid or incomplete requested validation prevents commit, including incomplete analysis retained in that validation report.

If any gate fails, returned authoritative text is the original query, `committed` is false, and candidate text survives solely as preview evidence. Every proposed edit is marked not committed; apply audit entries that were included in the candidate become skipped with `post_verification_failed` and retain their proposed replacement/candidate coordinates. No automatic rollback subset search or second attempt publishes only some failed-request edits.

Independent safe groups may commit while ambiguous/unknown groups remain unchanged if the resulting candidate passes the gate. Such a result is explicitly incomplete with `committed: true`. A syntactically and semantically valid candidate does not erase unknown mapping eligibility. Unmatched rules, false conditions, explicit derived names outside source mapping, and source-equals-target rules are ordinary explained skips and do not automatically make the result incomplete.


## Binding behavioral constraints (verbatim approved plan)

Only Milestone 6 is in scope. Preserve existing fixed-SPL mapper methods, configuration precedence and old native signatures. Do not change source files in place, perform whole-query conversion, beautify queries, rewrite wildcards/dynamic identifiers, infer raw-to-data-model/tstats changes, learn rules, execute searches or claim equivalent runtime results. Report output explicitly requested by a CLI caller is the only filesystem write performed by the operation.

Select language spl or spl2 explicitly through the existing canonical QueryDocument, with omitted language defaulting to spl, profile splunkd and version current. Normalize/reject options through the accepted canonical selector boundary. Maintain source text and source identity byte-for-byte, half-open UTF-8 byte offsets, Unicode columns, CRLF semantics, copied public values, deterministic IDs and array ordering. Unknown options and malformed Unicode remain request errors.

Conditions use only original, guaranteed source/flow facts. AND combines compatible guarantees, OR intersects guarantees, and query NOT establishes no positive equality. Later facts cannot authorize earlier edits; independent child queries never establish parent facts. Source-reference-present is a static query-reference fact, never event presence. The new rule language contains all/any, proven literal equals/string contains and source-reference-present, without regex, arbitrary code, condition-language NOT or caller-injected facts.

Canonical frontends own typed contexts, identity interpretation and render eligibility. Canonical transfer owns bindings, alias/implicit-output origins, inherited environments, unknown barriers, SQL logical phases and source universes. Rewrite must neither discover these by substring/regex/token guesses nor replay their transfer algorithms. The selected M6 rewrite bridge below is new implementation work; existing M5 helpers named below are real at the accepted fixed source. Final M5 closure at 237e62ac preserves those source identities; any later actual relevant change must be reconciled before it is used.

Atom/path rule identities remain distinct. On 2026-09-08 root confirmed that M6 adds only minimal fact/render/implicit-name hooks for already proven forms; do not expand canonical path binding just to force a mapping or schema match. Use the reconciled proven-form inventory below; every navigated or alias-qualified form that lacks canonical binding proof remains a located refusal.

Apply has one whole-request post-verification gate. Existing unrelated semantic incompleteness may remain without a requested target if every edited group is proven. Requested destination validation must produce a valid, complete report; invalid or incomplete validation prevents commit. An unknown/ambiguous group may remain unchanged alongside independently committed safe groups, yielding incomplete with committed true. This never permits an edit to depend on a skipped edit for safety.

## Accepted Task1 wire and ordering obligations

Keep CandidateValidation.FieldList as the complete, unchanged canonical *validation.Report in Go. Task1's root-approved rewrite-only MarshalJSON projection retains field_list.target {kind, identity, version}, all three keys including empty metadata strings, and omits only fields/optional_fields from that target metadata. Every other canonical report field/value/analysis/outcome/coverage/diagnostic remains unchanged. Standalone canonical validation serialization and the JSON Schema/OCSF branch remain unchanged. Use that existing serializer; do not reproject or rebuild validation results in the engine.

Ordering is deterministic: rules preserve request order; candidate references and changes follow canonical source ordering with stable tie-breakers; contributing rule IDs follow request order; diagnostics follow the canonical location/code/message order. Empty collections serialize as arrays, never null. State is call-local, inputs are copied as needed, and concurrent identical calls return equivalent JSON values.

## Prepared concrete engine handoff — Task4 review/release pending

Task4 candidate 14a3a0dcfe4652240dc8b949461f905b206f215a is under independent review. This section prepares its reported interface only; the coordinator must bind the final accepted Task4 HEAD/review and release Task5 before implementation. Preserve all historical BASE/final-source qualifications; no assumption below accepts an unreviewed candidate.

Exact Task5 product ownership is pkg/rewrite/verify.go, verify_test.go, rewrite.go, rewrite_test.go, batch.go, batch_test.go and testdata/rewrite/cases.json. Existing Task1 contract/serializer, Task3 selection and Task4 candidate helpers are inputs, not file ownership. Raise a concrete owner/interface issue before modifying any other source; no canonical proof duplicate or schema compiler is authorized.

Approved public operations are exactly:

```go
func Rewrite(request Request) (*Result, error)
func RewriteBatch(request BatchRequest) (*BatchResult, error)
```

Go-constructed requests must use the same existing preparation rules as strict decoded requests. Keep DecodeRequest/DecodeBatchRequest/DecodeRuleSet/IsInputError unchanged unless a reviewed concrete interface issue requires an ownership ruling. Request/BatchRequest/Result/BatchResult already exist; do not export alternate engine/request/result variants.

Canonical validation provides the existing Validate/ValidateBatch and ValidateSchema/ValidateSchemaBatch APIs with QueryDocument, FieldCatalog and SchemaTarget. The batch APIs prepare one target for an ordered candidate slice. Use them directly once for a requested batch target, retain exact original report objects and positions, and finish all input/internal operations before returning any partial batch. A single request also finishes canonical semantic target checking before publication. No validation of a synthetic empty query, no new public target-preparation API and no duplicated schema/catalog compilation.

Task3 accepted private helpers are conditionProbes(rules), evaluateConditionAtSite(condition, probes, site), and selectRules(rules, probes, evidence). Task4 reports this private candidate API; reconcile it to the final accepted source at release:

```go
func buildCandidate(session *analysis.RewriteSession, rules []Rule, probes []analysis.RewriteFactProbe, selection ruleSelection) (*rewriteCandidate, error)

type rewriteCandidate struct {
    Text        string
    Changes     []Change
    Groups      []editGroup
    Evaluations []RuleEvaluation
    Rendering   *analysis.RewriteRendering
    Session     *analysis.RewriteSession
    Proof       analysis.RewriteProof
    Incomplete  bool
}
```

Prepare the original session once from the prepared document/probes, select only from its original Evidence, then build the candidate from those same inputs. Candidate Session is final canonical analysis with identical language/profile/version/source ID; Rendering belongs to the original session, and Proof corresponds to that original/candidate/rendering triple. Task4 already uses canonical Verify for collision selection; Task5 still owns the explicit whole-request syntax/definite-error/affected-uncertainty/destination-validation decision and authoritative Text/Committed policy. Reuse the final candidate session/evidence or call original.Verify(candidate.Session, candidate.Rendering) as needed; never invent reference correspondence or coordinates.

Groups with empty Reason are selected; rejected groups retain linked_edit_unproven, target_not_renderable, conflicting_targets, overlapping_edits or binding_collision, plus canonical limitations. A rejected group's representative replacements are not an authorized target choice or fallback apply attempt; its full conflicting alternatives are retained in Changes/private audit members. No second reduced candidate may be published after a whole-request gate failure.

Included Changes are proposed/matched, CandidateApplied=true, exact candidate locations and resolvable IDs, Committed=false. Refused alternatives retain ambiguity/skips and original coordinates; unavailable encoding leaves NewText empty rather than guessed text. On failed apply, preserve candidate text/analysis/validation/audit coordinates, authoritative original text and all Committed=false; included proposals become skipped/post_verification_failed while CandidateApplied remains true.

Candidate Evaluations includes originating-rule checks at canonical implicit consumers in request/source order. Task4 Incomplete combines Task3 uncertainty, required-member unknown condition evidence and rejected groups; identical unconditional authorization may permit a candidate while another rule remains unknown. Proven derived-name ordinary skips are not made incomplete merely by unsupported_reference wording. Combine the actual candidate summary with original/candidate canonical coverage and requested validation under the approved final policy. Do not count diagnostic totals or reason strings as a substitute for affected ownership/proof.

After complete immutable Task5 review, stop all product mutation/test/build activity and deliver the exact accepted core HEAD and recoverable evidence for root's independent Go-only acceptance window. No CLI/HTTP/native adapters start before that window is explicitly released. Targeted Task5 concurrency/race and approved affected checks are authorized before this stable window; no parallel root acceptance is running during implementation.
