# M6 Task 4 independent combined review

**Spec compliance: Approved for the Task 4 boundary, with the investigated uncertainty limit and downstream gates stated below.**
**Code quality: Approved.**
**Open findings: 0 Critical, 0 Important, 0 Minor.**

Reviewed BASE `6c18c32a073b944375d1d37da7e47b768d16656a` → HEAD `14a3a0dcfe4652240dc8b949461f905b206f215a`. This is a task gate, not whole-branch acceptance or Task 5 apply/validation acceptance.

## Inputs and scope

The review used the full current Task 4 brief, implementation report, candidate identity, retained test/probe receipts and raw streams, and the immutable 52,288-byte package `review-6c18c32..14a3a0d.diff`. All five new-file hunks were read once in sequential, nonoverlapping windows. Mechanical patch-byte hashing later reconciled the full added bytes without another semantic pass over the diff. No changed source file was separately reread.

Verified input SHA-256 values:

| Input | SHA-256 |
| --- | --- |
| Review assignment | `bb7c529de8dc2527ac608f7cb1ddd8d502797f923cea20fc16b3620c1373c0c1` |
| Review brief | `33f0c5ad5045675859502af1c5b5c0286719d7e817cfc5c9aa2d2d372a499e28` |
| Task brief | `c8a1f30a1feb2ee8c4fb783260e68f0cde83bf7a1e609918d2822802474a320d` |
| Implementation report | `17a90b443e00f0ccd266c17b69871e96c44f0150b5f60a491c8267970ea7216c` |
| Immutable diff | `92f5cdaeb54e0f25f2c3220795fe9503caa036b550157ff425c7b277fd7aef9d` |
| Candidate identity | `3c5556f59922d1a24209dacc7935b53d265eaa288bfe17bb3e7df533db19de07` |

The package contains one commit and exactly the five owned additions: `pkg/rewrite/groups.go` (602 lines), `groups_test.go` (288), `edits.go` (182), `edits_test.go` (97), and `testdata/rewrite/edits.json` (467). Every assigned file has its required hunk. The initial read-only HEAD/status/stat observation matched the named HEAD, five-file scope and retained untracked plan files; no Git command was repeated after reading the review template. The retained commit receipt records BASE as the direct parent, ancestry exit 0 and an empty owned-worktree diff. No source, index, HEAD, plan, ledger, acceptance input or other agent artifact was modified. Only this report and `task-4-review-evidence/` were written; no children were dispatched.

## Spec checks and strengths

| Requirement | Reviewed evidence and conclusion |
| --- | --- |
| Original canonical identity and linked source members | `pkg/rewrite/groups.go:64-100,192-218` groups canonical BindingIDs, falls back to a single site when absent, and requires a selected proposal at each eligible original member. It does not rename same-spelled derived aliases. Explicit rename/eval/aggregate aliases, parent-derived versus child-source identity, and exact removal cases are retained in `testdata/rewrite/edits.json`; `groups_test.go:37-115` asserts actual canonical candidate text. |
| Implicit names and per-member conditions | `groups.go:219-307` consumes canonical Render requirements, obtains linked target identities from the producer, and independently evaluates originating rule conditions at required derived consumers. Coupled catalog dependencies require their own selected rule. False/unknown required authorization refuses the linked group; an independently true identical rule can authorize an edit while unknown evidence still marks incompleteness. `groups_test.go:137-159` verifies this distinction and per-edit RuleIDs. No AS alias or generated name is invented by rewrite. |
| Relevant uncertainty and scope independence | `groups.go:325-368` obtains affected field references from canonical effects and tests actual live origin sets or the edited owner's stage/phase against transition uncertainty, incomplete owning stages and dynamic/unproved field owners. It does not propagate uncertainty merely by matching text or source epoch. The retained wildcard, dynamic, unknown-merge, independent-child, removed-before-unknown and SPL2 implicit-refusal cases exercise the boundary. The shared-stage sibling-owner comparison is qualified below: the owning-phase match alone is not an independence proof, and the retained unsupported case also carries affected origins through an uncertain transition. |
| Contradictory and overlapping alternatives | `groups.go:371-439` connects shared required sites and overlapping intervals, preserves member alternatives, coalesces compatible site targets and rejects incompatible targets/render overlaps. `edits.go:57-160` retains rejected alternatives with their contributing rules and original locations. `groups_test.go:119-135` asserts distinct conflict alternatives, and the compatible-catalog fixture asserts both rule and original/candidate reference IDs survive co-rendering. |
| Simultaneous capture/collapse and closure | `groups.go:101-168,443-491` schedules potentially interacting groups using source epochs/live origins plus before/after identities, but uses canonical Verify to decide safety. Shared epochs are scheduling evidence, not a binding proof. Already refused groups are absent from each component candidate, so a survivor cannot borrow their changes. Every failed component loses its selected members; the final combined surviving set is verified, and failure removes all remaining edits and constructs the empty mapping. This is monotone conservative closure with no precedence, iterative maximum-subset search or alternate publication attempt. Retained swap, chain, alias capture, live collapse, skipped-safety-dependency and independent-source-epoch fixtures test actual canonical behavior. |
| Byte-preserving construction | `edits.go:14-55` validates original byte ranges through LocateRewriteBytes, sorts a copied index order, rejects mismatched old slices and incompatible overlap, copies untouched bytes once, and records cumulative candidate byte ranges in caller order. It then calls the canonical locator with the exact constructed text. It contains no rune/CRLF coordinate scan or EOF cleanup. `edits_test.go:14-77` covers hand-derived Unicode/newline/CRLF positions, unsorted arbitrary spans, boundary insertions, overlap, split codepoints, malformed replacement text and literal `<EOF>`. |
| Real candidate audit coordinates and reference correspondence | `edits.go:57-143` uses the actual final rendering and reconstruction locations, maps candidate IDs through the final canonical proof, retains original IDs, and leaves rejected alternatives outside the candidate. `edits_test.go:79-97` checks hand-derived candidate positions after canonical escaped multiline Unicode rendering. `groups_test.go:79-105` checks original/candidate slices and co-rendered provenance. |
| Ordering, copying and ordinary skips | `edits.go:161-180` sorts public Changes by original location with stable replacement/group ties. `groups.go:176-190,557-602` preserves request-order contributing RuleIDs, evaluation ordering and deep copies condition evidence. `groups_test.go:161-233,236-288` checks concurrent deterministic output, reversed rule order without precedence, returned audit ownership, ordinary derived/no-match/false/no-change skips and unknown incompleteness. Opaque group numbering is qualified below. |
| Private Task 5 interface | `groups.go:12-38,64-173,475-491` exposes package-private preview text, final candidate session, original-session rendering, correspondence proof, group reasons/limitations, evaluations and audit. The renderer and session retain the original language/profile/version/source ID. `edits.go:91-160` never marks a change committed. The interface supplies Task 5's inputs without adding an engine API or duplicating parsing, frontend rendering, source coordinates or transfer. |

The two production files have clear responsibilities: `groups.go` constructs linked groups and coordinates canonical selection proofs; `edits.go` reconstructs bytes and builds changes. Their added size is supported by the required conflict, closure and audit behavior, and the union-find helper is limited to those connections. No unnecessary abstraction, unrelated cleanup or expanded frontend capability was introduced.

## Named interface checks outside the diff

1. **Risk: opaque Render requirements could be misinterpreted or reused without original-session authority.** Read the actual facade values/accessors in `pkg/analysis/rewrite_evidence.go:12-109,147-175`, and requirement/implicit-consumer/catalog/overlap construction in `rewrite_correspondence.go:10-220`. Render validates unique site replacements, retains requirements/effects and owns all encoding. The consumer uses these exported copies and submits targets back to the original session; no producer ownership is inferred from strings.
2. **Risk: component success might be parser-only or final candidate/session metadata might bypass correspondence.** Read `rewrite_correspondence.go:282-491`. Verify checks render provenance, candidate bytes and document selectors, requirements, syntax/definite validity, reference roles/scopes/stages/bindings, origins, direct alias ownership, field membership and transition relationships, including located uncertainty. `groups.go:475-491` passes the original opaque rendering and the actual reconstructed candidate; no alternate proof is substituted.
3. **Risk: initial group scheduling might depend on rule precedence or silently reclassify accepted Task 3 exclusions.** Read the specific `ruleProposal`/`ruleSelection` declarations and `selectRules` in `pkg/rewrite/conditions.go:190-200,242-327`. Its proposals are original-site ordered; identical site/target proposals retain request-order contributors, and known-derived exclusions remain ordinary while unknown eligibility remains incomplete. Task 4 consumes and copies that output rather than replacing selection policy.
4. **Risk: byte offsets could be sent to the rune-indexed private location method.** Read only `pkg/analysis/rewrite_evidence.go:300-328` for the locator contract. LocateRewriteBytes validates UTF-8 and byte boundaries and returns canonical Locations; Task 4 calls it with half-open byte ranges. It never calls the private source index.

5. **Risk: the stage-wide fallback might over-reject a canonically independent SQL sibling owner.** A bounded lookup of the existing SQL evidence test and `testdata/spl2/sql-clauses.json` / `sql-boundaries.json` identified admitted SELECT syntax and the established unproved qualified-owner boundary (including `T4.typed.select`). These were used only to choose the supported/qualified-sibling comparison below. A lookup of `testdata/rewrite/forms.json` and `testdata/spl2/functions.json` yielded no additional SQL case used in the comparison. No producer implementation was expanded or changed.

No frontend transfer implementation, broader repository, other milestone SDD directory or root-private oracle was inspected. These checks concern the exact consumer contracts above; they are not a re-review of accepted Tasks 1–3.

## Retained verification audit

`task-4-review-evidence/retained-evidence-audit.json` records independent SHA-256 reconciliation of all 13 retained run receipts and both raw streams for each run. All hashes, commands, reported exits and stderr sizes match `task-4-candidate-identity.json`. All retained stderr files are empty. The resolved Go binary and retained inspection-source hashes match their recorded identities.

The five current file hashes equal the whole new-file bytes reconstructed mechanically from the immutable diff, the candidate identity, all three final run source manifests, and the committed-source receipt. This verifies the final owned-source identity behind the retained GREEN results; it does not create a new all-dependency historical manifest.

| Retained evidence | Observed result and qualification |
| --- | --- |
| `01-groups-red.*` | Exit 1; compiling-stub failures cover missing linked candidates, conflict handling and refusal audits. The initial parent-before-append fixture was subsequently corrected after canonical evidence showed a relevant unknown merge; it is not treated as a valid required-success case. |
| `02-bytes-red.*` | Exit 1; actual assertion failures cover byte preservation, insertion and every invalid interval control. The unchanged-text check already passed. |
| `03-canonical-inspection.*` | Exit 0; five JSON observations retain canonical wildcard/unknown/merge/removal evidence. Their expected product diagnostic warnings are data being inspected, not tool warnings or passing regression assertions. |
| `04-affected.*` → `05-affected-green.*` | Exit 1 → 0. The initial SPL2 output incorrectly changed `sum(src)` input while leaving its consumer unchanged (`04-affected.stdout:33-34`). Final owner-stage uncertainty checks close this case; no producer expansion was made. |
| `06-audit-red.*` → `07-audit-green.*` | Exit 1 → 0. Compatible catalog co-render lost rule B (`06-audit-red.stdout:74`); final per-site contribution gathering retains both. |
| `08-closure-ownership-red.*` → `09-closure-ownership-green.*` | Exit 1 → 0. Earlier independent epoch over-rejection and returned evaluation aliasing are real REDs (`08-closure-ownership-red.stdout:3,11`). Line 19 is the invalid source-reference-present/index fixture, correctly rejected by request preparation and subsequently replaced with a valid field wildcard guard; it is not a product failure. |
| `10-unknown-audit-red.*` → `11-final-affected.*` | Exit 1 → 0. Required implicit-consumer unknown evidence lost aggregate incompleteness alongside unconditional authorization (`10-unknown-audit-red.stdout:2`); final code retains both authorization and incompleteness. The full original diagnostic payload remains in its raw stream. |
| `11-final-affected.*` | Exit 0; 58 PASS test/subtest records, zero failures, empty stderr; exact affected command includes `-count=1 -v`. |
| `12-package.*` | Exit 0; uncached full `./pkg/rewrite` package check, empty stderr. |
| `13-race.*` | Exit 0; `-race` only for `TestRewriteConflictsDeterministicConcurrent`, `-count=1`, empty stderr. |
| `14-precommit-identity.json`, `15-staged-checks.json`, `16-committed-identity.json`, `17-git-actions.json` | Retain exact tool/environment, empty gofmt output, exact staged paths and diff-check exit 0, direct parent/ancestry and source-match proof, and exact-path commit. Pre-existing untracked plan files are explicitly preserved; no globally clean checkout claim is made. |

No covered suite, race run, canonical probe, baseline or broad build was rerun. Historical RED manifests supply source hashes and observed failures, not recoverable snapshots of every precommit source revision; I did not claim an independent replay of their historical implementations.

## Uncovered review checks and their interpretation

A single overlay-only test examined whether expanding a later true proposal to an earlier unauthorized member produces source-ordered internal Groups. It used `search src=x other=z | search EventCode=1 | table src other`, a guarded src-to-user rule and an unconditional other-to-destination rule. The retained probe reported internal group first offsets 13 then 7, with the guarded group refused and the independent mapping included. Its stronger ordering assertion failed (Go exit 1, empty stderr).

Evidence is `task-4-review-evidence/ordering_probe_test.go`, `ordering-overlay.json`, `ordering-probe.json`, `ordering-probe.stdout:2-5`, and `ordering-probe.stderr`. The receipt records the exact command, five unchanged product-source hashes, overlay/probe hashes and raw stream hashes. The injected test existed only through the Go overlay; no product test file was created or changed. This was the first of two new, narrowly selected product executions in this review.

This is **not a product finding**. The approved public clause orders candidate references and Changes, while contributing RuleIDs follow request order. Public Result has no Groups array, and GroupID is an opaque relationship label with no approved monotonic numbering convention. `edits.go:161-180` still orders public changes by original coordinates, and this probe identified no nondeterminism, wrong linkage, reordered public change or candidate error. The coordinator explicitly clarified this distinction after the risk was reported. No broader follow-up probe was run, and the failed stronger assertion is retained rather than hidden or relabeled as a pass.

### Shared SQL owner comparison

At the coordinator's explicit request, one separate overlay-only comparison examined the stage-wide completeness fallback and phase-less limitation sweep in `groups.go:325-368`. It reused the accepted SELECT and qualified-owner syntax; it did not add a proof API or reinterpret a qualified binding.

| Case | Canonical and Task 4 observations |
| --- | --- |
| Supported control: `SELECT src AS kept, other AS label FROM main AS m` | Original status valid, source `src` eligible, all stage/lineage states complete, no Render requirements, direct Verify.Proven true. Task 4 emits `SELECT dst AS kept, other AS label FROM main AS m`. The probe asserts this control actually changes the source and remains proven. |
| Qualified sibling: `SELECT src AS kept, m.other AS label FROM main AS m` | Original status incomplete; `src` remains eligible, while `m.other` has an empty BindingID and `unproved_owner`. Direct Render produces the src-to-dst candidate with no requirements and Verify.Proven true. Task 4 refuses it with `linked_transition_unproved`. Canonical evaluate.After.Uncertain and project.Before.Uncertain are also true while carrying the affected `ref-0` source origins. |

The comparison command exits 0 with empty stderr. The qualified case is an observation, not a regression assertion that refusal or inclusion is required. It does **not** isolate an error in the stage-wide fallback: the existing live-uncertain-transition branch independently explains refusal. It also does not establish that the qualified sibling is canonically unrelated to the edit. Before/after Verify.Proven alone cannot waive the separate closure-uncertainty requirement. No defect is confirmed, and no producer capability expansion or less conservative policy is requested on this evidence.

Exact source, overlay, tool command/environment, observed exit and stream hashes are retained in `task-4-review-evidence/phase-probe.json`; full raw streams are `phase-probe.stdout` / `.stderr`, and the unabridged structured original evidence, selection, group reasons, direct candidate, requirements and proof for both cases are in `phase-comparison.json`. `phase_probe_test.go` and `phase-overlay.json` remain separate from the ordering probe. All five product-source hashes still match the reviewed candidate. No further probe, covered test, race run or expanded producer scan followed this comparison.

## Issues

### Critical

None.

### Important

None.

### Minor

None.

## Cannot verify here and remaining gates

- **Investigated shared-stage uncertainty limit:** `groups.go:325-368` uses a phase-specific owner match, followed by stage-wide completeness and StageID-only dynamic/unproved-owner checks. The single supported/qualified-sibling comparison above does not prove the general independence of all sibling phases, but its actual canonical evidence also contains relevant live-origin uncertainty; it therefore establishes no counterexample to the current refusal. This is a stated proof/coverage limit, not an open product finding or an extra Task 4 gate. Future independently proven cases should preserve the approved scope/identity/transition relevance policy rather than treating arbitrary stage equality as an independence proof.
- **Task 5 authoritative publication and rollback remain open.** This diff intentionally builds private candidate evidence. It does not implement apply mode, whole-request final validity/uncertainty policy, requested destination validation, authoritative-original rollback, committed flags or rollback audit rewriting. The interface above is sufficient to implement those behaviors, but their implementation is not accepted by this review.
- **Whole-branch integration, final public ordering/serialization and endpoint behavior remain later checks.** This review accepts the private evidence and existing public Change construction only. Task 5 must carry its selected and skipped alternatives, original/candidate analyses and conditions into the final Result without dropping them. Native/CLI/HTTP/legacy preservation is supported by exact scope here, not by rerunning their integration suites.
- **Proof remains static and conservative.** It does not guarantee equivalent search results or event payloads, and it does not require proving that an unobserved destination event field is absent. The approved SPL2 implicit-label and unsupported encoding refusals remain in force.
- **Historical verification boundary:** final five-file source identity is independently reconciled, while accepted predecessor state and retained commit/clean-tracked evidence qualify the unchanged dependencies. No private acceptance inputs or live Splunk/provider behavior were available or necessary for this task review.

## Assessment

**Task quality: Approved.** Linked authorization, the demonstrated uncertainty boundaries, simultaneous canonical collision proof, stable candidate closure and exact byte/audit construction meet the verified Task 4 requirements. The retained tests are tied to the reviewed source, cover the decision-bearing cases and preserve their failures and fixture corrections. Release Task 5 against this candidate while retaining the distinct whole-request apply/validation and whole-branch gates. The investigated SQL case supplies no confirmed defect and no permission to bypass canonical closure uncertainty.
