# Contract clarification received during Task 3 review

Source: coordinator `/root/milestone6_xhigh` message to this reviewer, after the initial report draft and before final submission. The coordinator identifies the wording as an existing approved design clause copied into `task-4-brief.md`, Preview/apply and Field identity sections. No new behavior or runtime finding was supplied.

> Unmatched rules, false conditions, explicit derived names outside source mapping, and source-equals-target rules are ordinary explained skips and do not automatically make the result incomplete.

The coordinator also stated that creation-only references and explicit eval, rename, SQL, and lookup aliases are not source-name replacements; derived, unavailable, and indeterminate names do not become source mappings by spelling. Task 4/5 continue to own final aggregate coverage.

Review interpretation: assess Task 3's concrete `ruleSelection.Incomplete` output separately from unimplemented downstream aggregation. A final public-result failure is not claimed. The existing explicit-eval selection test provides the relevant behavior without a new product run.
