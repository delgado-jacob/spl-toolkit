## Task 1: Strict independent request, rule, target and result contracts


Own new pkg/rewrite/model.go, request.go, target.go, diagnostics.go and their focused tests, plus initial durable testdata/rewrite/requests.json. Consume real analysis.QueryDocument and validation FieldCatalog/SchemaTarget/report types from the accepted predecessor. Produce the approved public request/rule/decoder/report types and input-error classification used by every later task; no rewrite engine or successful stub is needed yet.

1. Write table-driven TestDecodeRewriteRequest and TestDecodeRewriteBatchRequest covering required keys, duplicate keys/IDs, unknown members, UTF-8/lone-surrogate rejection, identity atom/path distinctions, kind/identity incompatibility, null versus missing, exact scalar values, source-equals-target, empty rules and malformed documents/options/targets. Include numbers around 9007199254740992 so float rounding cannot make different rules equal. Seed requests.json with independently specified accepted/rejected shapes; no generated expected snapshots.

2. Run `go test -mod=readonly ./pkg/rewrite -run 'TestDecodeRewrite|TestRewriteModel'` and record the expected missing-definition failures. Add minimal types, strict key/presence decoding using the accepted internal/jsoninput facilities, deep-copy normalization and delegation to canonical document/target normalization. Do not copy a query parser or add Python-side JSON policy. Source/target names preserve meaningful whitespace; they are never parsed as caller-supplied SPL fragments.

3. Add TestRewriteModelJSON distinguishing empty arrays from null, preview candidate-applied from committed, optional absent target/location, and rule-level unmatched evidence without a fabricated reference. Ensure direct Go requests reject the same invalid values as decoded JSON. A null literal value is accepted only in the supported literal condition union, never as an omitted required member.

4. Rerun focused tests and the accepted strict validation request regressions if a shared JSON helper changed. Commit only owned files after root execution release; pass the immutable commit to a fresh reviewer for combined spec/code review. Resolve findings before Task 2. Do not commit other workers' files.




## Accepted contract context (verbatim from approved plan/spec)

Create pkg/rewrite rather than replacing pkg/mapper. Proposed public operations and decoders are:

    func DecodeRequest(data []byte) (Request, error)
    func DecodeBatchRequest(data []byte) (BatchRequest, error)
    func DecodeRuleSet(data []byte) (RuleSet, error)
    func Rewrite(request Request) (*Result, error)
    func RewriteBatch(request BatchRequest) (*BatchResult, error)
    func IsInputError(err error) bool

Request is the strict schema_version/mode/document/rules/validation_target wrapper. BatchRequest replaces document with documents and shares mode/rules/target. RuleSet is the CLI file wrapper containing schema_version and rules only; mode/document/target are supplied by CLI flags. Require schema_version integer 1; missing mode normalizes to preview; an explicitly null/malformed mode is rejected. Empty rules are a valid no-op; empty documents are a batch input error. Validate Go-constructed values through the same preparation path as decoded requests.

An Identity contains either Name *string or Path []string, never both, serialized as name or path. Path is field-only and retains exact segments. Rule contains ID, Kind, Source, Target and optional When. Condition is a strict all/any/literal/source_reference_present union. Literal contains kind, identity, operator equals/contains and a scalar value retained without lossy float64 decoding; string, number, bool and null identities remain different. Numeric equality uses supported exact literal values, and values outside the frontend's proven scalar representation make only affected conditions unknown rather than coercing data. The strict decoder distinguishes a present null scalar from a missing value member.

ValidationTarget composes existing types: field_list uses `{kind: field_list, catalog: <existing catalog input>}` and delegates catalog decoding to DecodeFieldCatalog; json_schema/ocsf use the existing SchemaTarget wire shape unchanged and delegate to DecodeSchemaTarget. This wrapper is target selection, not a second schema format or a copy of schema logic. CandidateValidation retains exactly one complete original validation.Report or SchemaReport and its kind in Go. Only rewrite CandidateValidation JSON projects field_list.target to original {kind, identity, version}, keeping all three keys present even for empty metadata strings and omitting only fields and optional_fields. Preserve every other canonical report field/value, analysis, outcome, coverage and diagnostic, without mutating the original Go report or adding metadata/default/hash/validation logic. Canonical validation.Report serialization and the JSON Schema/OCSF branch remain unchanged. Do not flatten away report evidence or repeat the large catalog in each rewrite report.

Result contains SchemaVersion, normalized Document, Mode, Status, Coverage, OriginalText, CandidateText, Text, Committed, Changes, RuleEvaluations, OriginalAnalysis, CandidateAnalysis and optional CandidateValidation, with the approved snake_case wire keys. BatchResult has SchemaVersion, Status and ordered Reports. Coverage retains syntax/semantic/rewrite completeness, optional validation coverage and ordered reasons without confusing rewrite ambiguity with a parser failure. Changes carry outcome, reason, group/rule IDs, original/candidate reference IDs, optional real original/candidate locations, old/new text and separate candidate_applied/committed flags. Missing references use rule-level evaluations with absent location, never a fake zero-length span. Task 1 implements these snake_case fields and copied collection shapes without changing their approved meaning.

Condition is exactly one leaf/combinator. Literal leaves have fact=literal, kind field/index/source/sourcetype, identity, operator equals/contains and a scalar value. Contains requires a string, uses exact case-sensitive substring search on proven literal values and never scans source text. Reference leaves have only fact=source_reference_present, kind=field and identity. Combinators are {all:[conditions]} or {any:[conditions]} with nonempty children; there is no condition-language NOT. A literal null is present data and differs from missing value. Numeric equality retains exact precision, including 9007199254740992 versus 9007199254740993. Preserve evidence for every child even when a known false all-child or true any-child controls the result.

For example, a field reference leaf is {"fact":"source_reference_present","kind":"field","identity":{"name":"src"}}; a dotted atom {"name":"actor.name"} is different from {"path":["actor","name"]}. A field-list destination target is {"kind":"field_list","catalog":{"fields":["user"]}}. JSON Schema and OCSF targets use their existing strict SchemaTarget objects unchanged. The CLI RuleSet has only schema_version and rules; apply mode never comes from a rules file. Batch replaces document with a nonempty documents array and shares rules/mode/target; all request preparation and internal operations must complete before publishing any batch report.

Result keys include schema_version, document, mode, status, coverage, original_text, candidate_text, text, committed, changes, rule_evaluations, original_analysis, candidate_analysis and optional candidate_validation. Empty collections encode as arrays. Top-level invalid outranks incomplete outranks valid. Preview may mark a change applied/candidate_applied=true but keeps committed=false and text original. Apply publishes candidate text only after all selected-group/static/error/optional-target gates pass. A failed apply keeps candidate evidence but changes candidate-included applied audit entries to skipped/post_verification_failed, candidate_applied=true, committed=false and text original. No-op never fabricates applied entries or commits; a requested target still validates the unchanged candidate. Ambiguous changes never alter candidate text. An independent safe group can commit beside an unchanged unknown/ambiguous group with overall incomplete status; exit 3 therefore is not synonymous with no commit.

Stable uncertainty/conflict reasons include condition_unknown, unsupported_reference, dynamic_reference, conflicting_targets, overlapping_edits, binding_collision, linked_edit_unproven, target_not_renderable and post_verification_failed. Ordinary no_match, condition_false, no_change and explicit derived names outside source mapping do not alone make a result incomplete. Keep original analysis/schema diagnostics and real locations; absent references have rule-level evaluations without invented spans. Do not confuse mapped static identity with event presence, unseen-field absence or equivalent query execution.

## Strict request and rule contract

The new request has integer `schema_version: 1`, `mode` (`preview` or `apply`, omitted means preview), a canonical `document`, ordered `rules`, and an optional `validation_target`. Reuse the existing field-list, JSON Schema and OCSF target contracts through a strict tagged selection; do not invent a new catalog or schema format. Targets describe the destination query and are evaluated after proposed edits. They are not preconditions that the original source names satisfy the destination schema. Exact Go target types and adapter envelopes are selected against finished M5 APIs.

Each rule has a unique nonempty `id`, `kind`, `source`, `target`, and optional `when`. Supported kinds are `field`, `index`, `source`, `sourcetype`, `lookup`, `dataset`, and `data_model`. Source/target identities are strict tagged values: an atom has `name: <logical string>`; a statically navigated field path has `path: [<logical segment>, ...]`. Exactly one form is allowed. Paths are field-only, nonempty and contain nonempty segments. A dotted atom such as `{"name":"actor.name"}` differs from `{"path":["actor","name"]}`. A frontend must prove that it can render the requested identity in the original role; an unsupported atom/path conversion is refused. Query normalization and case rules stay frontend-owned. Configuration names are logical names, never query fragments, quoting syntax, wildcards or executable text.

Reject unknown keys/kinds/modes/versions, null required values, empty/whitespace-only names, malformed conditions, duplicate rule IDs and invalid target requests. Preserve meaningful name whitespace and case. Do not trim or parse caller names as SPL. Empty rules are a valid no-op. Duplicate semantic rules with distinct IDs are permitted and their identical edits coalesce. A rule mapping an identity to itself is an explained no-op. Rules have no priority, implicit override or cascading evaluation. Caller-injected condition contexts, legacy regex operators, arbitrary expressions and executable rule code are not accepted.

For example, the conceptual request below changes a source field only where the query establishes the source-type fact:

```json
{
  "schema_version": 1,
  "mode": "preview",
  "document": {"text": "search sourcetype=auth src=alice | table src", "language": "spl"},
  "rules": [{
    "id": "auth-user",
    "kind": "field",
    "source": {"name": "src"},
    "target": {"name": "user"},
    "when": {"fact": "literal", "kind": "sourcetype", "identity": {"name": "sourcetype"}, "operator": "equals", "value": "auth"}
  }]
}
```

The configuration's literal-fact identity selects the grammar-recognized dependency selector or event-field identity. A SQL expression field named sourcetype remains a field-kind fact; it is not reclassified as a dependency selector by spelling.

## Result and failure contracts

The versioned result contains the normalized request document, mode, `status`, coverage and reasons, `original_text`, `candidate_text`, authoritative returned `text`, `committed`, source-ordered change audit, rule evaluations, original analysis, candidate analysis and optional candidate validation. The exact serialization/type factoring must fit verified M5, while preserving these observable fields and distinctions. A result's top-level status combines query/verification errors and rewrite uncertainty using invalid, incomplete, valid precedence. Request errors remain separate API/transport errors.

Audit outcomes are `applied`, `skipped`, and `ambiguous`. In preview, applied explicitly means included in the candidate, while `committed: false` and authoritative text remains original. In successful apply, applied entries identify committed edits. In failed apply they become skipped/post_verification_failed as above. An audit entry records `candidate_applied` and `committed` separately so preview and failed-apply proposal evidence is unambiguous. Ambiguous entries never modify candidate or returned text.

No-op preview/apply retains original bytes, `committed: false`, and no fabricated applied entry. Candidate analysis may reuse equivalent original analysis when text is unchanged, but an optional destination target is still evaluated. Rule-level skip entries explain no_match/condition_false/no_change even without a source location; a location is never fabricated for an absent reference. Rejected dynamic/unsupported references retain their real locations and diagnostics.

Stable rewrite reason codes distinguish condition_unknown, unsupported_reference, dynamic_reference, conflicting_targets, overlapping_edits, binding_collision, linked_edit_unproven, target_not_renderable, and post_verification_failed. Definite verification errors yield invalid, while ambiguous or unresolved eligibility yields incomplete. Preserve the originating analysis/schema diagnostic evidence instead of replacing every failure with a generic rewrite message. Malformed requests, inaccessible files and internal failures never return an empty successful report.

## Public interfaces and batches

The public Go operations are Rewrite and RewriteBatch in the canonical rewrite package. Batch requests share prepared rules/mode/validation target and contain ordered canonical documents; each document selects its language and retains source identity. Empty batches are request errors. Invalid query content produces its ordered per-query result. Malformed rules/targets/options/document request shapes or internal failures reject the batch without publishing a partial success report. There is no cross-document transaction or filesystem mutation: individual apply results commit only their returned text. Aggregate status follows invalid, incomplete, valid precedence.

Add CLI `rewrite`, defaulting to preview; `--apply` selects apply. A local rules file supplies the strict versioned mapping definition. Reuse existing query/positional/file/stdin/batch inputs, language/profile/compatibility-version/source-ID flags, target selectors, conflict rules, `--format text|json` and requested report `--output`. Batch mode takes dialect options from documents. Report output is the only filesystem mutation; there is no in-place query editing. Text output clearly labels candidate versus returned text, committed state, skipped/ambiguous groups and validation failures. JSON is canonical report data. Write content reports before exits 0 valid, 1 invalid, 3 incomplete; usage/request/I/O/internal errors exit 2. Do not imply that exit 3 means nothing committed: callers inspect committed and audit.

Python adds rewrite and rewrite_batch methods through the actual native operation boundary, with document dialect options and canonical dictionaries. Preserve operation guards, closed-handle behavior, owned results, exception conventions and finally freeing. Update native source packaging manifests. No Python parser, condition evaluator or matcher is added.

REST adds POST `/api/v1/query/rewrite` and `/api/v1/query/rewrite/batch` with inline canonical requests, rules and targets. Existing body limits and error middleware apply. Return HTTP 200 for valid/invalid/incomplete query-level results; malformed input is HTTP 400 and internal failure is a server error. Server filesystem paths and retrieval URLs are not rule/schema sources. Existing fixed-SPL legacy mapping routes and methods remain available without silently adopting new rule precedence or syntax.

## Binding behavioral constraints (verbatim approved plan)

Only Milestone 6 is in scope. Preserve existing fixed-SPL mapper methods, configuration precedence and old native signatures. Do not change source files in place, perform whole-query conversion, beautify queries, rewrite wildcards/dynamic identifiers, infer raw-to-data-model/tstats changes, learn rules, execute searches or claim equivalent runtime results. Report output explicitly requested by a CLI caller is the only filesystem write performed by the operation.

Select language spl or spl2 explicitly through the existing canonical QueryDocument, with omitted language defaulting to spl, profile splunkd and version current. Normalize/reject options through the accepted canonical selector boundary. Maintain source text and source identity byte-for-byte, half-open UTF-8 byte offsets, Unicode columns, CRLF semantics, copied public values, deterministic IDs and array ordering. Unknown options and malformed Unicode remain request errors.

Conditions use only original, guaranteed source/flow facts. AND combines compatible guarantees, OR intersects guarantees, and query NOT establishes no positive equality. Later facts cannot authorize earlier edits; independent child queries never establish parent facts. Source-reference-present is a static query-reference fact, never event presence. The new rule language contains all/any, proven literal equals/string contains and source-reference-present, without regex, arbitrary code, condition-language NOT or caller-injected facts.

Canonical frontends own typed contexts, identity interpretation and render eligibility. Canonical transfer owns bindings, alias/implicit-output origins, inherited environments, unknown barriers, SQL logical phases and source universes. Rewrite must neither discover these by substring/regex/token guesses nor replay their transfer algorithms. The selected M6 rewrite bridge below is new implementation work; existing M5 helpers named below are real at the accepted fixed source. Final M5 closure at 237e62ac preserves those source identities; any later actual relevant change must be reconciled before it is used.

Atom/path rule identities remain distinct. On 2026-09-08 root confirmed that M6 adds only minimal fact/render/implicit-name hooks for already proven forms; do not expand canonical path binding just to force a mapping or schema match. Use the reconciled proven-form inventory below; every navigated or alias-qualified form that lacks canonical binding proof remains a located refusal.

Apply has one whole-request post-verification gate. Existing unrelated semantic incompleteness may remain without a requested target if every edited group is proven. Requested destination validation must produce a valid, complete report; invalid or incomplete validation prevents commit. An unknown/ambiguous group may remain unchanged alongside independently committed safe groups, yielding incomplete with committed true. This never permits an edit to depend on a skipped edit for safety.

## Execution authority, ownership and evidence

Root approved the complete plan and released Task1 at accepted M5 237e62ac063755559207870b45744db6b2544a17. The coordinator has applied the plan; earlier private-preparation gate text is historical. Work only in /Users/jacobdelgado/repos/spl-toolkit/.worktrees/remaining-milestones.

Own only new pkg/rewrite/model.go, request.go, target.go, diagnostics.go, focused *_test.go files for those contracts and testdata/rewrite/requests.json. The existing validation/internal packages are read-only unless you identify an unavoidable shared-helper need and receive a concrete scope ruling first. Direct-Go validation belongs in the same internal request/rule/target preparation path used by decoders and later canonical operations; do not implement Rewrite/RewriteBatch or success stubs now. Preserve result distinctions and copied collections without implementing selection, rendering or proof engines.

Read current /Users/jacobdelgado/.codex/AGENTS.md and efficient-delegation/SKILL.md; use TDD and verification-before-completion. You are not alone in the shared worktree. Preserve every other edit, the coordinator's M6 plan/ledger, all root/M5 evidence and the user original checkout. No subagents or self-dispatched reviewers. Do not inspect root aggregate/private oracles or unrelated milestone SDD directories. No broad predecessor scans/tests or generators/build-all runs for orientation.

Use installed Go with GOCACHE=/private/tmp/spl-toolkit-go-cache, GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache, GOPROXY=off, GOTOOLCHAIN=local. Observe the requested focused RED, then implement and record focused/package GREEN. Run strict validation request regressions only for actual shared-helper changes. No new dependencies/toolchain/network fallback. Preserve raw stdout/stderr, exact command, observed exit, tool/source identities, expected failures and warnings under this task's SDD directory; do not rerun commands only to regenerate summaries.

Root authorizes exact-owned-file Git commits. The default sandbox makes .git read-only: use require_escalated for the authorized exact-path git add/commit, with an explicit justification, instead of repeating the known index-lock denial. Stage only the enumerated owned files; no git add -A, reset, stash, clean, merge, push, publication or deletion. The coordinator owns plan/ledger commits separately. Self-review the owned diff before reporting.

Write the complete implementer report to the sibling task-1-report.md with implementation details, exact changed paths, RED/GREEN command/output/raw-log references, all failures/warnings, commit SHA, self-review and concerns. Return under 15 lines: DONE/DONE_WITH_CONCERNS/BLOCKED/NEEDS_CONTEXT, commits, one-line verification, concerns, report path. Raise concrete missing requirements to the coordinator rather than re-opening approved design.


## Root-approved Task1 review clarification I1

Root ruling 2026-09-08, Task1 I1: Keep CandidateValidation.FieldList *validation.Report complete and unchanged in Go. Only rewrite CandidateValidation JSON field_list.target projects original {kind, identity, version}; all three keys remain present, including empty metadata strings, and fields/optional_fields keys are absent. Preserve every other canonical report field/value/analysis/outcome/coverage/diagnostic. No new metadata/default/hash/validation logic. Canonical validation.Report serialization and JSON Schema/OCSF branch remain unchanged. Use a small rewrite-only projection without mutating the original report; retain array/union guards. Test a populated required+optional catalog with nonvacuous report evidence, exact JSON equivalence after excluding ONLY those two target keys, unchanged Go original, standalone canonical arrays still present and unchanged schema serialization.
