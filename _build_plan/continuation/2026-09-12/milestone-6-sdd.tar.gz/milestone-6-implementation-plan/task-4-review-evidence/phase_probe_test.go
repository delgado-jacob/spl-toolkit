package rewrite

import (
    "encoding/json"
    "testing"
    "github.com/delgado-jacob/spl-toolkit/pkg/analysis"
)

func TestTask4ReviewSiblingOwnerComparison(t *testing.T) {
    for _, tc := range []struct{name, query string}{
        {"supported", "SELECT src AS kept, other AS label FROM main AS m"},
        {"qualified_sibling", "SELECT src AS kept, m.other AS label FROM main AS m"},
    } {
        t.Run(tc.name, func(t *testing.T) {
            rules := []Rule{{ID:"source", Kind:"field", Source:conditionIdentity("src"), Target:conditionIdentity("dst")}}
            probes := conditionProbes(rules)
            original, err := analysis.PrepareRewrite(analysis.QueryDocument{Language:"spl2", Text:tc.query}, probes)
            if err != nil { t.Fatal(err) }
            evidence := original.Evidence()
            selection := selectRules(rules, probes, evidence)
            grouped, err := buildCandidate(original, rules, probes, selection)
            if err != nil { t.Fatal(err) }
            replacements := []analysis.RewriteReplacement{}
            for _, p := range selection.Proposals { replacements=append(replacements,analysis.RewriteReplacement{SiteID:p.SiteID,Target:canonicalIdentity(p.Target)}) }
            rendering, err := original.Render(replacements)
            if err != nil { t.Fatal(err) }
            directText, _, err := reconstructEdits(tc.query,rendering.Edits())
            if err != nil { t.Fatal(err) }
            candidate, err := analysis.PrepareRewrite(analysis.QueryDocument{Language:"spl2",Text:directText},probes)
            if err != nil { t.Fatal(err) }
            proof := original.Verify(candidate,rendering)
            raw, err := json.Marshal(struct {
                Name string
                Original analysis.RewriteEvidence
                Selection ruleSelection
                GroupedText string
                Groups []editGroup
                DirectText string
                DirectProof analysis.RewriteProof
                Requirements []analysis.RewriteRequirement
            }{tc.name,evidence,selection,grouped.Text,grouped.Groups,directText,proof,rendering.Requirements()})
            if err != nil { t.Fatal(err) }
            t.Log(string(raw))
            if tc.name=="supported" && (evidence.Analysis.Status!=analysis.Valid || !proof.Proven || grouped.Text!=directText || directText==tc.query) { t.Error("supported control is not a proven applied source mapping") }
        })
    }
}
