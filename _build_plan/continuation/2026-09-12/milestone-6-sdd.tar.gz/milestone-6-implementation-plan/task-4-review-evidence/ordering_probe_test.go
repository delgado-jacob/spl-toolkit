package rewrite

import (
    "testing"
    "github.com/delgado-jacob/spl-toolkit/pkg/analysis"
)

func TestTask4ReviewExpandedGroupSourceOrdering(t *testing.T) {
    condition := conditionLiteral("EventCode", "equals", `1`)
    got, original := candidateForTest(t, analysis.QueryDocument{Text: "search src=x other=z | search EventCode=1 | table src other"}, []Rule{
        {ID: "guarded", Kind: "field", Source: conditionIdentity("src"), Target: conditionIdentity("user"), When: &condition},
        {ID: "independent", Kind: "field", Source: conditionIdentity("other"), Target: conditionIdentity("destination")},
    })
    sites := map[string]analysis.RewriteSite{}
    for _, s := range original.Evidence().Sites { sites[s.ID] = s }
    previous := -1
    for _, g := range got.Groups {
        first := len(got.Text)
        for _, r := range g.Replacements {
            if offset := sites[r.SiteID].Location.Start.Offset; offset < first { first = offset }
        }
        t.Logf("%s first_original_offset=%d reason=%q rules=%v", g.ID, first, g.Reason, g.RuleIDs)
        if first < previous { t.Errorf("groups are not in canonical original source order: offset %d follows %d", first, previous) }
        previous = first
    }
    t.Logf("candidate=%q", got.Text)
}
