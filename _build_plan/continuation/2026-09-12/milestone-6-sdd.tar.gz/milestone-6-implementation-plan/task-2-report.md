# M6 Task 2 implementation report

Status: implemented, self-reviewed, and committed. Parent independent review remains separate. This task does not release later apply/integration gates.

## Immutable source and authority

- Worktree: `/Users/jacobdelgado/repos/spl-toolkit/.worktrees/remaining-milestones`.
- Reviewed BASE: `3a29058949b5b0000e4b90d9406764dbe11ce2ee`.
- Commit: `02c2e3217df6edef01cada136d9e623da0de7a93` (`feat(analysis): add canonical rewrite evidence and rendering bridge`). Exactly 22 owned paths; 2,389 insertions and 27 deletions.
- Original task brief SHA256: `f764b9ba70fca83fa87c1a351b496caebdb0bc6e28759887adf1500d4ddb28d4`. The coordinator preserved it as `task-2-brief-before-owner-hook.md`.
- Expanded brief SHA256 supplied by coordinator: `5c358776c156824986775b2e294adaf0e89923fea9a4f94beb470b4a565ef3c2`. Its sole new scope ruling authorizes private owner registration adjacent to existing `qualifiedCatalog` reference emissions in `dependencies.go`.
- `source.go` remains read-only and unchanged: SHA256 `c0421ed1db6a70c689396801a40d515fa2c887f273571cd704baa9af314c628b`.
- [Final source/tool manifest](task-2-evidence/final-source.json) contains all 22 content hashes, the exact Go binary path/hash/version, BASE, verified commit/tree and fixed environment. [Final Git evidence](task-2-evidence/final-git.json) records commands, raw stdout/stderr and observed exits for HEAD/tree, BASE ancestry, commit whitespace and owned/full status.
- Owned paths are clean. Existing unrelated untracked planning/CLAUDE files remain; the whole worktree is intentionally not claimed clean. No original-checkout edits, broad staging, cleanup, network/dependency changes, shared builds, private-oracle reads, subagents or self-dispatched reviewers occurred.

## Implemented source-level interface

The approved exported values live in `pkg/analysis/rewrite_evidence.go`: RewriteIdentity, RewriteFactProbe, RewriteReplacement, RewriteEvidence, RewriteSite, RewritePoint, RewriteFactEvidence, RewriteScalar, RewriteLimitation, RewriteTextEdit, RewriteRequirement, RewriteIdentityEffect, RewriteReferencePair, RewriteProof, RewriteByteRange, RewriteSession and RewriteRendering. Their declared fields match the brief. Collections returned by the facade/rendering accessors are copied; session IDs are per-call handles.

```go
func PrepareRewrite(document QueryDocument, probes []RewriteFactProbe) (*RewriteSession, error)
func (s *RewriteSession) Evidence() RewriteEvidence
func (s *RewriteSession) Render(changes []RewriteReplacement) (*RewriteRendering, error)
func (s *RewriteSession) Verify(candidate *RewriteSession, rendered *RewriteRendering) RewriteProof
func (r *RewriteRendering) Edits() []RewriteTextEdit
func (r *RewriteRendering) Requirements() []RewriteRequirement
func (r *RewriteRendering) Effects() []RewriteIdentityEffect
func LocateRewriteBytes(text string, ranges []RewriteByteRange) ([]Location, error)
```

`LocateRewriteBytes`, RewriteByteRange and the private `sourceIndex.byteLocation(start,end) (Location,bool)` live together in rewrite_evidence.go. They use one canonical sourceIndex and ordered exact Position.Offset searches, validate all UTF-8 byte boundaries/ranges without clamping, preserve Unicode/CRLF/tab/EOF semantics, and return no partial results on error. Empty range input produces a nonnil empty slice.

## Canonical ownership and facts

PrepareRewrite uses the same normalization, typed parser/lowering, semantic transfers and finalization path as Analyze. An unexported Result sidecar carries only rewrite evidence. Ordinary analysis JSON is unchanged; facade tests compare serialized ordinary Analyze with Evidence.Analysis. Full affected-package tests preserve existing M5 conformance, including atomic tstats extraction.

The bridge attaches owner information where typed operands already exist and observes actual operand/read/create/removal callbacks. Environment clone, source reset, assignment/removal, projection/aggregation and uncertainty callbacks maintain private facts. No independent field engine, public AST, new parser or analysis-to-rewrite import was added. The only dependencies.go change registers the already-proven owner at the existing qualified root/dataset emissions; extraction, dependency values, diagnostics and public coordinates remain unchanged.

- `Eligibility` is `eligible` or `ineligible`. Only exact selected source bindings and supported dependency owners become eligible. Explicit creation/rename/lookup/SQL aliases remain fixed. An ineligible derived implicit consumer can be proposed only when Render establishes its required link to an actual changed aggregate input.
- BindingID names the direct canonical definition boundary for derived reads, retaining explicit aliases independently of transitive public origins. Source bindings use SourceEpochID plus the exact canonical kind/atom. SourceEpochID follows actual independent/reset environments; clones preserve provenance.
- Sites are observed in execution order, while ReferenceID is remapped to the ordinary finalized report. Point carries real scope/stage, phase, lineage index and ordinal. SQL SELECT preparation emits one physical read; later project transitions reuse it. SPL2 lexical stage finalization remaps sidecar stage handles.
- Rendering roles distinguish expression_atom, search_field, selector_atom, rename_input, null_test, lookup_local, lookup_dual, search_value, metric_value, catalog_atom, quoted_catalog_atom, catalog_component, qualified_dataset and implicit_output. Unknown owners have a located unproved_owner limitation; navigation and dynamic_name have explicit refusal evidence. Missing canonical references retain empty ReferenceID. Typed static navigation can retain a distinct Path identity while remaining ineligible; no path binding was added.
- Every requested probe has evidence at every site. AND unions compatible guaranteed values, OR intersects them, and NOT/XOR/unproved operators establish no positive equality. Comparisons require typed static scalars and an applicable canonical source binding. Derived-alias predicates cannot masquerade as source facts. Exact rational comparison preserves large-number intersection; search Boolean words retain string semantics. Raw/interpolated/held signed/punctuation or unfamiliar scalar syntax stays unknown.
- ReferenceState is `true`, `false` or `unknown` at the original point. Fact references and supporting locations are finalized to real canonical IDs. Definition/removal/source reset invalidates affected field facts. Projection/aggregation discards removed fields' facts. Unknown filter evidence can lower LiteralComplete while retaining a separately guaranteed value. Independent child scopes do not inherit/export parent facts.

## Rendering and correspondence

Render is pure over the original session and consumes simultaneous proposals. Unknown/duplicate site handles or malformed identity values are ordinary errors. Contextual inability to encode a target becomes a located `target_not_renderable` requirement limitation. Strings, quoted identifiers, dependencies and search fields have distinct encoders; source-looking reserved search keys cannot change a field into a dependency. A logical atom containing punctuation, Unicode or `| eval pwn=1` remains a single logical identity. Atom/path identities are never silently interchanged. Original quote style is retained where the supported role permits it.

Lookup local aliases edit locally. A proven unaliased input preserves its remote column and emits a zero-width ` AS local` insertion; outputs remain fixed. SPL implicit aggregate input changes return required consumer changes and normalization effects, without synthetic AS. SPL2 changed implicit labels remain refused under the existing narrow naming contract. Datamodel components retain prefix/quote ownership, can require a linked model edit, and expose enclosing/nested normalization effects. Compatible overlaps co-render once; conflicting overlaps produce render_conflict.

Requirements are obligations, not permission: downstream rewrite must satisfy every required site's original condition and withhold any group with an unsatisfied/limited member. Render may return proposed edits together with an unsatisfied requirement; Verify refuses that rendering until all obligations are satisfied.

Verify requires original-render/session provenance, unchanged language/profile/version/source_id, and the exact candidate text implied by the private edits. It compares canonical translated references, owners, direct alias bindings, mapped origins, field membership/removal/conditionality, transitions and actual SQL phases; stages, scopes and located diagnostics/unknown owners must correspond. Typed nested catalog components and zero-width lookup insertion have explicit coordinate correspondence. It does not promise runtime equivalence. Existing unrelated incompleteness can remain when the selected group is proven, but invalid/damaged original or candidate documents do not obtain proof.

## Capabilities and corpus

CapabilityManifest now has the approved optional `Rewrite *RewriteCapabilityManifest` with `rewrite,omitempty`. The nested manifest/form shapes match the approved fields/tags. Both dialect tables enumerate implemented roles and conservative limitations; path navigation is explicitly unsupported. No new Rule.Kind was added.

`testdata/rewrite/forms.json` contains 19 durable facade cases, exercised by TestRewriteForms: all six nonfield mapping kinds, source reads/selectors, rename inputs, composite/atomic catalogs, SPL2 metric values, quote preservation and held wildcard/dynamic controls. Focused behavioral tests additionally cover facts, alias boundaries, lookup columns, null-capable roles, SQL phases, implicit requirements, malicious-looking target data, coordinate errors, snapshot isolation, provenance, unsupported owners, source epochs, whole-field-state correspondence and original JSON parity.

## Verification and all observed failures

Tool: exec_command/write_stdin. Go binary: `/opt/homebrew/Cellar/go/1.25.5/libexec/bin/go`; `go version go1.25.5 darwin/arm64`; SHA256 `11caa81dd6f1c2d6e2799f19265db880dd5a2c91b45703b4e871dbd90249f261`. Every Go invocation used:

```text
GOCACHE=/private/tmp/spl-toolkit-go-cache
GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache
GOPROXY=off
GOTOOLCHAIN=local
```

[Run manifest](task-2-evidence/runs.json) records each exact command and observed exit. Each linked log retains combined raw stdout/stderr. RED checks used evolving owned working files at BASE; they were not separately committed. The final successful content was hashed and verified unchanged in the immutable commit. Final focused output was delivered in tool chunk `344d50` (session 85531); final affected-package output in `ff520c` (session 81891). Commit tool chunk: `061f25`; final exact-head/source verification: `8fbe1b`.

Final commands, both observed exit 0 with no warnings:

```text
go test -mod=readonly ./pkg/analysis -run 'TestRewrite|TestLocateRewriteBytes|TestFinalize'
# ok analysis 0.511s

go test -mod=readonly ./pkg/analysis ./pkg/validation ./pkg/rewrite
# ok analysis 1.804s
# ok validation 9.294s
# ok rewrite 0.882s
```

| Raw log | Exit | Observation / resolution |
|---|---:|---|
| [red.log](task-2-evidence/red.log) | 1 | Absent facade types/functions; intended initial compile RED. |
| [first-behavior.log](task-2-evidence/first-behavior.log) | 1 | SPL2 RenameSourceContext classified as selector_atom. |
| [first-green.log](task-2-evidence/first-green.log) | 1 | Same rename role failure; first correction covered the parent context but not the operand context itself. |
| [expanded-red.log](task-2-evidence/expanded-red.log) | 1 | Found Boolean-routing fact loss, model normalization effect gap, and numeric-prefix decoding. Also corrected own malformed tstats query, held-wildcard test setup, and expected SQL phase label. |
| [expanded-green.log](task-2-evidence/expanded-green.log) | 0 | First expanded facade/render/fact/coordinate suite GREEN. |
| [capability-flow-red.log](task-2-evidence/capability-flow-red.log) | 1 | Missing metric_value owner and additive rewrite capabilities. |
| [capability-flow-green.log](task-2-evidence/capability-flow-green.log) | 0 | Capability and source-reset flow checks GREEN. |
| [conservative-red.log](task-2-evidence/conservative-red.log) | 1 | Unknown function owner, exact numeric intersection, and linked model requirement absent. |
| [conservative-green.log](task-2-evidence/conservative-green.log) | 1 | Unknown SPL2 function owner still stopped at an inner predicate wrapper. |
| [conservative-green-2.log](task-2-evidence/conservative-green-2.log) | 0 | Conservative owner/fact/composite checks GREEN. |
| [proof-red.log](task-2-evidence/proof-red.log) | 1 | Proof ignored retained field state after removal; search field could encode as a dependency key. |
| [proof-green.log](task-2-evidence/proof-green.log) | 0 | Field-state and grammar-category proof checks GREEN. |
| [forms-check.log](task-2-evidence/forms-check.log) | 1 | Replacing a whole qualified dataset translated its nested model endpoint to the whole replacement end. |
| [forms-green.log](task-2-evidence/forms-green.log) | 1 | Missing closing brace while implementing typed nested-component correspondence; compile failure corrected before tests. |
| [forms-green-2.log](task-2-evidence/forms-green-2.log) | 0 | All durable forms and focused tests GREEN. |
| [affected-packages.log](task-2-evidence/affected-packages.log) | 0 | Analysis, validation, rewrite packages passed before final self-review fact corrections. |
| [derived-fact-red.log](task-2-evidence/derived-fact-red.log) | 1 | Derived-alias predicate incorrectly established source evidence. |
| [final-focused.log](task-2-evidence/final-focused.log) | 0 | Derived source-fact correction GREEN. |
| [aggregate-fact-red.log](task-2-evidence/aggregate-fact-red.log) | 1 | Aggregation retained facts for discarded source fields. |
| [final-focused-2.log](task-2-evidence/final-focused-2.log) | 0 | Aggregation fact invalidation GREEN. |
| [held-values-red.log](task-2-evidence/held-values-red.log) | 1 | Interpolated search dependency incorrectly retained eligible render ownership. |
| [final-focused-3.log](task-2-evidence/final-focused-3.log) | 0 | Final focused suite GREEN: 0.511s. |
| [final-affected-packages.log](task-2-evidence/final-affected-packages.log) | 0 | Final affected packages GREEN: analysis 1.804s; validation 9.294s; rewrite 0.882s. |

Non-test read-command failures were limited to optional/local instruction-path discovery (several AGENTS.md paths did not exist), one nonexistent kernel.go read, and a nonexistent pkg/rewrite/conditions.go lookup. The actual global AGENTS.md/current efficient-delegation/TDD/verification guidance and real source files were read. These read failures made no changes and left no blocker. No dependency/toolchain/network warning, failing affected-package regression, Git index-lock retry or automatic approval rejection occurred. The authorized exact-path commit used require_escalated successfully because shared .git is read-only in the default sandbox.

## Owned changed files

- `pkg/analysis/rewrite_evidence.go`
- `pkg/analysis/rewrite_facts.go`
- `pkg/analysis/rewrite_render_spl.go`
- `pkg/analysis/rewrite_render_spl2.go`
- `pkg/analysis/rewrite_correspondence.go`
- `pkg/analysis/rewrite_evidence_test.go`
- `pkg/analysis/rewrite_forms_test.go`
- `testdata/rewrite/forms.json`
- `pkg/analysis/analyze.go`
- `pkg/analysis/references.go`
- `pkg/analysis/transfers.go`
- `pkg/analysis/flow.go`
- `pkg/analysis/commands.go`
- `pkg/analysis/dependencies.go`
- `pkg/analysis/spl2_lower.go`
- `pkg/analysis/spl2_commands.go`
- `pkg/analysis/spl2_expressions.go`
- `pkg/analysis/spl2_sql.go`
- `pkg/analysis/spl2_scopes.go`
- `pkg/analysis/model.go`
- `pkg/analysis/capabilities.go`
- `pkg/analysis/spl2_capabilities.go`

## Remaining boundaries

No implementation blocker remains. Independent review and downstream rule/group/apply work remain with the coordinator. Conservative refusals intentionally cover unproved navigation/aliases, dynamic/wildcard owners, unfamiliar scalar forms, unsupported function contexts and changed SPL2 implicit names. Correspondence is canonical static proof, not execution or provider acceptance. No broadened path semantics, schema engine, tstats extraction, module support or runtime search execution was introduced.

## Independent-review fix round 1

Implemented I1–I5 and root-included M1, self-reviewed and committed as `0b8dd62068be0638e470a532544acd1cc0a48507` (`fix(analysis): preserve conservative rewrite evidence`). This is the direct child of reviewed BASE `02c2e3217df6edef01cada136d9e623da0de7a93`, tree `5c4c577496f7826751f9102a7f093afcbe169a07`. Independent rereview remains pending; Task3 is still gated. No architecture or public API change was required.

Authority: initial fix brief SHA256 `e10dada601202dc25944406726b030751ecdfd71c027a6a486ca8231b71999b6` is retained as `task-2-fix-1-brief-before-m1.md`. Current `task-2-fix-1-brief.md`, including root's three M1 lexical controls, hashes to `65a544abe9f60dad49606bb8f22a635316c56af1ae03432ebf1035877e1079c1`. This supersedes the earlier M1 deferral for this round only. The receiving-code-review skill was read and applied; no children or self-dispatched review were used.

Exactly six authorized files changed (251 insertions, seven deletions): rewrite_correspondence.go, rewrite_evidence.go, rewrite_evidence_test.go, rewrite_facts.go, rewrite_render_spl2.go and transfers.go, all under pkg/analysis. Forms, capabilities, dependencies.go, M5 extraction and source.go did not change. Other original Task2 file hashes still match the preceding manifest. The source.go SHA256 remains `c0421ed1db6a70c689396801a40d515fa2c887f273571cd704baa9af314c628b`. Tracked and owned paths are clean; unrelated untracked planning/CLAUDE files remain preserved. The authorized escalated Git action staged and committed only the six listed paths.

### Findings and corrections

- **I1:** Typed search values use a narrow search-scalar proof which withholds exact guarantees for decoded wildcard patterns. Expression strings still use their existing exact scalar semantics. The same restriction applies to the canonical metric-index dependency slot; metric field expressions remain exact. Private dependency reference facts now require exact operand resolution and a proved owner, so pattern references cannot become exact source-reference facts. The SPL2 search owner uses the decoded proof, including an escaped asterisk. Ordinary canonical references, dependency extraction and diagnostics remain unchanged.
- **I2:** Render validates each caller-supplied target before the JSON copy can replace malformed UTF-8. Valid identities still enter a private copied rendering. Both Name and Path reject invalid initial bytes, truncated sequences and surrogate encodings; a valid Unicode replacement remains intact after caller mutation and passes correspondence.
- **I3:** The semantic null-test role specializes a render owner only when that owner is already proved. Unknown-function and unmodeled named-argument refusals survive with located limitations and no edits. Direct known null inspections still render and verify. Ordinary Analyze equality controls preserve the canonical null-inspection behavior.
- **I4:** A separate datamodel dataset operand obtains its enclosing effect from its retained decoded identity. Rendering still preserves its original token and quote boundaries. Model-only edits with both single- and double-quoted dataset operands now report `Network.All` and pass correspondence.
- **I5:** Aggregation clones private rewrite state after its grouping reads, immediately before installing the projected output environment. The first grouping read and its downstream passthrough now share SourceEpochID and BindingID, and the downstream fact retains the grouping ReferenceID. Existing canonical projection and fact invalidation remain in place.
- **M1:** Three focused mapping controls cover a same-text comment, option value and remote lookup label with a different local alias in both dialects. Only the two actual source-field sites change; expected candidate bytes and correspondence are asserted. The option case selects its source reads before the existing unsupported SPL option boundary, preserving that boundary rather than adding semantics.

### Retained reproduction and RED/GREEN evidence

Read-only review reproductions were inspected, not rerun: [probe source](task-2-review-evidence/probe.go), [probe log](task-2-review-evidence/probe.log), [probe receipt](task-2-review-evidence/probe-receipt.json); [null owner source](task-2-review-evidence/null-owner-probe.go), [null owner log](task-2-review-evidence/null-owner-probe.log), [null owner receipt](task-2-review-evidence/null-owner-probe-receipt.json); [composite/epoch source](task-2-review-evidence/composite-epoch-probe.go), [composite/epoch log](task-2-review-evidence/composite-epoch-probe.log), [composite/epoch receipt](task-2-review-evidence/composite-epoch-probe-receipt.json). Their recorded observational exit 0 means the harness completed, not that regression assertions passed. Control-character cases in the first probe were not treated as findings.

Every new test invocation used `/opt/homebrew/Cellar/go/1.25.5/libexec/bin/go` with `GOCACHE=/private/tmp/spl-toolkit-go-cache`, `GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache`, `GOPROXY=off`, `GOTOOLCHAIN=local`. Go remains `go1.25.5 darwin/arm64`, binary SHA256 `11caa81dd6f1c2d6e2799f19265db880dd5a2c91b45703b4e871dbd90249f261`. No network, dependency installation or unchanged baseline/build-all verification was performed.

The raw command arguments, working directory, environment, observed exit, elapsed time, Go hash, hashes of all tracked Go/module source, source-stability assertion, exact pre-run diff and raw combined stdout/stderr are retained for every run. Each named log below has a corresponding `-receipt.json` and `.diff` in [task-2-fix-1-evidence](task-2-fix-1-evidence/). Tests ran through the retained [run.py](task-2-fix-1-evidence/run.py) runner using subprocess argument arrays; its process exit propagates the Go exit.

| Run | Observed exit | Result and classification |
| --- | --- | --- |
| [regressions-red.log](task-2-fix-1-evidence/regressions-red.log) | 1 | Reproduced all five Important findings against BASE production with new assertions. Quoted field/dependency pattern facts and unquoted dependency reference facts failed; all 12 malformed Name/Path targets were accepted; both SPL2 null-owner cases rendered; both quoted composite effects/proofs failed; aggregate binding/epoch and grouping provenance failed. The initial SPL option control also failed because its selected grouping field crossed an existing unmodeled option boundary. That was a fixture-boundary mistake, not another runtime finding. No malformed syntax fixture was used. |
| [lexical-controls.log](task-2-fix-1-evidence/lexical-controls.log) | 0 | M1 controls all pass on unchanged BASE production after moving only the option fixture's selected reads before the existing boundary. This is coverage confirmation, not claimed RED-to-GREEN runtime repair. |
| [regressions-green.log](task-2-fix-1-evidence/regressions-green.log) | 0 | All five corrections plus M1 pass. Cross-dialect exact quoted search controls and exact expression strings containing asterisks also pass. |
| [focused-green.log](task-2-fix-1-evidence/focused-green.log) | 0 | Final focused rewrite, coordinate and finalize tests pass, including self-review additions for escaped SPL2 search wildcard, metric index pattern, and exact metric field-string comparison. Package elapsed 0.535s. |
| [affected-packages.log](task-2-fix-1-evidence/affected-packages.log) | 0 | Final affected packages pass: analysis 1.686s, validation 9.373s, rewrite 0.489s. |

The RED and initial regression GREEN command was:

```text
go test -mod=readonly ./pkg/analysis -run 'TestRewrite(SearchPatternFacts|RenderRejectsOriginalInvalidUTF8|NullInspectionOwnerProof|ModelOnlyQuotedDatasetEffect|AggregationFirstReadEpoch|LexicalMappingControls)$' -count=1
```

The initial regression GREEN additionally used `-v`. The M1-only command was `go test -mod=readonly ./pkg/analysis -run '^TestRewriteLexicalMappingControls$' -count=1 -v`. Final commands were:

```text
go test -mod=readonly ./pkg/analysis -run 'TestRewrite|TestLocateRewriteBytes|TestFinalize' -count=1
go test -mod=readonly ./pkg/analysis ./pkg/validation ./pkg/rewrite -count=1
```

The final focused and affected runs used exactly the committed source bytes; their source manifests were checked against the final working files, and the final Task2 file hashes were checked against the immutable commit. HEAD during precommit tests was BASE, so the retained diffs and content hashes identify the tested amended source; the report does not substitute the old HEAD label for that source. Every test run records source unchanged during execution. No test/compiler warnings were emitted. Bounded read-only orientation encountered an unmatched shell glob and a nonexistent exploratory `aggregates.go` path; neither was a verification result or a product failure.

### Self-review and immutable receipt

Self-review checked role-specific literal handling, positive/negative owner controls, original-byte validation before copying, decoded versus raw datamodel identity, aggregation provenance ordering, and exact expected lexical candidate bytes. Each syntax-valid session helper also compares ordinary Analyze JSON with Evidence.Analysis. Existing full analysis/validation/rewrite tests continue to cover canonical null behavior, field filtering, source reset, M5 metrics extraction and the unchanged facade contracts. No unresolved implementation concern was found; independent rereview remains the next gate.

[Precommit Git receipt](task-2-fix-1-evidence/precommit-git.json) records BASE, six-path scope, empty preexisting index and clean whitespace checks. [Commit receipt](task-2-fix-1-evidence/commit.json) records the exact add, staged-path check and `git commit --only` arguments with observed exits 0. [Final Git receipt](task-2-fix-1-evidence/final-git.json) records full SHA/tree, direct parent/ancestry, exact six committed paths, commit whitespace and final tracked/full status. [Final source manifest](task-2-fix-1-evidence/final-source.json) binds all 22 original Task2 path hashes, protected source.go, unchanged Go binary, and final tested source to `0b8dd62068be0638e470a532544acd1cc0a48507`. Original implementation and review evidence remain immutable.
