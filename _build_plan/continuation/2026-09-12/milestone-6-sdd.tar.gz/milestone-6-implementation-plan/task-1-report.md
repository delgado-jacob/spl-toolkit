# M6 Task 1 implementer report

Status: DONE. Independent review remains with the coordinator.

Commit: `f90d364c3cf1ab0bebb62c263a0183cd440076b3` — `feat(rewrite): define strict request and report contracts`.

Accepted base: `237e62ac063755559207870b45744db6b2544a17`. The base remains an ancestor, all eight owned files match their tested SHA256 values and committed content, and no owned edits remain. The pre-existing untracked `CLAUDE.md` and `_build_plan` files remain untouched. No other source, predecessor evidence, plan, ledger, native signature, dependency, or generated file was changed.

The task brief SHA256 was verified as `83d58671b1d3f078d16c6567147c920ac9bf81b7dc0e06cd928702a342da72ce`. Current global AGENTS, efficient-delegation, TDD (including writing-good-tests), and verification-before-completion instructions were read. No subagents or reviewers were dispatched.

## Changed paths

- `pkg/rewrite/model.go`: request, batch, rules, identity, condition, coverage, change, condition/rule evaluation and report types; snake_case JSON and non-null public collection serialization.
- `pkg/rewrite/request.go`: strict `DecodeRequest`, `DecodeBatchRequest`, `DecodeRuleSet`; shared direct-Go preparation; copied identities, nested conditions, exact scalar bytes, documents and rules.
- `pkg/rewrite/target.go`: existing target adapters and complete candidate validation report union.
- `pkg/rewrite/diagnostics.go`: input-error classification and stable rewrite reason codes.
- `pkg/rewrite/request_test.go`: strict request/rule/condition/batch/rules-file tables, typed preparation, ownership and durable corpus checks.
- `pkg/rewrite/target_test.go`: accepted/rejected field-list/schema/OCSF shapes, typed rejection and nested target ownership.
- `pkg/rewrite/model_test.go`: preview/candidate/commit distinctions, absent locations and target, arrays, literal null and preserved validation evidence.
- `testdata/rewrite/requests.json`: fourteen independently specified accepted/rejected request shapes; no generated expected snapshots.

## Implementation and downstream boundaries

`Identity.Name` is `*string`; `Identity.Path` is `[]string`. Exactly one is accepted. Paths are field-only and nonempty with nonblank UTF-8 segments. Meaningful whitespace and case are preserved. Names are logical data and never parsed as SPL fragments. Duplicate rule IDs are rejected; semantic duplicates with different IDs and source-equals-target are accepted for later coalescing/no-op reporting.

`Condition` uses `All`/`Any` child slices or a fact leaf with `Identity *Identity`. Its `Value` is `json.RawMessage`: nil is missing and rejected for literal leaves, while raw `null` is accepted present data. A `UseNumber` scalar check never converts to float64. The values `9007199254740992`, `9007199254740993`, strings, booleans, null and large valid JSON exponents retain their original scalar representations. Evaluation and frontend scalar representability remain later engine work. Combinator children are copied without removing any child. Unknown union keys, mixed unions, empty children, unsupported facts/operators/kinds and nonstring contains values are rejected.

`prepareRequest` and `prepareBatchRequest` are the private preparation entry points for the later public operations. They share `prepareShared`, `prepareRules`, `prepareCondition`, `prepareIdentity`, `prepareDocuments` and `prepareTarget` with the decoders. Mode omission/Go zero mode normalizes to preview; explicit malformed/empty/null JSON mode is rejected. Schema version must be integer 1. Nil Go rules normalize to an empty array. Empty batches fail and invalid later documents do not leak partial request values.

Canonical document decoding/defaulting delegates to existing `validation.DecodeDocuments`, including its canonical selector normalization; direct Go strings are checked before JSON encoding can replace malformed UTF-8. JSON source Unicode and lone surrogate validation use the existing `internal/jsoninput.ValidateUnicode`.

`ValidationTarget` has `Kind` and exactly one `Catalog *validation.FieldCatalog` or `SchemaTarget *validation.SchemaTarget`. Field-list wire data remains `{kind:"field_list",catalog:<existing catalog input>}`. JSON Schema and OCSF marshal with the existing flat SchemaTarget wire shape. The typed adapter preserves non-nil empty members so `omitempty` cannot hide mixed unions. Existing `DecodeFieldCatalog` and `DecodeSchemaTarget` own policy, normalization and nested decoding. No shared helper changed.

Coordinator ruling confirmed during implementation: Task 1 reuses `DecodeSchemaTarget` structural behavior and does not duplicate semantic compilation. Thus structurally accepted raw schema/catalog data can still fail canonical semantic validation later. Task 5 must complete that canonical target preparation before publishing any result or partial batch. No empty-query semantic-validation proxy, parser copy, rewrite engine, public operation stub or successful placeholder was introduced.

`CandidateValidation` holds `Kind` and exactly one original `FieldList *validation.Report` or `Schema *validation.SchemaReport`; its JSON marshal rejects invalid unions. Original diagnostics, locations and schema evidence stay inside the original report. The request's full ValidationTarget is not copied into every rewrite Result.

Changes retain group/rule IDs, original/candidate reference ID arrays, optional original/candidate real locations, text and separate `candidate_applied`/`committed`. Rule-level unmatched evidence has no fabricated location. `ConditionEvaluation` keeps state, reason, real reference IDs and ordered children. Coverage has syntax/semantic/rewrite completeness, ordered reasons and optional original `validation.Coverage` under `validation`. Selection, evaluation, status reduction, render eligibility and commit gates are deliberately not implemented in this contract task.

## TDD and verification

Working directory for all commands: `/Users/jacobdelgado/repos/spl-toolkit/.worktrees/remaining-milestones`.

Go environment for every test command:

```text
GOCACHE=/private/tmp/spl-toolkit-go-cache
GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache
GOPROXY=off
GOTOOLCHAIN=local
```

Installed tool: `/opt/homebrew/bin/go`; `go version go1.25.5 darwin/arm64`. No downloads, dependencies, toolchains, network fallback, broad predecessor suite, generators or build-all runs were used.

1. RED, before production definitions: `go test -mod=readonly ./pkg/rewrite -run 'TestDecodeRewrite|TestRewriteModel'`. Observed Go exit **1**. Expected missing symbols: Result, Preview, Change, RuleEvaluation, ReasonNoMatch, BatchResult, Coverage, and the compiler's too-many-errors cutoff. Full output: `task-1-evidence/01-red.log`; exact argv/environment/exit: `01-red.json`. The Python logging wrapper exited 0 after recording the actual Go exit; this is not represented as test success.
2. GREEN after implementation and `gofmt -w` on all seven owned Go files: same focused command. Observed Go exit **0**, output `ok github.com/delgado-jacob/spl-toolkit/pkg/rewrite 0.377s`. Full output/metadata: `task-1-evidence/02-focused.log` and `02-focused.json`.
3. Fresh package GREEN: `go test -mod=readonly ./pkg/rewrite -count=1`. Observed Go exit **0**, output `ok github.com/delgado-jacob/spl-toolkit/pkg/rewrite 0.359s`. Full output/metadata: `task-1-evidence/05-package-green.log` and `05-package-green.json`. This includes normal Go test vet checks.
4. Per-new-file `git diff --no-index --check -- /dev/null <owned path>` returned **1** for added-file differences with empty output for each path; these are expected diff status codes, not silently treated as zero. Exact commands, exits and output: `task-1-evidence/03-diff-check.json`. The actual staged `git diff --cached --check` returned **0**, empty output (`07-staged-check.log/.json`).
5. Tool/source hashes are in `task-1-evidence/04-source-identity.json`; the complete reviewed staged diff is `06-staged-diff.log` with command/exit in `06-staged-diff.json`.
6. Authorized exact-file `git add` and `git commit --only` both returned **0** through `require_escalated`. Exact argv and transcribed raw observed outputs are in `09-git-mutations.json`, with original tool chunk IDs. No rejected escalation, index-lock failure, destructive command, hook bypass, merge, push or publication occurred.
7. Final HEAD, commit stat, owned diff, complete status, accepted-base ancestry and tested-file hash equality are recorded in `task-1-evidence/08-final-checks.json`. All commands returned **0**, owned diff is empty and source hashes match the fresh passing package check.

The only test failure was the specified RED missing-definition failure. There were no compiler/test warnings or post-implementation failures. Strict validation request regressions were not run because no shared helper changed, as the brief prescribes.

## Self-review and concerns

Reviewed the owned staged diff against the brief: strict presence/duplicate/unknown-key gates at each wrapper and nested union; canonical document/target reuse; raw Unicode and exact scalar preservation; source-equals-target/empty rules/duplicate semantic rules acceptance; whole-batch preparation; copied nested request storage; original validation evidence; absent unmatched locations; preview candidate versus committed data; and snake_case non-null collection shapes. The staged change is exactly the eight authorized paths, 1,459 added lines. No unrelated cleanup or feature was included.

No unresolved Task 1 implementation concern was found. Independent spec/code review is still required before Task 2. The structural-versus-semantic target boundary above is an explicit downstream integration obligation, not a claimed completed validation engine. Broader transport, engine, behavioral, native, CLI, REST and Python verification belongs to later tasks.

## Review fix round 1 — I1 catalog projection

Status: DONE for the released fix; scoped independent re-review remains with the coordinator. This section supersedes the initial self-review conclusion about complete catalog omission: independent review correctly found that the initial field-list CandidateValidation still repeated the catalog through its embedded canonical report.

Fix base: `f90d364c3cf1ab0bebb62c263a0183cd440076b3`.

Immutable fix commit: `3a29058949b5b0000e4b90d9406764dbe11ce2ee` — `fix(rewrite): omit catalog arrays from candidate reports`.

Read the full independent `task-1-review.md`, updated `task-1-brief.md`, original implementer report and `task-1-fix-1-brief.md`. The fix brief SHA256 matched `8cd7df93ca833edffe395925e51c56a6192a746b10d9ff6d0d26198bf0fe8ca5`. Applied the receiving-code-review skill in addition to the existing TDD and verification instructions. The first combined read exceeded output capacity; the truncated updated-brief span was recovered with a bounded read. No requirements remained unread.

Root's exact I1 ruling was implemented without additional metadata or validation logic. `CandidateValidation.FieldList` still holds the complete original `*validation.Report`. Its rewrite-only JSON serialization now embeds that report with a shallow target override containing the original `kind`, `identity` and `version`, all three explicitly serialized even when empty. Only `fields` and `optional_fields` are omitted. The original report is never mutated. Canonical `validation.Report` serialization and both schema branches are unchanged, as are union guards and existing collection behavior.

The fix changed exactly two authorized source paths:

- `pkg/rewrite/target.go`: 20 added lines / 1 removed line for the comment and small field-list-only projection. All other report properties flow directly from the existing canonical report.
- `pkg/rewrite/model_test.go`: 113 added lines covering the populated-catalog regression, empty metadata presence, complete report equivalence, immutability, standalone canonical serialization, and unchanged JSON Schema/OCSF report bytes.

`pkg/rewrite/target_test.go` needed no change. No canonical/shared, request decoder, engine, plan, ledger, dependency or other source was modified. No subagents or reviewers were dispatched.

`TestRewriteModelCandidateFieldListProjection` uses the real canonical validator on `search user=alice | table user extra missing`, with required `user` and optional `extra` catalog entries. It requires an invalid report with populated outcomes, diagnostics and analysis references before checking the projection, so the comparison cannot pass on an empty report. Both populated and empty original metadata cases assert the exact three-key target. It compares all JSON values against canonical serialization after excluding only the two catalog keys, checks the unchanged Go report against an independent deep snapshot, checks the preserved report pointer, and verifies standalone canonical serialization still has both arrays before and after rewrite marshaling. `TestRewriteModelCandidateSchemaSerialization` checks byte-identical canonical schema payloads for JSON Schema and OCSF, including populated evidence and an int64 UID of `9007199254740993`.

### Fix verification and retained evidence

All test commands ran in the same approved worktree and with the four Go environment values above. Tool identity remained `/opt/homebrew/bin/go`, `go version go1.25.5 darwin/arm64`.

1. Narrow RED, before the production fix: `go test -mod=readonly ./pkg/rewrite -run '^TestRewriteModelCandidateFieldListProjection$' -count=1`. Observed Go exit **1**, 0.365s. Both subtests reported the expected repeated `target.fields` and `target.optional_fields`, extra target keys and resulting equivalence mismatch. No other assertion failed. Full raw output: `task-1-evidence/fix-1-01-red.log`; command, environment, actual Go exit and pre-fix source/test hashes: `fix-1-01-red.json`. The tool display truncated the long populated reports; the full log was retained and all failure lines were recovered in a bounded display without rerunning the test.
2. Affected GREEN: `go test -mod=readonly ./pkg/rewrite -run TestRewriteModelCandidate -count=1`. Observed Go exit **0**, output `ok github.com/delgado-jacob/spl-toolkit/pkg/rewrite 0.346s`. This includes existing union/evidence tests and both new tests. Full raw output and command/environment/exit/source hashes: `fix-1-02-affected-green.log` and `fix-1-02-affected-green.json`.
3. Fresh full package GREEN, once after the fix: `go test -mod=readonly ./pkg/rewrite -count=1`. Observed Go exit **0**, output `ok github.com/delgado-jacob/spl-toolkit/pkg/rewrite 0.261s`. Full raw output and exact metadata: `fix-1-04-package-green.log` and `fix-1-04-package-green.json`. No warnings or unexpected failures occurred. The Python capture wrappers returned 0 after recording the separate actual Go exit; the RED is not represented as a success.
4. Self-review inspected the complete two-file diff against I1. `git diff --check` returned **0**, empty output; the pre-stage index was empty. Diff, check commands/output/exits and tool identity are retained in `fix-1-03-self-review.json`. The production change preserves complete report embedding, copies metadata only, omits no other evidence and touches no canonical serialization. Existing invalid union guards were exercised by the affected GREEN.
5. Exact-path authorized `git add` and `git commit --only` both returned **0** through `require_escalated`; staged `git diff --cached --check` returned **0**. Exact argv, observed outputs and original tool chunk IDs are retained in `fix-1-06-git-mutations.json`. The commit contains exactly these two paths, 132 insertions and 1 deletion.
6. `fix-1-05-final-checks.json` records the immutable HEAD, commit stat, empty owned diff, complete status, fix-base ancestry and equality of committed working files to fresh-GREEN SHA256 values. All Git checks returned **0** and the tested hashes match. Only the same pre-existing untracked CLAUDE/build-plan paths remain.

No remaining I1 implementation concern was found. Scoped independent re-review is still required. The previously documented downstream semantic-target preparation obligation remains unchanged.
