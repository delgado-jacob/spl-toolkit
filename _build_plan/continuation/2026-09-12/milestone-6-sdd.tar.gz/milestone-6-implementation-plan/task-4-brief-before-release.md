## Task 4: Linked edits, conflict closure and byte-preserving preview candidate


Own pkg/rewrite/groups.go, edits.go, their tests and durable testdata/rewrite/edits.json. Consume proposals/evidence from Tasks 2–3 and produce a candidate plus precise proposed-edit audit. This task does not publish apply text or bypass the later verification gate. An edit group is the smallest connected set that must change together to preserve a proven source/implicit-name relationship.

1. Add TestRewriteLinkedAliases asserting src-to-user changes `search src=x | rename src AS owner | table owner` to `search user=x | rename user AS owner | table owner`. owner remains explicit and unchanged; an owner source rule cannot rename it. Add implicit sum(src) and exact downstream implicit-name references using valid dialect quoting from forms.json; either all canonically linked edits occur or the whole group is skipped. Explicit AS names do not change.

2. Build linked groups from canonical identities and origin/transition evidence. Require condition authorization at each required edit's own flow point. A later true rule cannot authorize an earlier false/unknown occurrence; refuse incomplete linkage rather than split one source identity into differently named consumers. Wildcards, dynamic consumers or a relevant unknown merge make the affected group unproven. Unrelated scopes remain independent.

3. Add TestRewriteConflicts for two different true targets, identical replacements with multiple IDs, overlapping spans, target capture by an explicit alias, distinct observed live identities collapsing onto one target, original-identity swaps/chains and a skipped edit that another group needed for safety. Resolve conflicts deterministically to a stable surviving set. Coalesce identical edits, reject connected contradictory groups, and never choose first/last rule or search for a maximum-count rewrite set. Do not require proof that unreferenced event fields are absent.

4. Add TestRewriteBytePreservationAndLocations. Apply validated disjoint original intervals in a single forward reconstruction; check old text against the original slice, copy untouched bytes exactly and compute cumulative byte-offset translation. Batch the resulting half-open replacement ranges with the exact candidate text through `analysis.LocateRewriteBytes`; use its returned Locations for candidate audit positions. The rewrite package does not rescan runes/CRLF to compute lines or columns, and does not pass byte offsets to the private rune-indexed sourceIndex.location method. Test CRLF, tabs, comments containing pipes, quotes, Unicode before/inside edits, multibyte and newline-containing logical-name rendering, arbitrary edit spans without a canonical reference and zero-width insertions. Unchanged text, including literal `<EOF>` text, is not cleaned up.

5. Audit original/candidate text, location, reference IDs when resolvable, group/rule IDs and proposed inclusion. Ambiguous entries never enter the candidate. No_match/condition_false/no_change are ordinary rule-level skips; unknown eligibility adds incomplete evidence. Run `go test -mod=readonly ./pkg/rewrite -run 'TestRewriteLinked|TestRewriteConflicts|TestRewriteByte'`, commit/review, and retain counterexamples as durable fixtures rather than loose temporary files.



## Accepted semantic context (verbatim design)

## Field identity, aliases and linked changes

Match exact canonical identity and kind, not every token with the same spelling. Ordinary source-bound reads and proven passthrough source selectors are eligible. Creation-only references and explicitly created eval, rename, SQL and lookup aliases are not source-name replacements. Exact removal/exclusion operands are eligible only when the kernel proves which source identity they select; their lack of a schema read obligation is not itself a rewrite decision. Derived, unavailable or indeterminate bindings do not become source mappings merely because names match a rule.

For `rename src AS alias | table alias`, src-to-dst edits the rename input to dst and keeps alias and its downstream reads. An alias-to-other source rule cannot rename that derived alias. For `eval alias=src | table alias`, only src changes. Scope-specific identity permits the same spelling to map in an independent source subquery while staying unchanged as a parent-derived field.

An input replacement may alter a generated implicit output name, for example sum(src). Use canonical origin/lineage and frontend naming evidence to assemble a linked edit group that changes the source input and every affected exact downstream implicit-name read. Explicit user aliases stay unchanged. If naming, consumers, projection, qualification or scope linkage cannot be proven, skip the entire group. Do not silently add AS, manufacture aliases, or guess implicit names by formatting strings.

A group's proof must include its affected statically modeled uses and transitions. A relevant wildcard, dynamic reference, unknown command effect or unmodeled merge that prevents this closure makes the group ineligible. Unrelated incomplete scopes do not automatically taint an independently proven group. No unseen dynamic name or macro body is rewritten.

Where preserving one source identity requires linked edits at several flow points, every required edit must be independently authorized by its rule condition at that point. A later true condition cannot backfill an earlier false or unknown condition. If such a group cannot be completed without an unauthorized edit, skip the whole group as linked_edit_unproven. Do not silently split one proven identity into differently named consumers merely to publish a partial mapping.

## Dependency references and supported forms

Index/source/sourcetype mappings edit only exact grammar-established dependency values. Identically spelled event fields, literals, comments and options are not dependency matches. Lookup mappings edit exact catalog dependency identities and preserve known local-field/catalog-column distinctions. Dataset and data-model mappings edit supported exact dependency identities, including qualified forms only when the frontend proves their structure and replacement interval.

Mapping a model or dataset does not infer a corresponding field schema, alias or raw-to-tstats conversion. Explicit related mappings can participate in one proven edit group where canonical evidence establishes a coupling. An independently supplied qualified field mapping must retain its atom/path/alias distinction. Unsupported tstats/metrics/join semantics cannot be upgraded merely because a dependency token is recognized. The capability report states exact rewrite-supported roles and limitations separately from parse support and full command semantic coverage.

Macros, dynamically computed datasets/fields, wildcard names, unresolved aliases and damaged contexts are refused with located reasons. A target is encoded as a single proven identity in the original grammatical role; punctuation in caller text never becomes a pipeline command or an unquoted query fragment.

## Conflict and collision policy

Build candidates from original identities simultaneously. Source a-to-b and b-to-c do not become a-to-c. Coalesce identical replacements at the same interval with all contributing rule IDs. Two true rules proposing different replacements, incompatible overlapping intervals, or required linked edits that disagree make the connected edit group ambiguous and unchanged. Disjoint safe groups can proceed. Audit conflicting alternatives and their rule evidence rather than choosing request order or legacy priority.

Check static capture and collapse: distinct statically live source/derived identities may not silently become one binding; an existing alias must not capture a newly renamed source read. Swaps and chains are accepted only if canonical before/after relationships under the simultaneous mapping prove the intended distinct identities remain correctly bound. Name equality alone is not a proof of a safe swap.

This is an observed static collision boundary. It does not require proving that unreferenced event fields are absent, checking event payloads, or proving equivalent search results. Ordinary src-to-dst source migration is not blocked just because an open source could contain an unseen dst field. Report these limits without presenting a runtime-equivalence guarantee.

A dependent group's exclusion can change whether another proposed group is safe. Resolve conflict groups deterministically to a stable candidate, and verify the final selected set together. A surviving group cannot rely on a skipped edit to prevent capture. This is conflict closure over canonical identities, not a search for an optimally large subset of rewrites.

## Source preservation and audit coordinates

Construct the candidate from validated, nonoverlapping edit intervals over the original bytes or their canonical token equivalents. Preserve every byte outside those intervals, including comments, spaces, tabs, line breaks, CRLF, case and unaffected quote spelling. Within an edited identifier retain its existing quote style when the selected dialect and role can encode the target correctly; otherwise use the minimal required proven quoting. Escape the target through that frontend's rules. Never normalize the whole query or strip an EOF-looking user suffix.

Audit every edit's exact original and replacement text, original location, candidate location when included, original reference IDs, candidate reference IDs when resolved, rule IDs, group ID and reason. Locations use existing half-open UTF-8 byte offsets, one-based Unicode columns and CRLF behavior. Compute translation through the ordered edit map; downstream locations after multibyte or multiline replacements must point into the actual candidate. Do not compare original/candidate offsets directly or carry stale original IDs into candidate analysis.

Ordering is deterministic: rules preserve request order; candidate references and changes follow canonical source ordering with stable tie-breakers; contributing rule IDs follow request order; diagnostics follow the canonical location/code/message order. Empty collections serialize as arrays, never null. State is call-local, inputs are copied as needed, and concurrent identical calls return equivalent JSON values.

## Preview, apply and post-verification

Preview builds the candidate from independently eligible, unambiguous groups, then reparses and reanalyzes it in the same document language/profile/version. If requested, validate that destination candidate through the existing canonical field-list or schema validator. Retain original analysis, candidate analysis and validation evidence. Do not apply from syntax-damaged original input where exact token/binding evidence cannot be established; the conservative default for original syntax errors is no edits and an invalid report with original bytes retained.

Verification is stronger than parser success. Map original reference identities and locations through the edit map, and prove preservation of the intended static binding/lineage relationships under the selected mapping. Check changed implicit outputs, capture, scope boundaries and SQL phases. New uncertainty is assessed by affected scopes, identities, transitions and translated source evidence, never by diagnostic counts alone. An uncertainty barrier touching an edited group fails its proof.

Apply uses one whole-request verification gate after safe-group selection. It publishes the candidate only if candidate parsing succeeds, static relationship checks succeed, no new relevant uncertainty is introduced, and candidate analysis has no definite errors. Without requested schema validation, unrelated preexisting semantic incompleteness may remain when every edited group is independently proven. A supplied validation target is a strict additional gate: its resulting validation report must be conclusive and error-free. Invalid or incomplete requested validation prevents commit, including incomplete analysis retained in that validation report.

If any gate fails, returned authoritative text is the original query, `committed` is false, and candidate text survives solely as preview evidence. Every proposed edit is marked not committed; apply audit entries that were included in the candidate become skipped with `post_verification_failed` and retain their proposed replacement/candidate coordinates. No automatic rollback subset search or second attempt publishes only some failed-request edits.

Independent safe groups may commit while ambiguous/unknown groups remain unchanged if the resulting candidate passes the gate. Such a result is explicitly incomplete with `committed: true`. A syntactically and semantically valid candidate does not erase unknown mapping eligibility. Unmatched rules, false conditions, explicit derived names outside source mapping, and source-equals-target rules are ordinary explained skips and do not automatically make the result incomplete.


## Binding behavioral constraints (verbatim approved plan)

Only Milestone 6 is in scope. Preserve existing fixed-SPL mapper methods, configuration precedence and old native signatures. Do not change source files in place, perform whole-query conversion, beautify queries, rewrite wildcards/dynamic identifiers, infer raw-to-data-model/tstats changes, learn rules, execute searches or claim equivalent runtime results. Report output explicitly requested by a CLI caller is the only filesystem write performed by the operation.

Select language spl or spl2 explicitly through the existing canonical QueryDocument, with omitted language defaulting to spl, profile splunkd and version current. Normalize/reject options through the accepted canonical selector boundary. Maintain source text and source identity byte-for-byte, half-open UTF-8 byte offsets, Unicode columns, CRLF semantics, copied public values, deterministic IDs and array ordering. Unknown options and malformed Unicode remain request errors.

Conditions use only original, guaranteed source/flow facts. AND combines compatible guarantees, OR intersects guarantees, and query NOT establishes no positive equality. Later facts cannot authorize earlier edits; independent child queries never establish parent facts. Source-reference-present is a static query-reference fact, never event presence. The new rule language contains all/any, proven literal equals/string contains and source-reference-present, without regex, arbitrary code, condition-language NOT or caller-injected facts.

Canonical frontends own typed contexts, identity interpretation and render eligibility. Canonical transfer owns bindings, alias/implicit-output origins, inherited environments, unknown barriers, SQL logical phases and source universes. Rewrite must neither discover these by substring/regex/token guesses nor replay their transfer algorithms. The selected M6 rewrite bridge below is new implementation work; existing M5 helpers named below are real at the accepted fixed source. Final M5 closure at 237e62ac preserves those source identities; any later actual relevant change must be reconciled before it is used.

Atom/path rule identities remain distinct. On 2026-09-08 root confirmed that M6 adds only minimal fact/render/implicit-name hooks for already proven forms; do not expand canonical path binding just to force a mapping or schema match. Use the reconciled proven-form inventory below; every navigated or alias-qualified form that lacks canonical binding proof remains a located refusal.

Apply has one whole-request post-verification gate. Existing unrelated semantic incompleteness may remain without a requested target if every edited group is proven. Requested destination validation must produce a valid, complete report; invalid or incomplete validation prevents commit. An unknown/ambiguous group may remain unchanged alongside independently committed safe groups, yielding incomplete with committed true. This never permits an edit to depend on a skipped edit for safety.

Prepared consumer brief only. Do not dispatch or execute until all preceding tasks receive immutable review approval. The coordinator will add actual accepted predecessor interfaces, exact BASE and bounded execution/evidence instructions at dispatch. No source/architecture assumption here replaces the accepted canonical bridge.

## Execution and evidence boundary

This brief is not released until its accepted predecessor and immutable BASE are supplied by the coordinator. Work only in /Users/jacobdelgado/repos/spl-toolkit/.worktrees/remaining-milestones. Own only the task files explicitly listed above and this task report/evidence; request a concrete ownership ruling for any additional necessary source file before editing it. You are not alone: preserve other source changes, coordinator living plan/ledger, root aggregate and private acceptance oracles, all M5 artifacts/history and the user's original checkout. Never inspect other milestone SDD directories or private root acceptance inputs. No subagents, self-dispatched reviewer, branch/worktree creation, merge, push, publication, cleanup or downstream task implementation.

Read current /Users/jacobdelgado/.codex/AGENTS.md and /Users/jacobdelgado/.codex/skills/efficient-delegation/SKILL.md. Use TDD and verification-before-completion. Do not reread the full plan or redo accepted design/preflight/baseline research. Inspect only accepted producer interfaces and canonical source needed for this task. Capture meaningful RED, affected GREEN and appropriate package verification with exact source/tool identities, raw stdout/stderr and observed exit status, including every relevant failure/warning. Do not rerun tests merely to regenerate a summary.

Use GOCACHE=/private/tmp/spl-toolkit-go-cache, GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache, GOPROXY=off and GOTOOLCHAIN=local with /opt/homebrew/bin/go. No dependency/toolchain/network changes or shared build-all for orientation. Root authorizes exact-owned-file commits; use require_escalated for exact-path git add/commit because the shared .git is read-only in the default sandbox. Do not repeat the known index-lock denial or use add -A/reset/stash/clean. Self-review and commit only owned files. Record the immutable commit, tested hashes, implementation, test commands/results, raw evidence and concerns in the task report; return concise status/commits/test outcome/concerns/report path.

## Prepared concrete consumer handoff — review/release pending

This addendum records the current Task3 candidate interface for reconciliation; it does not release Task4. Task3 candidate is 3892f6dc8db7e8fb3e1de78d443704fb56b696ef and independent review is still pending. The coordinator must replace this paragraph with accepted predecessor HEAD and review identity before dispatch.

Exact product ownership is pkg/rewrite/groups.go, pkg/rewrite/groups_test.go, pkg/rewrite/edits.go, pkg/rewrite/edits_test.go and testdata/rewrite/edits.json. Task1's accepted public model, request preparation and diagnostics remain unchanged inputs. Consume those Result/Change/RuleEvaluation/ConditionEvaluation/Identity types; do not invent another public wire model or export a provisional engine API. You may choose the smallest private candidate/group helper values needed by Task5 and record their exact signatures in the completed report.

Task3 report records these package-private interfaces (verify against its eventual accepted source as needed):

```go
conditionProbes(rules []Rule) []analysis.RewriteFactProbe
evaluateConditionAtSite(condition *Condition, probes []analysis.RewriteFactProbe, site analysis.RewriteSite) ConditionEvaluation
selectRules(rules []Rule, probes []analysis.RewriteFactProbe, evidence analysis.RewriteEvidence) ruleSelection
```

ruleSelection carries Evaluations, Proposals and Incomplete. Each ruleProposal carries SiteID, Target, RuleIDs and EvidenceReferenceIDs. Collect probes from Task1-prepared rules before preparing the original canonical session. Selection uses only that session's original Evidence. It coalesces equal site/target proposals, preserving every originating rule ID in request order; unequal targets remain alternatives for your conflict closure. Pure condition evaluation is independent of source matching and eligibility so you can evaluate every originating rule at each canonically required member's original point. Directly evaluating an ineligible linked site does not make it an initial source match. Keep canonical source ordering and contributing IDs in request order; never make order act as precedence.

The canonical bridge in pkg/analysis/rewrite_evidence.go, rewrite_facts.go, rewrite_render_spl.go, rewrite_render_spl2.go and rewrite_correspondence.go is already implemented and reviewed. Use PrepareRewrite, Evidence, Render, rendering Edits/Requirements/Effects, Verify and LocateRewriteBytes with their actual exported values. Do not infer owners, implicit names, binding/source epochs, path identities, facts or correspondence by parsing text in rewrite. source.go is read-only; the approved byte-range locator owns all candidate line/column conversion. Read only needed accepted declarations/call contracts. If a concrete missing canonical proof appears, report the precise source case and needed owner boundary before changing analysis files; no private shadow algorithm or unapproved path expansion.

The producer completeness/O1 follow-up is accepted at 5745041676c8d6cddfb7b769c2aaa2630d3ab8a2 (task-2-producer-followup-review.md SHA f07bd46f515508630b4a2342c043d877cac2ed2f6501d48294a3ba83bebffcb6). Complete supported absence is false query-fact evidence, unknown scalar/pattern/owner/binding/scope remains unknown, and independently guaranteed values survive other incomplete literal evidence. Metric field Booleans are typed Booleans; quoted spellings remain strings. Never coerce a producer value or reinterpret missing evidence.

Task5 will consume your final candidate and group/edit audit to perform whole-request verification and optional destination validation. Task4 does not publish authoritative apply text, wrap standalone HTTP/native/CLI endpoints, compile targets or create an alternate verification policy. Preserve failed/unselected alternatives for audit, and record the actual private candidate construction interface, group state/reasons, correspondence inputs and test seams in task-4-report.md for that consumer.
