# Task2 independent combined review

Immutable BASE is 3a29058949b5b0000e4b90d9406764dbe11ce2ee; HEAD is 02c2e3217df6edef01cada136d9e623da0de7a93. The complete writer report has been received and source/evidence identities independently reconciled. A fresh reviewer must receive current task-2-brief.md, task-2-report.md, the complete immutable review package and these binding constraints. Root is waiting for reviewed Task5; this review must not access root oracles or other milestone workspaces. Read current global AGENTS/efficient-delegation. Explicit gpt-6-astra/xhigh/default, isolated fork none; role has no fixed lower override. No children.

Read-only product/index/HEAD/branch. Own only task-2-review.md and narrowly justified review evidence beneath this SDD directory. Do not rerun already-covered tests; inspect retained raw logs/exits and source identities. Review both spec compliance and code quality, independently; classify concrete gaps with file/line evidence. Use the template process below. Root accepted coordinate helper and private qualifiedCatalog owner registration are requirements, not a reason to waive findings. Every cannot-verify item needs an exact bounded pointer for coordinator reconciliation.

## Binding constraints

Only Milestone 6 is in scope. Preserve existing fixed-SPL mapper methods, configuration precedence and old native signatures. Do not change source files in place, perform whole-query conversion, beautify queries, rewrite wildcards/dynamic identifiers, infer raw-to-data-model/tstats changes, learn rules, execute searches or claim equivalent runtime results. Report output explicitly requested by a CLI caller is the only filesystem write performed by the operation.

Select language spl or spl2 explicitly through the existing canonical QueryDocument, with omitted language defaulting to spl, profile splunkd and version current. Normalize/reject options through the accepted canonical selector boundary. Maintain source text and source identity byte-for-byte, half-open UTF-8 byte offsets, Unicode columns, CRLF semantics, copied public values, deterministic IDs and array ordering. Unknown options and malformed Unicode remain request errors.

Conditions use only original, guaranteed source/flow facts. AND combines compatible guarantees, OR intersects guarantees, and query NOT establishes no positive equality. Later facts cannot authorize earlier edits; independent child queries never establish parent facts. Source-reference-present is a static query-reference fact, never event presence. The new rule language contains all/any, proven literal equals/string contains and source-reference-present, without regex, arbitrary code, condition-language NOT or caller-injected facts.

Canonical frontends own typed contexts, identity interpretation and render eligibility. Canonical transfer owns bindings, alias/implicit-output origins, inherited environments, unknown barriers, SQL logical phases and source universes. Rewrite must neither discover these by substring/regex/token guesses nor replay their transfer algorithms. The selected M6 rewrite bridge below is new implementation work; existing M5 helpers named below are real at the accepted fixed source. Final M5 closure at 237e62ac preserves those source identities; any later actual relevant change must be reconciled before it is used.

Atom/path rule identities remain distinct. On 2026-09-08 root confirmed that M6 adds only minimal fact/render/implicit-name hooks for already proven forms; do not expand canonical path binding just to force a mapping or schema match. Use the reconciled proven-form inventory below; every navigated or alias-qualified form that lacks canonical binding proof remains a located refusal.

Apply has one whole-request post-verification gate. Existing unrelated semantic incompleteness may remain without a requested target if every edited group is proven. Requested destination validation must produce a valid, complete report; invalid or incomplete validation prevents commit. An unknown/ambiguous group may remain unchanged alongside independently committed safe groups, yielding incomplete with committed true. This never permits an edit to depend on a skipped edit for safety.




## Exact review inputs and output

All paths below are in this directory unless absolute. Requirements: task-2-brief.md. Implementation/evidence report: task-2-report.md. Immutable full diff: review-3a29058..02c2e32.diff (131962 bytes). Coordinator source reconciliation: task-2-candidate-identity.json. Output: task-2-review.md, complete combined spec/code verdict with all findings and named evidence checks. Final response only concise verdicts/findings/report path; this overrides the generic template's full-final-report wording. Do not read the entire milestone plan or prior task reports. Read the diff once in bounded sequential chunks if needed; do not dump it into another agent or rerun Git. Template placeholders below refer to these exact inputs; binding constraints are reproduced above.

## Complete review template

# Task Reviewer Prompt Template

Use this template when dispatching a task reviewer subagent. The reviewer
reads the task's diff once and returns two verdicts: spec compliance and
code quality.

**Purpose:** Verify one task's implementation matches its requirements (nothing
more, nothing less) and is well-built (clean, tested, maintainable)

```
Subagent (general-purpose):
  description: "Review Task N (spec + quality)"
  model: [MODEL — REQUIRED: choose per SKILL.md Model Selection; an omitted
         model silently inherits the session's most expensive one]
  prompt: |
    You are reviewing one task's implementation: first whether it matches its
    requirements, then whether it is well-built. This is a task-scoped gate,
    not a merge review — a broad whole-branch review happens separately after
    all tasks are complete.

    ## What Was Requested

    Read the task brief: [BRIEF_FILE]

    Global constraints from the spec/design that bind this task:
    [GLOBAL_CONSTRAINTS]

    ## What the Implementer Claims They Built

    Read the implementer's report: [REPORT_FILE]

    ## Diff Under Review

    **Base:** [BASE_SHA]
    **Head:** [HEAD_SHA]
    **Diff file:** [DIFF_FILE]

    Read the diff file once — it contains the commit list, a stat summary,
    and the full diff with surrounding context, and it is your view of the
    change. The diff's context lines ARE the changed files: do not Read a
    changed file separately unless a hunk you must judge is cut off
    mid-function — and say so in your report. Do not re-run git commands.
    If the diff file is missing, fetch the diff yourself:
    `git diff --stat [BASE_SHA]..[HEAD_SHA]` and `git diff [BASE_SHA]..[HEAD_SHA]`.
    Do not crawl the broader codebase. Inspect code outside the diff only
    to evaluate a concrete risk you can name — one focused check per named
    risk, and name both the risk and what you checked in your report.
    Cross-cutting changes are legitimate named risks: if the diff changes
    lock ordering, a function or API contract, or shared mutable state,
    checking the call sites is the right method.

    Your review is read-only on this checkout. Do not mutate the working
    tree, the index, HEAD, or branch state in any way.

    ## You Do Not Dispatch Subagents

    Do all of this review yourself. Never spawn a subagent to review part
    of the diff, and never spawn another reviewer for a second opinion.
    This process already provides every review seat the work gets; a
    reviewer you spawn duplicates one of them at full cost, and its
    verdict counts for nothing. If the diff feels too large for one
    pass, review it in passes yourself and say so in your report.

    ## Do Not Trust the Report

    Treat the implementer's report as unverified claims about the code. It
    may be incomplete, inaccurate, or optimistic. Verify the claims against
    the diff. Design rationales in the report are claims too: "left it per
    YAGNI," "kept it simple deliberately," or any other justification is the
    implementer grading their own work. Judge the code on its merits — a
    stated rationale never downgrades a finding's severity.

    ## Tests

    The implementer already ran the tests and reported results with TDD
    evidence for exactly this code. Do not re-run the suite to confirm their
    report. Run a test only when reading the code raises a specific doubt
    that no existing run answers — and then a focused test, never a
    package-wide suite, race detector run, or repeated/high-count loop. If
    heavy validation seems warranted, recommend it in your report instead of
    running it. If you cannot run commands in this environment, name the
    test you would run.

    Warnings or other noise in the implementer's reported test output are
    findings — test output should be pristine.

    Evidence you cannot see is not evidence that doesn't exist. If the
    report or its test evidence looks truncated, or you cannot locate the
    results it claims, re-read the file at its stated path — and if it is
    genuinely missing or garbled, report that as a gap for the controller.
    Re-running the suite to regenerate what you failed to read is not
    verification; illegibility of the evidence is not invalidation of it.

    ## Part 1: Spec Compliance

    Compare the diff against What Was Requested:

    - **Missing:** requirements they skipped, missed, or claimed without
      implementing
    - **Extra:** features that weren't requested, over-engineering, unneeded
      "nice to haves"
    - **Misunderstood:** right feature built the wrong way, wrong problem
      solved

    If the brief lists several files each with its own change (a batched
    dispatch), check the diff against that list file by file: every listed
    file must have its corresponding hunk. A listed file the diff never
    touches is a Missing finding, no matter how clean the rest of the
    batch looks.

    If a requirement cannot be verified from this diff alone (it lives in
    unchanged code or spans tasks), report it as a ⚠️ item instead of
    broadening your search.

    ## Part 2: Code Quality

    **Code quality:**
    - Clean separation of concerns?
    - Proper error handling?
    - DRY without premature abstraction?
    - Edge cases handled?

    **Tests:**
    - Do the new and changed tests verify real behavior, not mocks?
    - Are the task's edge cases covered?

    **Structure:**
    - Does each file have one clear responsibility with a well-defined interface?
    - Are units decomposed so they can be understood and tested independently?
    - Is the implementation following the file structure from the plan?
    - Did this change create new files that are already large, or
      significantly grow existing files? (Don't flag pre-existing file
      sizes — focus on what this change contributed.)

    Your report should point at evidence: file:line references for every
    finding and for any check you would otherwise answer with a bare
    "yes." A tight report that cites lines gives the controller everything
    it needs.

    Your final message is the report itself: begin directly with the
    spec-compliance verdict. Every line is a verdict, a finding with
    file:line, or a check you ran — no preamble, no process narration,
    no closing summary.

    ## Calibration

    Categorize issues by actual severity. Not everything is Critical.
    Important means this task cannot be trusted until it is fixed: incorrect
    or fragile behavior, a missed requirement, or maintainability damage you
    would block a merge over — verbatim duplication of a logic block,
    swallowed errors, tests that assert nothing. "Coverage could be broader"
    and polish suggestions are Minor.
    If the plan or brief explicitly mandates something this rubric calls a
    defect (a test that asserts nothing, verbatim duplication of a logic
    block), that IS a finding — report it as Important, labeled
    plan-mandated. The plan's authorship does not grade its own work; the
    human decides.
    Acknowledge what was done well before listing issues — accurate praise
    helps the implementer trust the rest of the feedback.

    ## Output Format

    ### Spec Compliance

    - ✅ Spec compliant | ❌ Issues found: [what's missing/extra/misunderstood,
      with file:line references]
    - ⚠️ Cannot verify from diff: [requirements you could not verify from the
      diff alone, and what the controller should check — report alongside the
      ✅/❌ verdict for everything you could verify]

    ### Strengths
    [What's well done? Be specific.]

    ### Issues

    #### Critical (Must Fix)
    #### Important (Should Fix)
    #### Minor (Nice to Have)

    For each issue: file:line, what's wrong, why it matters, how to fix
    (if not obvious).

    ### Assessment

    **Task quality:** [Approved | Needs fixes]

    **Reasoning:** [1-2 sentence technical assessment]
```

**Placeholders:**
- `[MODEL]` — REQUIRED: reviewer model per SKILL.md Model Selection
- `[BRIEF_FILE]` — REQUIRED: the task brief file (`scripts/task-brief PLAN N`
  prints the path; same file the implementer worked from)
- `[GLOBAL_CONSTRAINTS]` — the binding requirements copied verbatim from
  the plan's Global Constraints section or the spec: exact values, formats,
  and stated relationships between components (not process rules — those
  are already in this template)
- `[REPORT_FILE]` — REQUIRED: the file the implementer wrote its detailed
  report to
- `[BASE_SHA]` — commit before this task
- `[HEAD_SHA]` — current commit
- `[DIFF_FILE]` — REQUIRED: the path the controller wrote the review
  package to (`scripts/review-package PLAN_FILE BASE HEAD` prints the unique
  path it wrote; the package never enters the controller's context)

**Reviewer returns:** Spec Compliance verdict (✅/❌/⚠️), Strengths, Issues
(Critical/Important/Minor), Task quality verdict
