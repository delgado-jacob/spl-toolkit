package main
import("encoding/json";"fmt";"github.com/delgado-jacob/spl-toolkit/pkg/analysis")
func main(){
 for _, q:= range []string{`search index=main | eval src=1 | table src`,`search index=main | mystery | table src`,`search index=main | eval src=1 | where unknown(src)=2`} {
  session,err:=analysis.PrepareRewrite(analysis.QueryDocument{Text:q},nil);if err!=nil {panic(err)}
  e:=session.Evidence(); refs:=map[string]analysis.Reference{};for _,ref:=range e.Analysis.References {refs[ref.ID]=ref}
  fmt.Println(q)
  for _,site:=range e.Sites {if site.Identity.Name!=nil && *site.Identity.Name=="src" {raw,_:=json.Marshal(struct{Site analysis.RewriteSite;Reference analysis.Reference}{site,refs[site.ReferenceID]});fmt.Println(string(raw))}}
 }
}
