## Task 6: CLI and HTTP parity with executable documentation


Own new cmd/rewrite_cli.go and tests, pkg/api/rewrite.go and tests, minimal registrations in cmd/cli.go and pkg/api/server.go, actual accepted OpenAPI reconciliation tooling/generated docs, docs/cli.md, docs/api-server.md and tests/acceptance/cli_examples.json. Consume Task 5 Request/BatchRequest decoders and canonical operations; produce thin report transports. Use the exact integrated helper and request-limit contracts above, reconciling only any later accepted M5 delta and preserving maintained examples.

1. Add `rewrite --rules <local-json>` with preview default and explicit `--apply`. Reuse query/positional/file/stdin/batch and document options, field-list/schema/OCSF selectors, format text/json and report output behavior. Rules file uses RuleSet; never let a file silently supply apply mode. Reject competing inputs/options and global dialect flags in document-batch mode. No in-place source-file editing flag is added.

2. Test full canonical JSON equality, exact source bytes/source_id, text labels for candidate versus returned text, no-op and failed-apply audit, unknown/ambiguous partial commit, all exits 0/1/3/2 and output write failures. A report must be written before a content-status exit; file output must not duplicate stdout. Exit 3 alone cannot be described as a refusal because committed may be true.

3. Register POST `/api/v1/query/rewrite` and `/api/v1/query/rewrite/batch` through existing middleware and canonical decoders, selecting M4's 8 MiB schema-route body policy for both. Preserve 1 MiB legacy routes and add no global limit/config feature. HTTP 200 carries all query-level statuses; request errors are 400 and internal failures are server errors. Inline targets/rules are data; server filesystem paths and retrieval URLs are not accepted. Test malformed duplicate/null/selector/target inputs and single/batch JSON equality. Reuse the accepted M4 exact-bound and +1-byte mechanisms to prove the 8,388,608-byte bound, including its established transport error on overflow. Exercise genuine normal/selected-extension OCSF catalogs through single and batch rewrite requests; do not substitute tiny synthetic tables as payload/compatibility proof.

4. Add maintained docs/cli.md example markers with matching argv/stdin/exit/stdout/stderr/output_files entries in cli_examples.json. Execute the actual documented CLI harness, including stdin and output-file behavior, rather than copying expected strings from docs without execution. Update HTTP example assertions and OpenAPI through the accepted offline recipe; run idempotence/shape reconciliation tests. Run `go test -mod=readonly ./cmd ./pkg/api` and focused documented CLI/tooling tests. Commit/review the complete surface slice before native packaging.


## Exact native, package and surface integration


Task 7 adds the following functions in `pkg/bindings/bindings.go` using `ownedMapperJSONResult(mapperID C.int, operation func() (any, error)) *C.SPLResult`, canonical decode/rewrite operations and no mapper-config injection:

    //export spl_mapper_rewrite
    func spl_mapper_rewrite(mapperID C.int, requestJSON *C.char) *C.SPLResult
    //export spl_mapper_rewrite_batch
    func spl_mapper_rewrite_batch(mapperID C.int, requestJSON *C.char) *C.SPLResult

The existing helper allocates/initializes the owned result, admits a live registry handle, retains the pointer across the operation and marshals canonical JSON. Query statuses stay in result JSON; malformed/null requests become owned errors. `spl_result_free` frees both optional strings and the outer object exactly once; nil remains permitted. Registry removal prevents later admission but does not cancel an admitted operation. Python close separately waits for admitted calls. Existing 18 exports become 20 if final accepted M5 adds none; verify actual counts instead of hardcoding them as acceptance.

Add ctypes signatures `[ctypes.c_int, ctypes.c_char_p] -> ctypes.POINTER(SPLResult)` and these wrapper methods:

    def rewrite(self, query, rules, *, mode="preview", validation_target=None,
                language="spl", profile="splunkd", version="current", source_id="") -> dict:
        request = {"schema_version": 1, "mode": mode, "rules": rules,
                   "document": {"text": query, "language": language, "profile": profile,
                                "version": version, "source_id": source_id}}
        if validation_target is not None:
            request["validation_target"] = validation_target
        return self._validate_fields_request(self._lib.spl_mapper_rewrite, request, operation="rewrite")
    def rewrite_batch(self, documents, rules, *, mode="preview", validation_target=None) -> dict:
        request = {"schema_version": 1, "mode": mode, "rules": rules, "documents": documents}
        if validation_target is not None:
            request["validation_target"] = validation_target
        return self._validate_fields_request(self._lib.spl_mapper_rewrite_batch, request, operation="rewrite")

Bodies build schema_version=1 requests, preserve caller query/documents/rules, omit validation_target when None and forward other values to strict native decoding. Reuse `_validate_fields_request(self,native,request)` by adding keyword `operation="validation"`; keep existing message text by default and use operation="rewrite" for these methods. Keep `_operation`, allow_nan=False, copied decoded JSON, finally-free, close wait/idempotence and all existing loader/version behavior. Do not duplicate the ctypes/free loop or add a Python parser/validator. Preserve `_legacy_selectors`' `unsupported_dialect_for_operation`; update only guidance to include rewrite. Raw C tests cover duplicates and malformed Unicode that Python dicts cannot express; Python tests cover NaN/Inf/nonserializable rejection, invalid/freed handles, decode failure, concurrency and close admission. Add focused new ownership calls in `tests/native/memory.c`; source Python green is not ASAN acceptance.

Use `python/build_support.py`'s actual native build recipe and require both the library and generated .h. Update `python/spl_toolkit/libspl_toolkit.h` from actual output. Refresh both complete `tools/tests/fixtures/cgo-go1.22.h` and `cgo-go1.25.h` from real corresponding Go builds of the same source. Never insert two declarations synthetically or relax `toolkit_header_contract`'s exact compiler allowances. Preserve existing whole-header drift tests and recorded source/actual wheel header hashes.

Append every new non-test pkg/rewrite Go file, new analysis bridge/helper and any actual shared internal helper to `python/native-source-files.txt`. M5 already owns tstats extraction in an existing listed file; no new dependency file is required. Preserve all 65 predecessor entries and the 13 SPL2 fixture registrations. Extend tools/tests/test_package.py's native closure enumeration to pkg/rewrite and any real shared helper. Keep missing/duplicate/traversal/sdist-source/hash checks intact. Add tests/test_native_rewrite.py to SDIST_FIXED_FILES, test_native_rewrite.py to NATIVE_TESTS and verify_sdist_sources' explicit handwritten hash list. MANIFEST.in inclusion alone does not satisfy exact checker closure.

The checker, unchanged through accepted 40e6e171, has 28 fixed sdist members, six mandatory native modules, 11 schema fixture inputs, 13 SPL2 fixture inputs and eight acceptance inputs (six test modules, spl2_transport.py and cli_examples.json). Preserve the named suites and helper; do not infer test counts from file counts. Add test_rewrite_surfaces.py to ACCEPTANCE_FILES. In tools/check_acceptance.py add test_native_rewrite.py to REQUIRED_TEST_FILES.native and test_rewrite_surfaces.py to REQUIRED_TEST_FILES.acceptance. Register explicit REWRITE_FIXTURE_FILES for every durable rules/conditions/forms/edits/cases input used by native/surface suites. Copy and hash them before both suites under an absolute outside-checkout SPL_REWRITE_FIXTURES, clear inherited overrides in clean_env, and record fixture_hashes.rewrite. Copy maintained rewrite docs with existing copy_documentation; preserve README/docs/cli/docs/spl2 requirements.

M5's install_and_check now also accepts `go_transport: Path`; _check_package prepares the full Go SPL2 report artifact once, copies it for each install and sets SPL_SPL2_GO_REPORTS plus SPL_SPL2_GO_SHA256. `load_transport` validates producing source/fixture hashes, all document IDs and complete report shapes with conformance_credit=0. Preserve this mechanism and its source-freshness requirement after analysis changes; a matching transport snapshot never replaces independent semantic obligations. Both direct-wheel and rebuilt-sdist paths must keep required nonzero collection, zero skips/failures and collected=passed. Extend required-suite/missing-input/corrupted-copy/stale-source tests rather than increasing a numeric threshold alone. Carry schema_surface_evidence, spl2_surface_evidence, documentation_hashes and their canonical fixture/artifact identities into resulting evidence; add rewrite evidence consistently if required, without loosening record validation.

Task 8's new rewrite surface suite reuses `tests/acceptance/test_surfaces.py` helpers `cli_path`, `server_url`, `post_json`, `required_absolute_path`, and schema loader helpers when needed. server_url launches the supplied absolute SPL_SERVER with an ephemeral loopback PORT, a bounded readiness check at /api/v1/health and explicit cleanup/log retention; do not invent a second server lifecycle. Source runs use absolute SPL_NATIVE_LIBRARY; installed runs load the packaged module/library and omit that override. Source fixture assertions remain independently authored; full canonical transport parity compares every array/value/location/binding/diagnostic, ignoring only object-key order. Add safe preview/apply/ordered-batch examples to python/examples/basic_usage.py while retaining its existing schema and legacy examples. No release-platform/format change is indicated.

