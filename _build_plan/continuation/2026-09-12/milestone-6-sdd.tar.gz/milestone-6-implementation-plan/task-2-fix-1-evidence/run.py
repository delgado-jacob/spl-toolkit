import hashlib, json, os, pathlib, subprocess, sys, time
root=pathlib.Path.cwd()
evidence=root/'.superpowers/sdd/milestone-6-implementation-plan/task-2-fix-1-evidence'
name=sys.argv[1]
command=['/opt/homebrew/Cellar/go/1.25.5/libexec/bin/go']+sys.argv[2:]
envadd={'GOCACHE':'/private/tmp/spl-toolkit-go-cache','GOMODCACHE':'/private/tmp/spl-toolkit-remaining-gomodcache','GOPROXY':'off','GOTOOLCHAIN':'local'}
paths=subprocess.check_output(['git','ls-files'],text=True).splitlines()
paths=[p for p in paths if p.endswith('.go') or p in ['go.mod','go.sum']]
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
source={p:sha(p) for p in paths}
diff=subprocess.check_output(['git','diff','--binary','02c2e3217df6edef01cada136d9e623da0de7a93'])
(evidence/(name+'.diff')).write_bytes(diff)
started=time.time()
result=subprocess.run(command,env={**os.environ,**envadd},stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(evidence/(name+'.log')).write_bytes(result.stdout)
receipt={'command':command,'cwd':str(root),'environment':envadd,'observed_exit':result.returncode,'elapsed_seconds':time.time()-started,'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'go_binary_sha256':sha(command[0]),'source_sha256':source,'source_unchanged_during_run':source=={p:sha(p) for p in paths},'diff_sha256':hashlib.sha256(diff).hexdigest(),'log_sha256':hashlib.sha256(result.stdout).hexdigest()}
(evidence/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(result.stdout.decode(errors='replace'),end='')
print('OBSERVED_EXIT='+str(result.returncode))
sys.exit(result.returncode)
