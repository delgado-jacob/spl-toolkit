# M6 Task 4 implementation report

Task 4 is implemented and committed at `14a3a0dcfe4652240dc8b949461f905b206f215a`. Its sole parent is the accepted Task 3 BASE `6c18c32a073b944375d1d37da7e47b768d16656a`. Independent review is pending; this report does not accept Task 4 or implement the Task 5 apply gate.

The release brief SHA-256 is `c8a1f30a1feb2ee8c4fb783260e68f0cde83bf7a1e609918d2822802474a320d`; assignment receipt SHA-256 is `87d33c7691437d8f23ea9fb6c05fa5fd5daca26e98e6056b8eaf4a68bb8b39b3`. Both and the exact BASE were checked before work. No subagents or independent reviewer were dispatched by this implementer.

## Scope and implementation

The commit contains exactly `pkg/rewrite/groups.go`, `pkg/rewrite/groups_test.go`, `pkg/rewrite/edits.go`, `pkg/rewrite/edits_test.go`, and `testdata/rewrite/edits.json`. It creates private candidate construction and does not alter the public model, Task 3 selection, analysis/frontends, parser, command transfer, selectors, native methods, CLI, HTTP, configuration, dependency versions or toolchain. The original checkout, unrelated untracked plan files, coordinator ledger, other SDD directories and root-private acceptance inputs were preserved.

Canonical BindingID groups include all eligible observed members of an original binding, with authorization at each member's original flow point. Render requirements expand proven implicit consumers and explicitly authorized coupled catalog changes; canonical effects retain implicit output identity changes without guessed names or manufactured AS aliases. Explicit eval/rename/aggregate aliases and their derived reads remain outside source-name mapping. An omitted source authorization or unproved required consumer refuses its entire group.

Uncertainty relevance uses canonical lineage field-origin sets and edited sites' owning phase/stage. A relevant wildcard, dynamic owner, unknown command, unsupported implicit label or unknown merge refuses closure. Independent child scopes, fresh source epochs and a source removed before later unrelated uncertainty are retained as counterexamples. No transfer algorithm or token-name discovery exists in rewrite.

Identical site/target proposals retain every contributing ID. Shared required sites and overlapping intervals connect edit groups. Contradictory target alternatives and incompatible canonical overlaps are retained for audit and excluded. Potential field capture/collapse interactions are scheduled together using canonical source epochs or shared live origin sets, then decided by the original session's `Verify` over simultaneous rendering. This admits canonically proven swaps/chains and refuses dependent groups when a skipped edit would have been needed to prevent capture. It does not require an open event source to prove unseen target fields absent. The final selected set is verified together as well; failure removes the remaining set conservatively, with no optimal-subset search.

The byte reconstructor validates old slices and disjoint original intervals, copies untouched bytes in one forward construction, computes cumulative replacement byte ranges and batches them through `analysis.LocateRewriteBytes` against the exact candidate. Original and candidate boundary validation both use the canonical locator. Rewrite does not count runes, implement CRLF conversion, call private source-index methods or strip EOF-looking text. The audit retains exact before/after text, half-open locations, original IDs, candidate IDs returned by canonical correspondence, per-edit rule contributions, group membership, ambiguity and candidate inclusion. No entry is marked committed.

## Exact private Task 5 interface

```go
func buildCandidate(
    session *analysis.RewriteSession,
    rules []Rule,
    probes []analysis.RewriteFactProbe,
    selection ruleSelection,
) (*rewriteCandidate, error)

type rewriteCandidate struct {
    Text        string
    Changes     []Change
    Groups      []editGroup
    Evaluations []RuleEvaluation
    Rendering   *analysis.RewriteRendering
    Session     *analysis.RewriteSession
    Proof       analysis.RewriteProof
    Incomplete  bool
}

type editGroup struct {
    ID, Reason   string
    Replacements []analysis.RewriteReplacement
    RuleIDs      []string
    Limitations  []analysis.RewriteLimitation
    // private rendering and member alternatives retained for audit construction
}

func reconstructEdits(
    original string,
    edits []analysis.RewriteTextEdit,
) (string, []analysis.Location, error)
```

Consumer sequence: prepare rules through the accepted Task 1 boundary; collect `conditionProbes(rules)`; prepare the original canonical session with the prepared document and those probes; call `selectRules(rules, probes, original.Evidence())`; pass those same original inputs to `buildCandidate`. All binding/fact authority remains in that original session. `reconstructEdits` returns locations in caller edit order, even when the intervals arrive unsorted, and returns errors for malformed/out-of-bounds/split-codepoint intervals, old-text mismatches and incompatible overlaps.

`Text` is candidate preview text only. `Session` is the canonical analysis of that final candidate in the original language/profile/version/source ID; `Rendering` is the final opaque rendering belonging to the original session. `Proof` is canonical correspondence for that final pair. Task 5 must still enforce its whole-request original/candidate validity, relevant relationship/uncertainty and optional strict destination-validation gate before marking any change committed or publishing authoritative apply text. It can call `original.Verify(candidate.Session, candidate.Rendering)` directly without fabricating coordinates or IDs. A destination validation failure must retain this candidate as evidence and leave authoritative text original, as required by the approved plan.

`Groups[i].Reason == ""` denotes selected groups. Rejected reasons are the existing `linked_edit_unproven`, `target_not_renderable`, `conflicting_targets`, `overlapping_edits`, or `binding_collision` codes; precise canonical limitations are retained. `Groups[i].Replacements` is unique by site for the selected representation; for a contradictory rejected group it is not an authorized choice of target. All conflicting byte alternatives remain in `Changes` and private member renderings. Consumers must never render rejected group representatives as an alternative apply attempt.

`Evaluations` retains Task 3 evaluations and adds per-originating-rule evaluations for canonically required implicit consumers, in rule request order and canonical location order. An independently true identical rule can authorize a required edit while another rule is unknown there; the full condition evidence and `Incomplete` remain. `Incomplete` is Task 3 uncertainty OR required-member unknown eligibility OR any rejected group. It does not turn ordinary no-match, false-condition, no-change or proven derived-name exclusions into uncertainty. Task 5 must combine this with original/candidate analysis and destination validation rather than treating every unsupported-reference reason alike.

`Changes` are sorted by original intervals and stable replacement/group ties. Included entries have `Outcome: "proposed"`, `Reason: "matched"`, `CandidateApplied: true`, exact candidate locations and resolvable candidate IDs. Conflict/capture alternatives are `Outcome: "ambiguous"`; other refusals are skipped, with no candidate location or candidate IDs. A rendering refusal with no proven encoding retains the located old text and an empty NewText; rewrite never invents an encoding. Ordinary rule-only skips remain in `Evaluations` rather than inventing byte edits. All `Committed` fields stay false. Public arrays serialize through the accepted Task 1 model; copied evaluations prevent callers from mutating selection evidence through returned output.

## Verification and evidence

All tests used `/opt/homebrew/bin/go` (`go1.25.5 darwin/arm64`) with `GOCACHE=/private/tmp/spl-toolkit-go-cache`, `GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache`, `GOPROXY=off`, `GOTOOLCHAIN=local`. Exact resolved binary path and SHA-256 are in `task-4-evidence/14-precommit-identity.json`.

Final commands, each exit 0, with no stderr or unexpected stdout:

- `go test -mod=readonly ./pkg/rewrite -run 'TestRewriteLinked|TestRewriteConflicts|TestRewriteByte' -count=1 -v`: 58 passing test/subtest checks, zero failures (`11-final-affected.*`).
- `go test -mod=readonly ./pkg/rewrite -count=1`: full affected package passes (`12-package.*`).
- `go test -race -mod=readonly ./pkg/rewrite -run TestRewriteConflictsDeterministicConcurrent -count=1`: concurrent identical calls on one original session pass the race detector (`13-race.*`).
- `gofmt -l` on the four Go files returned no paths. Exact-path staged `git diff --check` passed; only the five owned files were staged (`14-precommit-identity.json`, `15-staged-checks.json`).

Each test log includes raw stdout, raw stderr, its exact command, observed exit and changed-source/fixture hashes. No unchanged predecessor or shared build-all suite was rerun. `16-committed-identity.json` verifies that the final commit's source bytes equal all three final test identities, the BASE is its direct parent/ancestor and the owned worktree has no diff. The unrelated pre-existing untracked plan files remain; this is not a globally clean checkout claim.

Retained RED/GREEN sequence:

1. `01-groups-red.*` (exit 1): compiling minimal stub failed linked changes, conflicts and refusal audits for missing functionality. `02-bytes-red.*` (exit 1): compiling byte stub failed reconstruction, insertion and interval-validation assertions.
2. `03-canonical-inspection.*` (exit 0, source `inspect.go`): raw canonical evidence established relevant wildcard/unknown transition origins, parent merge uncertainty and exact-removal boundaries. The initial draft independent-parent fixture was corrected because append itself had a relevant unknown merge; the durable independent fixture edits only the separate child source.
3. `04-affected.*` (exit 1): generic SPL2 implicit output had no retained field-state origin, exposing missing edited-owner-stage uncertainty checking. `05-affected-green.*` (exit 0) closed it without changing canonical producer code.
4. `06-audit-red.*` (exit 1): compatible overlapping catalog rendering dropped the component rule ID. `07-audit-green.*` (exit 0) closed that provenance defect.
5. `08-closure-ownership-red.*` (exit 1): independent earlier source epoch was over-rejected and returned evaluation pointers aliased input selection. That run also contained a test-fixture mistake: source-reference-present was supplied an index identity, correctly rejected by existing request preparation. The fixture was corrected to a valid field-literal wildcard guard; it is not counted as a product RED. `09-closure-ownership-green.*` (exit 0) closed the real defects and checked ordinary/unknown skips.
6. `10-unknown-audit-red.*` (exit 1): an unknown required-consumer rule's audit failed to retain aggregate incompleteness when an identical unconditional rule authorized the candidate. `11-final-affected.*` closes it, followed by package and race verification.

Durable fixtures include explicit aliases, implicit outputs, per-member guards, wildcard/dynamic/unknown closure, independent child scopes and source resets, removals, duplicate/conflicting targets, capture/collapse, swaps/chains, skipped safety dependencies, overlapping and coupled catalogs, catalog/local lookup insertion, CRLF/tabs/comments/quotes/Unicode and newline-name rendering. Direct byte tests additionally cover arbitrary intervals without canonical references, multiple zero-width insertions, multiline replacements, malformed boundaries and literal `<EOF>` preservation. Hand-derived candidate positions verify actual half-open Unicode/CRLF locations; tests do not mirror the locator algorithm.

## Tested source SHA-256

- `pkg/rewrite/groups.go`: `33a29ec90eb519874f187c6186a0458487ea97467f11fa964c0dd44944762e59`
- `pkg/rewrite/groups_test.go`: `3ae9f129ae6b01ad53474cb2dab45d9ce44106ebc6fc865028b7aff1c04dee0c`
- `pkg/rewrite/edits.go`: `82658ed178039c16d363f35024ac59cbd03ff96d18522d1a55a2638fa497ba8d`
- `pkg/rewrite/edits_test.go`: `13a197e032a2fddb5242283d73226d0919e6a623570d98df4b83ddd86dec20e9`
- `testdata/rewrite/edits.json`: `7b62f37757c173550ec1c83228c11ddd14d8aa2619a18584b615250eb2986c54`

## Concerns and remaining gates

No concrete ownership or missing-canonical-proof blocker remains. Static correspondence is deliberately conservative and does not claim runtime-equivalent search results or unseen event-field absence. SPL2 implicit labels outside the already accepted canonical contract remain refused; SPL newline targets without a proven encoding remain refused. Component and final-set correspondence parsing is local prepublication selection evidence, and cannot substitute for Task 5's apply/validation policy. Fresh independent Task 4 spec/code review and the subsequent Task 5 gate remain open.
