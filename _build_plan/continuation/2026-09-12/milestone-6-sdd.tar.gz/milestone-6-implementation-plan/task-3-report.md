# Task 3 partial checkpoint — frozen for canonical producer correction

Status: PARTIAL, no Task3 commit. Production/test activity stopped after the red-selection command, as requested by coordinator. All work is in the assigned worktree. No source files outside Task3 ownership were edited.

Current BASE: `0b8dd62068be0638e470a532544acd1cc0a48507`.
Tool: `go version go1.25.5 darwin/arm64`.

Owned untracked production/test files:

- `pkg/rewrite/conditions.go`: SHA256 `6721f6ea136eee71c2497fe04425bc1620864ace075c34e415ed244cdfcb9361`
- `pkg/rewrite/conditions_test.go`: SHA256 `8d7d3743c8694871666d900254af62bbd674be9c297a747933fc859a5ad850ae`
- `testdata/rewrite/conditions.json`: SHA256 `9aaa221e3c3ef42caef7f3d5ae6025443d82b88ed970abf716a9100ddb48500f`

Owned ignored task artifacts: `task-3-report.md`; `task-3-evidence/probe.go`, `producer-probe.json`, `producer-probe.stdout`, `producer-probe.stderr`, `run.py`, and `{red-unit,green-unit,red-selection}.{json,stdout,stderr}`.

## Observed evidence

- `producer-probe`: exit 0. Canonical real-query evidence establishes the coordinator-confirmed completeness gap; see retained raw stdout.
- `red-unit`: exit 1. Minimal evaluator stub caused expected truth-table, typed-scalar, evidence-retention and absence failures.
- `green-unit`: exit 0. `/opt/homebrew/bin/go test -mod=readonly ./pkg/rewrite -run '^TestCondition'` passed against the implemented pure evaluator. Later new probe tests did not exist at this green checkpoint.
- `red-selection`: exit 1. `/opt/homebrew/bin/go test -mod=readonly ./pkg/rewrite -run 'TestConditionProbe|TestRewriteCondition'` failed as expected with newly added probe/selection stubs. Canonical integration tests consequently receive no probes at this checkpoint; these failures are feature RED, not a fresh producer diagnosis. All raw stdout/stderr, exit codes, source hashes and tool/environment identity are retained in matching artifacts. Stderr is empty for these checks.

## Implemented and pending

Implemented: pure `evaluateConditionAtSite` over canonical facts, full child evidence retention for all/any, source-reference truth, typed scalar equals/contains, exact decimal numeric normalization including very large exponents without expanding their magnitude, copied condition evaluations and evidence IDs.

Pending: implement `conditionProbes` and `selectRules` (currently explicit stubs); reconcile real-query fixtures against the reviewed canonical producer correction without weakening approved expectations; add targeted remaining selection/evidence-ownership checks if needed; self-review, affected/package verification, exact-owned commit, final report.

Proposed private API, accepted by coordinator:

```go
conditionProbes(rules []Rule) []analysis.RewriteFactProbe
evaluateConditionAtSite(condition *Condition, probes []analysis.RewriteFactProbe, site analysis.RewriteSite) ConditionEvaluation
selectRules(rules []Rule, probes []analysis.RewriteFactProbe, evidence analysis.RewriteEvidence) ruleSelection
```

`ruleSelection` contains Evaluations, Proposals, Incomplete. `ruleProposal` contains SiteID, Target, RuleIDs, EvidenceReferenceIDs. Planned selection coalesces identical site targets and preserves all originating RuleIDs; Task4 can independently re-evaluate those rules at canonical RequiredChanges sites. No renderer/transfer/query parser is implemented here.

Coordinator confirmed completeness gap for supported OR/NOT and absent earlier facts. A serial original-Task2-writer correction plus review will supply a new BASE. This Task3 worker is frozen until coordinator followup. No commit or success claim is made.


# Final Task 3 continuation — implementation COMPLETE, ready for independent review

This final continuation supersedes the PARTIAL status above; the original frozen checkpoint and its evidence remain unchanged history. All Task3 source work is complete and committed. The coordinator owns independent review and subsequent Task4 release.

## Immutable source and scope

- Original writing BASE: `0b8dd62068be0638e470a532544acd1cc0a48507`.
- Accepted canonical producer continuation / final Task3 commit-review BASE: `5745041676c8d6cddfb7b769c2aaa2630d3ab8a2`.
- Exact Task3 commit: `3892f6dc8db7e8fb3e1de78d443704fb56b696ef`, direct child of that accepted producer BASE.
- Commit subject: `feat(rewrite): select rules from canonical three-valued facts`.
- Exactly three committed files: `pkg/rewrite/conditions.go`, `pkg/rewrite/conditions_test.go`, `testdata/rewrite/conditions.json`.
- No other production paths edited; no child agents, renderer, candidate construction, flow replay, query parsing, network/toolchain change, branch creation, merge, push or cleanup.
- Post-commit status has no tracked/index changes. Existing unrelated untracked `CLAUDE.md` and `_build_plan` artifacts remain present, so this is not a globally clean-worktree claim.
- Working bytes and committed blobs both match the final tested SHA256 values:

- `pkg/rewrite/conditions.go`: `e796175576d8dc836c4a89b739ad63bfaf6f196b9865d2e9baaee5f0b837eca2`
- `pkg/rewrite/conditions_test.go`: `a198d745bae77a4dc3e0b4383ea06097d121f715541776f1aa25959b8afdc5ee`
- `testdata/rewrite/conditions.json`: `9aaa221e3c3ef42caef7f3d5ae6025443d82b88ed970abf716a9100ddb48500f`

## Implemented behavior and Task4 handoff

```go
func conditionProbes(rules []Rule) []analysis.RewriteFactProbe
func evaluateConditionAtSite(condition *Condition, probes []analysis.RewriteFactProbe, site analysis.RewriteSite) ConditionEvaluation
func selectRules(rules []Rule, probes []analysis.RewriteFactProbe, evidence analysis.RewriteEvidence) ruleSelection

type ruleProposal struct {
    SiteID               string
    Target               Identity
    RuleIDs              []string
    EvidenceReferenceIDs []string
}
type ruleSelection struct {
    Evaluations []RuleEvaluation
    Proposals   []ruleProposal
    Incomplete  bool
}
```

Call with Task1-prepared rules. Collect probes once before `analysis.PrepareRewrite(document, probes)`, then select from that session's original `Evidence()`. Probe collection deduplicates exact kind/typed-identity pairs, sorts internal probe keys deterministically, and returns copied identities. Atom `actor.name` is distinct from path `[actor,name]`.

`evaluateConditionAtSite` is deliberately independent of rule-source matching and site eligibility. A nil condition is true. Task4 must look up every originating `RuleID` from a proposal and call this evaluator independently for each canonical `RequiredChanges` site's original facts. Evaluating a linked member does not make it directly source-matchable or eligible. The durable implicit-consumer test proves a condition true at `sum(src)`'s source read becomes unknown at its later implicit output consumer after the restricting field is dropped.

All/any implement the full three-valued tables and retain every child evaluation and evidence ID, including unknown siblings beside controlling false/true children. A leaf consumes only the matching canonical `ProbeIndex`. Literal equality preserves string/number/Boolean/null kinds without coercion. String contains is exact, case-sensitive and compares established values only. Exact JSON decimal normalization uses coefficient plus arbitrary-precision exponent without expanding exponent magnitude; it preserves integers beyond float precision and accepted huge exponent spellings. Unknown/mismatched scalar representations remain unknown unless an independently guaranteed understood value proves the requested match. LiteralComplete alone controls nonmatching false versus unknown. Source-reference truth is consumed independently, never converted into equality or event presence.

Selection preserves request order for rule evaluations and contributing `RuleIDs`. Candidate sites are ordered by canonical source start/end offsets with stable canonical ties; SQL logical preparation order does not reorder public candidate locations. Proposals follow that source order, with request-order ties for distinct targets at one site. Equal targets at one site coalesce, retaining every contributing rule ID and the union of candidate/condition evidence reference IDs. Distinct targets remain separate proposals for Task4 conflict handling. Reordering rules changes audit order only; it never creates precedence, cascading facts or different proposal semantics.

Each rule/site evaluation contains the actual candidate reference ID and copied location. No-match evaluations have no fabricated source location/reference. Outcomes are `proposed` with reason `matched`, or `skipped` with existing reasons `no_match`, `no_change`, `condition_false`, `condition_unknown`, `unsupported_reference`, or `dynamic_reference`. A conditional evaluation remains attached for inspection. `Incomplete` records overall unknown conditions and ineligible source refusals; controlling all/any results remain their known result with all child uncertainty retained. Selection does not replace canonical analysis coverage or Task4/5 coverage aggregation.

## Verification and failure history

Environment for every Go test/run: `/opt/homebrew/bin/go`, `go version go1.25.5 darwin/arm64`; `GOCACHE=/private/tmp/spl-toolkit-go-cache`, `GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache`, `GOPROXY=off`, `GOTOOLCHAIN=local`, `-mod=readonly`.

Final tested source commands, both exit 0:

```text
/opt/homebrew/bin/go test -mod=readonly ./pkg/rewrite -run 'TestCondition|TestRewriteCondition'
/opt/homebrew/bin/go test -mod=readonly ./pkg/rewrite -json
```

The full package completed 247 passing tests/subtests, zero failures and zero skips. 85 passing entries are Task3 condition tests/subtests. All 26 durable real-query fixtures pass, covering same-point predicates; common/competing OR; query NOT; earlier/later filters; independent and inherited scopes; redefinition/removal/barriers/source reset; unsupported predicates with independent guarantees; SQL logical phases; reference-only facts; wildcard-versus-expression strings; and typed number/Boolean/null data. Both final test stderr files are empty. `git diff --cached --check` before commit and `git diff --check HEAD^ HEAD` after commit exited 0. No reruns were performed solely to regenerate a summary.

Retained evidence labels (each has raw `.stdout`, `.stderr`, and `.json` command/environment/source/exit metadata):

| Label | Exit | Meaning |
| --- | --- | --- |
| `red-unit` | 1 | Original minimal evaluator stub failed expected truth/evidence/typed-value assertions. |
| `green-unit` | 0 | Original bounded pure evaluator tests passed. |
| `red-selection` | 1 | Probe/selection stubs failed expected selection/integration assertions before freeze. |
| `continuation-selection` | 0 | Implemented probes/selection passed the focused suite with accepted producer correction. |
| `continuation-handoff` | 0 | Coalesced condition proof, return ownership, and implicit-member independent evaluation passed. |
| `continuation-focused-final` | 0 | Pre-ordering-correction focused GREEN history. |
| `continuation-package-final` | 0 | Pre-ordering-correction package GREEN history, 246 passing tests/subtests. |
| `continuation-order-red` | 1 | New non-lexical rule IDs and SQL source ordering exposed lexical audit sorting and logical-site output order. |
| `continuation-order-green` | 1 | Ordering implementation fixed; fixture's hand-counted final SQL offset was 41 rather than actual 42. Only offset assertions remained failing. |
| `continuation-order-green-corrected-offset` | 0 | Corrected the fixture literal offset to 42 after enumerating the source bytes; ordering regressions passed. |
| `continuation-order-focused-final` | 0 | Final required focused command passed. |
| `continuation-order-package-final` | 0 | Final whole-package check, 247 passing tests/subtests. |

`producer-probe` retains the original confirmed completeness gap, subsequently fixed and independently accepted in producer commit 57450416. No consumer fallback, reference-state inference, producer mutation or weakened durable expectation was introduced. Original frozen report/evidence copies were not changed. The ordering correction follows the coordinator's `task-3-ordering-contract.json`; revised brief SHA256 is `76f3e185a786852ec1708eee0862a3913f2f582d7fa2bbd98e291012ce34873e`.

Additional raw pre/postcommit checks, exact commit stdout/stderr, and committed-blob/test-hash proof are in `task-3-evidence/continuation-order-precommit*`, `continuation-commit*`, and `continuation-postcommit*`. Raw evidence includes the failed checks above; no failures or warnings were discarded.

## Self-review and concerns

Self-review checked the accepted task behavior, pure canonical ownership boundary, typed atom/path comparison, all-child retention, JSON scalar semantics, input/result ownership, every-rule selection, equal-target coalescing, request/source ordering, false/unknown refusal distinctions, and exact-owned commit scope. The canonical completeness/O1 follow-up is consumed as reviewed; no remaining producer gap was exposed by the final cases.

No open Task3 implementation concerns. Candidate rendering/group conflicts, post-verification, API/CLI wiring and full Milestone6 acceptance remain later tasks. This receipt claims Task3 implementation/package verification and its immutable commit; it does not claim independent review or completion of downstream work.


# Task 3 scoped correction, round 1 — I1 fixed; ready for rereview

This append supersedes the prior blanket-ineligible summary and its wrong derived-skip test expectation. All earlier report/freeze/review evidence remains intact. This writer has completed the bounded correction; the coordinator's same independent reviewer owns closure/rereview.

- Fix BASE: `3892f6dc8db7e8fb3e1de78d443704fb56b696ef`.
- Immutable fix commit: `6c18c32a073b944375d1d37da7e47b768d16656a` (direct child of the fix BASE).
- Subject: `fix(rewrite): keep known derived exclusions complete`.
- Exact changed/committed paths: `pkg/rewrite/conditions.go`, `pkg/rewrite/conditions_test.go`.
- `testdata/rewrite/conditions.json` is unchanged. No analysis, model, facade, later-task, private-oracle or unrelated files were changed. No child/reviewer agents were dispatched.
- Worktree/index have no tracked changes after commit; the original unrelated untracked planning artifacts remain preserved.

## Corrected behavior

Selection joins canonical `Analysis.References` by the actual site `ReferenceID`. A conclusive exclusion requires an exact field reference with `Binding=derived`, or `Binding=not_applicable` and canonical creation Role `create`, `rename`, or `output`. Definition names do not expose `Binding=definition` in the public Reference model: retained real metadata shows eval's creation is `create/not_applicable` and its later consumer is `read/derived`. Canonical creation call sites at `transfers.go` support the role set; no names, query text or ID spellings are interpreted.

For a matching ineligible site, only those known reference exclusions with no limitation beyond `binding_not_source` receive an ordinary `unsupported_reference` skip and leave `Incomplete` unchanged. The generic limitation alone never establishes completeness. Dynamic, indeterminate, unsupported-owner, and missing-reference proof remain incomplete. Existing matched proposals and source/target semantics are unchanged.

The known exclusion is classified before condition uncertainty because the name is already outside source mapping. Conditions are still evaluated and attached in full: an irrelevant unknown guard on a proven local definition/derived read does not downgrade selection, but its unknown state and every child evaluation remain visible. The same unknown guard at an eligible source remains `condition_unknown` and incomplete. The pure condition evaluator, linked-member evaluation, probe API, proposal model, request/source order, evidence copying, and coalescing signatures are unchanged.

## TDD, controls and exact-source verification

All evidence is under `task-3-fix-1-evidence/`; each test run has raw `.stdout`, `.stderr`, and `.json` command/tool/environment/source-hash/exit metadata. Nothing in prior evidence was overwritten.

| Evidence | Exit | Result |
| --- | --- | --- |
| `red` | 1 | Corrected original eval-derived expectation fails against blanket incomplete logic. Added proof test also exposes the mistaken assumption that public definition Binding is `definition`. |
| `metadata` | 0 | Real canonical facade/reference probe establishes `create/not_applicable`, `read/derived`, `read/indeterminate`, and a derived reference with `unproved_owner`. Raw data retained. |
| `red-canonical-reference-metadata` | 1 | After correcting only that metadata expectation, both known-exclusion behavior assertions fail for the intended reason: Incomplete=true. |
| `green` | 0 | Known exclusion plus dynamic/indeterminate/unproved-owner/missing-reference controls pass. |
| `red-unknown-guard` | 1 | A known excluded name with an unknown guard still incorrectly sets incomplete due to branch order. |
| `green-unknown-guard` | 0 | Known-exclusion precedence fixed while retaining guard/child uncertainty and eligible-source unknown behavior. |
| `focused-final` | 0 | All Task3 condition/selection tests pass against final source. |
| `package-final` | 0 | Full pkg/rewrite: 253 tests/subtests pass, zero fail/skip, empty stderr. |

Final commands:

```text
/opt/homebrew/bin/go test -mod=readonly ./pkg/rewrite -run 'TestCondition|TestRewriteCondition'
/opt/homebrew/bin/go test -mod=readonly ./pkg/rewrite -json
```

Go tool remains `go1.25.5 darwin/arm64`, `GOCACHE=/private/tmp/spl-toolkit-go-cache`, `GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache`, `GOPROXY=off`, `GOTOOLCHAIN=local`. No untouched baseline or whole-repository test was rerun.

Self-review of the scoped diff confirmed the ordinary-exclusion proof uses canonical metadata only, preserves all uncertainty controls and attached condition evidence, and changes only the two owned files. Precommit `git diff --cached --check` and postcommit `git diff --check HEAD^ HEAD` returned 0. `postcommit.json` records exact parent/path status and verifies both working bytes and committed blobs match final test hashes:

- `pkg/rewrite/conditions.go`: `519311a2576567855f8050d1fb12c55d3ee802b02515bb0814a830b2b243a4c5`
- `pkg/rewrite/conditions_test.go`: `59cf45b734480631a78e24fc00cc68b5b35a7b6e4293b19a54e330481d711ac8`
- `testdata/rewrite/conditions.json`: `9aaa221e3c3ef42caef7f3d5ae6025443d82b88ed970abf716a9100ddb48500f`

## Remaining concerns

No unresolved I1 implementation issue. Independent rereview remains pending; this report does not self-approve that gate or claim later Task4/5 acceptance. The creation-role proof and unknown-guard precedence were relayed to and accepted within scope by the coordinator. All final test results and the corrected private selection summary concern Task3; full public coverage aggregation remains downstream.
