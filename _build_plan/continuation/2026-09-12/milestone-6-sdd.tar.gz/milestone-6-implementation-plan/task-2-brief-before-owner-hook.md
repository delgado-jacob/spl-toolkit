## Task 2: Canonical evidence and rendering for proven forms


Own only the new analysis evidence/facts/render/correspondence files and surgical frontend/kernel/finalizer/capability hooks enumerated above, their focused tests, and durable testdata/rewrite/forms.json. Consume actual typed M5 contexts, field environment/source provenance, source-index conversion, phase and finalization functions. Produce the preflight-approved canonical evidence/render bridge used by pkg/rewrite; it is a narrow per-call edit service, not an independent field engine or public AST. The facade signatures and concrete hooks are recorded above; production still awaits root's exact plan/application/implementation release.

1. Add TestRewriteEvidenceSPL and TestRewriteEvidenceSPL2 that demand exact identity, original render interval, role, binding, scope/flow point, origin IDs, guaranteed literal/reference facts and limitations for ordinary source fields, rename inputs, explicit aliases, lookup input/output distinctions and each of the six nonfield mapping kinds. Test lexical-context negative controls: equal text in comments, string literals, option values and catalog-column labels is not an eligible source field. The tests must initially fail because canonical edit evidence is absent, not because the query corpus is malformed.

2. Attach evidence collection to existing typed frontend lowering and canonical transfer/phase callbacks. Record positive predicate facts from typed comparison/Boolean contexts and their supporting source references; maintain them with the existing environment copies/barriers rather than reconstructing transfer in rewrite. Field redefinition/removal/source reset invalidates affected facts; independent child scopes do not inherit or export parent facts. Source-reference-present is tied to the applicable source identity/flow evidence. Add the narrow typed static literal decoders/encoders in the canonical frontend bridge; normalizedName and spl2DecodeKey are not universal encoders. Unfamiliar scalar forms stay unknown.

3. Add TestRewriteRenderIdentity with quoted identifiers, reserved words, dependencies, static path forms actually proven at preflight, Unicode and punctuation such as a target containing `| eval pwn=1`. Rendering must yield one exact logical identity in the original grammar role or a located target_not_renderable refusal; it never inserts a command. Preserve original quote style when valid and choose minimal correct quoting otherwise. Atom `actor.name` never silently becomes path actor/name. Test both dialects rather than inheriting SPL quoting in SPL2. Add TestLocateRewriteBytes for the new helper: `LocateRewriteBytes("é\r\n😀x", []RewriteByteRange{{4,8},{9,9}})` returns line 2 columns 1–2 for the emoji range and line 2 column 3 at EOF, retaining byte offsets 4/8 and 9/9. Assert tabs, CRLF boundaries, empty text/range arrays, arbitrary ranges without references, zero-width insertion points and all-or-error rejection of invalid UTF-8, mid-rune endpoints, reversed and out-of-bounds ranges.

4. Preserve ordinary public analysis JSON byte values, including M5's already present tstats dependency. Add no duplicate extraction or new rule kind. The optional rewrite capability section is intentionally additive to capabilities only. Reuse finalization so evidence reference IDs align with ordinary reports after nested scopes/SQL phases. Test duplicate SELECT phase observations, implicit output name ownership, wildcard/dynamic refusal and unknown/unsupported contexts. A supported read in an unrelated complete scope may retain evidence even when another scope is incomplete; a damaged original query is not declared eligible for apply.

5. Run `go test -mod=readonly ./pkg/analysis -run 'TestRewriteEvidence|TestRewriteRender|TestLocateRewriteBytes|TestFinalize'` and focused existing SPL/SPL2/validation regressions for touched helpers. No broad new path semantics, parser alternative or schema engine belongs to this task. Commit/review the exact hook change, and record the implemented signatures and immutable commit in this living plan for subsequent implementers.




## Approved canonical interfaces and proven-form boundaries (verbatim plan)

## Canonical bridge, facts and proof ownership


Task 2 creates `pkg/analysis/rewrite_evidence.go`, `rewrite_facts.go`, `rewrite_render_spl.go`, `rewrite_render_spl2.go`, `rewrite_correspondence.go` and focused tests, with small hooks in `analyze.go`, `references.go`, `transfers.go`, `flow.go`, SPL `commands.go`, and SPL2 `spl2_lower.go`, `spl2_commands.go`, `spl2_expressions.go`, `spl2_sql.go`, `spl2_scopes.go`. The coordinate helper/value and private sourceIndex.byteLocation method live together in rewrite_evidence.go; existing source.go behavior and ownership remain unchanged. Capability types/tables live with existing `model.go`, `capabilities.go` and `spl2_capabilities.go`. No new parser generation, independent AST or tstats extraction helper is needed. Analysis cannot import rewrite; rewrite imports analysis.

Implement the approved narrow source-level facade below. These Go helper values are not a replacement public JSON AST. Session/rendering internals are unexported and owned by the call. All exposed collections are copied; IDs are session-local handles, never persistence or cross-query identities.

    func PrepareRewrite(document QueryDocument, probes []RewriteFactProbe) (*RewriteSession, error)
    func (s *RewriteSession) Evidence() RewriteEvidence
    func (s *RewriteSession) Render(changes []RewriteReplacement) (*RewriteRendering, error)
    func (s *RewriteSession) Verify(candidate *RewriteSession, rendered *RewriteRendering) RewriteProof

    type RewriteIdentity struct { Name *string; Path []string }
    type RewriteFactProbe struct { Kind string; Identity RewriteIdentity }
    type RewriteReplacement struct { SiteID string; Target RewriteIdentity }
    type RewriteEvidence struct { Analysis Result; Sites []RewriteSite }
    type RewriteSite struct {
        ID, ReferenceID, BindingID, SourceEpochID string
        Kind, Role, Eligibility string
        Identity RewriteIdentity
        Location, OwnerLocation Location
        Point RewritePoint
        Facts []RewriteFactEvidence
        Limitations []RewriteLimitation
    }
    type RewritePoint struct {
        ScopeID, StageID, Phase string
        LineageIndex, Ordinal int
    }
    type RewriteFactEvidence struct {
        ProbeIndex int
        GuaranteedValues []RewriteScalar
        LiteralComplete bool
        ReferenceState string
        ReferenceIDs []string
        Locations []Location
        Limitations []RewriteLimitation
    }
    type RewriteScalar struct { Kind string; Value json.RawMessage }
    type RewriteLimitation struct { Code, Message string; Location Location }
    type RewriteTextEdit struct { Location Location; Before, After string; SiteIDs []string }
    type RewriteRequirement struct {
        CauseSiteIDs []string
        RequiredChanges []RewriteReplacement
        Limitations []RewriteLimitation
    }
    type RewriteIdentityEffect struct { ReferenceID string; Before, After RewriteIdentity }
    func (r *RewriteRendering) Edits() []RewriteTextEdit
    func (r *RewriteRendering) Requirements() []RewriteRequirement
    func (r *RewriteRendering) Effects() []RewriteIdentityEffect
    type RewriteReferencePair struct { OriginalID, CandidateID string }
    type RewriteProof struct {
        Proven bool
        References []RewriteReferencePair
        Limitations []RewriteLimitation
    }

Root approved the following bounded coordinate clarification after reviewing the complete proposal; it was not part of the original approved preflight's facade. The preflight assigns Unicode/CRLF conversion to sourceIndex, but exposes no converter to pkg/rewrite. At fcbb74ac and unchanged through accepted 40e6e171, `pkg/analysis/source.go` SHA256 is `c0421ed1db6a70c689396801a40d515fa2c887f273571cd704baa9af314c628b` (Git blob `8f1b17b002a5a5cf3af24a23eff0c24ae741afd1`). Its sourceIndex, constructor and position/location methods are private; location accepts rune offsets and clamps them. The package's existing exported API provides no arbitrary-text byte-coordinate service. Passing candidate byte offsets to the rune-indexed method would be incorrect.

    type RewriteByteRange struct { Start, End int }
    func LocateRewriteBytes(text string, ranges []RewriteByteRange) ([]Location, error)

Task 2 places the public helper/value and private sourceIndex.byteLocation method together in rewrite_evidence.go. It validates UTF-8 and every half-open byte range: 0 <= Start <= End <= len(text), with both endpoints exactly on UTF-8 rune boundaries or document EOF. Empty ranges at a valid boundary are allowed; invalid UTF-8, reversed/out-of-bounds ranges and endpoints inside a multibyte rune return an ordinary error and no partial results. Empty ranges input returns an empty nonnil Location slice. Results follow input order. There is no clamping, parsing, normalization, text change, alias/binding inference or semantic evidence creation.

The helper builds the existing newSourceIndex once for the supplied text, then resolves all range endpoints by exact Position.Offset lookup in its already populated positions. Define only a private `func (s *sourceIndex) byteLocation(start, end int) (Location, bool)` in rewrite_evidence.go for that exact lookup, using ordered search of Position.Offset and rejecting missing boundaries. Reuse the existing Position values so Unicode columns, tabs, CRLF and EOF behavior remain canonical. Preserve all existing rune-indexed position/location behavior. This is a batched coordinate utility, not a public SourceIndex/AST or another line/column implementation.

Task 4 keeps candidate construction, nonoverlapping edit validation and cumulative byte-offset translation. Once the final selected edits have produced the exact candidate string, it batches their translated replacement ranges through analysis.LocateRewriteBytes to obtain audit CandidateLocations. This covers arbitrary replacements and zero-width insertions even if no candidate Reference exists. Candidate references, scopes or diagnostics that exist only after analysis remain Task 5/Verify evidence; any needed byte-range conversion uses the same helper/private facility. Coordinates from this utility never establish render/session provenance or semantic proof. Render's approved values and Verify's authority remain unchanged, so there is no duplicate candidate construction or premature parse introduced merely to obtain locations.

PrepareRewrite uses the same canonical Analyze path and retains its own typed owners/source bytes. Attach call-local evidence at existing typed operand/lowering sites and actual `readAt`, `createAt`, `selectorAt`, source reset, clone, assignment, rename, projection, aggregate, lookup and removal transfers. Retain explicit alias boundaries independent of transitive origins. `LineageIndex` is actual execution sequence; `Ordinal` distinguishes multiple reads/transfers within a phase. Missing canonical references use an empty ReferenceID with a real located refusal, never a fabricated reference.

Collect literal guarantees from typed per-dialect search/comparison/Boolean owners before annotating candidate sites in the same predicate. Carry and invalidate them in the actual environment rather than replaying public lineage. Existing expression presence is not equality evidence. Scalar Kind is string/number/boolean/null and Value is one strictly decoded canonical scalar with exact numeric precision. Unknown literal syntax stays unknown. LiteralComplete=false does not erase a separately guaranteed matching value; an unestablished value remains unknown. Conclusive empty guarantees mean false query-fact evidence, never event absence. Every probe gets explicit evidence at every site, including ReferenceState true/false/unknown. Rewrite owns equals/contains and all/any composition, not predicate parsing.

Render consumes simultaneous proposals at original sites. It deterministically encodes original role contexts, composite intervals and already-proven implicit-name changes; it returns edits plus required linked consumer changes. It does not authorize those changes, resolve rule winners or cascade identities. The rewrite layer independently checks each required site's original-point condition and withholds a group if any member fails. Composite/implicit references can have normalization Effects even when their whole semantic location is not a standalone editable token. Rendering is pure over original session state; mutation of copied evidence or a rendering from another session cannot create proof.

Verify first checks candidate document language/profile/version/source_id and original rendering/session provenance. It uses canonical candidate analysis, translated typed ownership and selected edits to compare intended identities, direct binding relationships, mapped origins, transition operations/inputs/outputs/conditionality and actual SQL phases. It neither reparses independently nor promises runtime equivalence. Remap all sidecar StageIDs at `spl2FinalizeStages` and reference/fact/implicit IDs at `finalizeReferences`; equal spans or equal ref-N values are insufficient. Translate every affected reference/owner/scope/diagnostic endpoint, including enclosing references and zero-width lookup AS insertion. SELECT preparation creates one physical reference/read owner; final project supplies a later transition using that reference. Unknown evidence is compared by translated ownership and effect, never diagnostic counts. Task 5 may complete a specifically scoped reviewed correspondence follow-up in analysis; adapters never own proof.

## Proven forms and explicit refusal boundary


SPL exact source reads/selectors, rename inputs and exact removals can map only with a selected source binding and typed identifier encoding. Explicit eval/rename/SQL/lookup outputs and downstream explicit aliases remain fixed. Wildcard selectors, dynamic names and creation-only or unavailable/indeterminate bindings do not become source mappings merely because names match. Null inspection keeps `null_test`: a source-bound exact operand can render, but unknown/unavailable null inspection never materializes a source field or proves event presence.

SPL2 exact bare or quoted field atoms use direct FieldName.Identifier without navigation. `'actor.name'` is an atom. Unresolved AccessPart navigation and alias-qualified joins remain located refusals; do not rewrite a source-looking root while the enclosing whole identity is unproved. Dotted resolver ambiguity remains governed by the existing typed source policy. Literal punctuation is assessed by role: an actual wildcard selector remains refused even quoted, while an exact quoted expression atom can render if its frontend proves encoding. Meaningful whitespace, keyword and punctuation targets are logical data, never raw query fragments.

Index/source/sourcetype mappings target typed dependency values, not same-spelled event fields. Search values, metric predicate values, SQL fields and quoted Boolean/string literals retain their own grammar categories. M5's `metricsPredicate` recognizes only an intact command-owned bare-index equality; BY/aggregate fields remain fields, wildcard/dynamic selectors stay refused. Dependency discovery through OR/NOT is not positive equality evidence. Interpolation, held signed/punctuation spellings or uncertain literal decoding never receive false definite render/fact credit.

Lookup catalog names are independent of columns. Explicit local match aliases can follow a proven source identity. An unaliased remote/local dual-purpose input must preserve the remote column and insert a documented AS local target only when canonical correspondence proves it; otherwise refuse it. Lookup outputs stay explicit derived names. Without explicit outputs, M5's possible remote overwrite makes affected aliases conditional; M6 must not infer linked consumer safety across that uncertainty.

Named external datasets can render independently of source aliases, including typed UNION/join dependency intentions only when local edit and final correspondence are independently proved; none of these tokens establishes a parent merge. Literal-row keys are derived field definitions. SPL datamodel/dataset composites retain their exact component owner and prefix/quotes: `datamodel Model Dataset` normalizes Model.Dataset across a Dataset-only interval, and qualified FROM/tstats references may overlap. Co-render compatible component edits and their normalization Effects; refuse conflict or unproved backslash forms instead of writing a full normalized name into a component interval.

For SPL2 tstats, consume `metricsInputs`' existing atomic data_model reference/dependency. It includes the entire quoted token, e.g. `'Traffic.All'`; never split model/dataset/path or duplicate extraction. Preserve canonical expectations for `C28-P2`, `L22-P1`, `E.C28.datamodel_name.P1/P2`, and invalid N1/N2 plus held mstats boundaries. Add only the private render owner and rewrite positive/held/dynamic/damaged cases. Recognition does not waive affected-effects/group/postverification proof. `search_job` is not an accepted Rule.Kind. Deferred field output intentions are not editable source permissions.

SPL's implicit aggregate label is frontend-owned and can require an atomic input/consumer group: `search index=main | stats sum(bytes) | table 'sum(bytes)'` with bytes→octets must become `search index=main | stats sum(octets) | table 'sum(octets)'`, or retain the whole group if proof fails. Never add a synthetic AS. SPL2's accepted implicit labels remain narrow (`count()`, `sum(bytes)`, `dc(action)`); mapping bytes to octets in `FROM main | stats sum(bytes) | table 'sum(bytes)'` cannot establish the changed label or indeterminate consumer and must withhold the whole group. Explicit AS outputs stay fixed. Direct unaliased SQL field projection is passthrough, not a synthetic name. Do not broaden implicit naming simply because SELECT now proves a finite output set or isolated count presence.

The original syntax-error gate applies before edits even where M5 recovery retains an intact typed operand. Comments, strings, object-key definitions, option labels, function names, source aliases and unmodeled named arguments are not inferred source sites. Add private naming owners at real SPL/SPL2 aggregate and SELECT creation only; preserve M5 assignment, deferred-effect, incomplete-wildcard and SQL collision/conditionality guards.

## Additive rewrite capabilities


Add `Rewrite *RewriteCapabilityManifest` with JSON key `rewrite,omitempty` to analysis.CapabilityManifest. Task 2 owns the canonical implemented role/form table; Task 8 completes documentation/corpus correspondence. Use this compact approved shape:

    type RewriteCapabilityManifest struct {
        SchemaVersion int `json:"schema_version"`
        Forms []RewriteCapabilityForm `json:"forms"`
    }
    type RewriteCapabilityForm struct {
        Kind string `json:"kind"`
        Role string `json:"role"`
        IdentityForms []string `json:"identity_forms"`
        Supported bool `json:"supported"`
        Limitations []string `json:"limitations"`
    }

Role is a stable documented rendering context fine-grained enough to distinguish exact expression atoms, selector atoms, null inspections, lookup local operands, dependency-value slots, composite catalog components and implicit consumers from refused navigation/wildcard/dynamic forms. It is not merely canonical read/create or a generated ANTLR type. Populate both selected dialect manifests from implemented renderer eligibility; preserve all existing default values, order, documentation_snapshot and copied nested slices. Intentionally additive capability JSON differs as a whole; ordinary Analyze reports stay unchanged. Text capabilities and OpenAPI expose the same optional addition without changing selector APIs or claiming universal seven-kind support.


## Binding behavioral constraints (verbatim approved plan)

Only Milestone 6 is in scope. Preserve existing fixed-SPL mapper methods, configuration precedence and old native signatures. Do not change source files in place, perform whole-query conversion, beautify queries, rewrite wildcards/dynamic identifiers, infer raw-to-data-model/tstats changes, learn rules, execute searches or claim equivalent runtime results. Report output explicitly requested by a CLI caller is the only filesystem write performed by the operation.

Select language spl or spl2 explicitly through the existing canonical QueryDocument, with omitted language defaulting to spl, profile splunkd and version current. Normalize/reject options through the accepted canonical selector boundary. Maintain source text and source identity byte-for-byte, half-open UTF-8 byte offsets, Unicode columns, CRLF semantics, copied public values, deterministic IDs and array ordering. Unknown options and malformed Unicode remain request errors.

Conditions use only original, guaranteed source/flow facts. AND combines compatible guarantees, OR intersects guarantees, and query NOT establishes no positive equality. Later facts cannot authorize earlier edits; independent child queries never establish parent facts. Source-reference-present is a static query-reference fact, never event presence. The new rule language contains all/any, proven literal equals/string contains and source-reference-present, without regex, arbitrary code, condition-language NOT or caller-injected facts.

Canonical frontends own typed contexts, identity interpretation and render eligibility. Canonical transfer owns bindings, alias/implicit-output origins, inherited environments, unknown barriers, SQL logical phases and source universes. Rewrite must neither discover these by substring/regex/token guesses nor replay their transfer algorithms. The selected M6 rewrite bridge below is new implementation work; existing M5 helpers named below are real at the accepted fixed source. Final M5 closure at 237e62ac preserves those source identities; any later actual relevant change must be reconciled before it is used.

Atom/path rule identities remain distinct. On 2026-09-08 root confirmed that M6 adds only minimal fact/render/implicit-name hooks for already proven forms; do not expand canonical path binding just to force a mapping or schema match. Use the reconciled proven-form inventory below; every navigated or alias-qualified form that lacks canonical binding proof remains a located refusal.

Apply has one whole-request post-verification gate. Existing unrelated semantic incompleteness may remain without a requested target if every edited group is proven. Requested destination validation must produce a valid, complete report; invalid or incomplete validation prevents commit. An unknown/ambiguous group may remain unchanged alongside independently committed safe groups, yielding incomplete with committed true. This never permits an edit to depend on a skipped edit for safety.


## Accepted predecessor and execution boundaries

M5 now extracts tstats DATAMODEL_NAME in `pkg/analysis/spl2_commands.go:561` (`metricsInputs`), as one `data_model` atom including its whole quoted token. The four prior positive corpus forms already contain that canonical reference; damaged N1/N2 forms do not. M6 needs private rendering ownership only, not another dependency helper or changes to ordinary Analyze JSON. `search_job` is a nonconsuming external-job reference, outside the seven mapping kinds. Deferred output references and named UNION/join dependencies do not establish output fields, source bindings or rewrite permission.

`prepareSQLSelection` now returns `([]preparedSelection, map[string]bool, bool)`. The final Boolean proves finite selected membership separately from conditional field presence. An origin crossing an incomplete wildcard expansion keeps that finite proof false. An intact noncolliding zero-argument count can have independent presence proof, without upgrading sibling semantics. `sqlProjectionCollisionName` may inspect a static alias-qualified suffix for collision purposes only; it cannot authorize a suffix/root source binding. M6 must preserve these distinctions when tracking implicit ownership and postverification.

Original typed recovery records and original delimiter checks became stricter in `spl2_parse.go`, `spl2_recovery.go` and `spl2_scopes.go`. Some intact original operands survive local parser damage; all original document diagnostics remain. M6's original-syntax-error gate still refuses edits for the document. It must not generalize the predecessor's narrow local retry into token reconstruction or a new parser.


The accepted correction in `pkg/analysis/spl2_functions.go`, SHA256 `d7576fde248da9e134dfbf3a79297abcf9783d77fff660378592630359ff57b7`, assigns len a numeric return domain and split an unknown scalar domain. Canonical analysis can now prove the numeric composition abs(len("abc")) when its existing argument/presence guards hold. Split is still modeled, but its multivalue output supplies no scalar-string proof to lower/len or another scalar consumer. Invalid/null/source-dependent arguments and unknown, named or wrong-arity functions retain existing uncertainty; valid modeled analysis may still have conditional field presence. M6 consumes these canonical results without inventing new literal facts or rewrite permissions. The corrected module suffix/declaration sites in `pkg/analysis/spl2_syntax.go`, SHA256 `8438f5174b3a930f80425d71c316bb1c6cdacab304b450af042766a5c4a7d46c`, use unsupported_syntax while preserving SPL_UNSUPPORTED_MODULE, messages, severity, locations and false syntax coverage. The four changed test files cover nested domains, conservative controls, validation presence and both module locations. All six source/test hashes match the supplied fix report.



Task2 is now released from reviewed Task1 head `3a29058949b5b0000e4b90d9406764dbe11ce2ee`. Task1 is complete after independent combined review and scoped I1 fix/rereview. This exact commit is Task2 BASE; its eight new rewrite contract/fixture files are accepted. Work only in the existing /Users/jacobdelgado/repos/spl-toolkit/.worktrees/remaining-milestones worktree. Analysis must not import pkg/rewrite. Task1 strict request/model preparation is consumed by later rewrite tasks and does not authorize a second type/flow engine here.

Own the new analysis evidence/facts/render/correspondence files and focused tests listed above, testdata/rewrite/forms.json, and only the enumerated small canonical hooks/capability types. Keep the approved coordinate helper/value/private byteLocation together in rewrite_evidence.go; source.go is read-only. M5 already owns atomic tstats extraction. Preserve other source/API behavior; no duplicate extraction or new proof from search_job/output intentions. If a concrete necessary ownership gap arises, send the specific evidence to the coordinator before touching that path.

Read current global AGENTS and efficient-delegation, use TDD and verification-before-completion. You are not alone; preserve every other edit, root aggregate/private oracles, coordinator plan/ledger, M5 evidence/history, and user original checkout. No subagents or self-dispatched reviewers. Do not read the whole plan or unrelated milestone SDD directories. Root already approved design/preflights/coordinates; read accepted canonical source as needed to implement, without repeating predecessor baseline tests or reopening settled architecture.

Use GOCACHE=/private/tmp/spl-toolkit-go-cache, GOMODCACHE=/private/tmp/spl-toolkit-remaining-gomodcache, GOPROXY=off, GOTOOLCHAIN=local. Capture focused RED/GREEN, then appropriate affected analysis/validation/rewrite package checks with actual tool/source identities and raw stdout/stderr/observed exits. No network/dependency/toolchain changes or shared build-all for orientation. Root held M5 artifacts are already preserved for later intentional replacement; no shared builds are needed in this task.

Root authorizes exact-owned-file commits. Use require_escalated for authorized exact-path git add/commit because .git is read-only in the default sandbox; do not repeat the known index-lock denial. No add -A/reset/stash/clean/merge/push/publication/deletion. Self-review and commit only owned paths. Write complete task-2-report.md with implementation, changed files, TDD/raw evidence, all failures/warnings, immutable commit and concerns; return concise status/commits/tests/concerns/report path. No parent-owned independent oracle access.

Task1 downstream note: strict request/condition/target normalization is in pkg/rewrite, using original canonical analysis/validation types; analysis must not import it. CandidateValidation retains complete Go reports while its field-list JSON projects only target metadata under root's approved I1 ruling. Task5 owns later semantic target compilation. These contracts require no analysis-side redesign.
