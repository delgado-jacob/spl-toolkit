package main
import("encoding/json";"os";"github.com/delgado-jacob/spl-toolkit/pkg/analysis")
func main(){ for _,q:=range []string{"search src=x | table *","search src=x | mystery | table src","search src=x | append [ search other=x | mystery ]","search src=x | append [ search other=x ] | table src","search src=x | fields - src | mystery"} {s,e:=analysis.PrepareRewrite(analysis.QueryDocument{Text:q},nil);if e!=nil{panic(e)};json.NewEncoder(os.Stdout).Encode(s.Evidence())} }
