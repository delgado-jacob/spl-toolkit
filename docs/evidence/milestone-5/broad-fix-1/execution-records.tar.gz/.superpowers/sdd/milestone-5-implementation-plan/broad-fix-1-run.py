import hashlib
import json
import os
import shutil
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
LOGS = Path(__file__).with_name('broad-fix-1-logs')


def snapshot():
    paths = set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')) - {''}
    for directory in ('_build_plan', 'testdata', 'tests', 'tools', 'docs', 'build', 'dist'):
        paths.update(str(p.relative_to(ROOT)) for p in (ROOT / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    paths.add('CLAUDE.md')
    paths.update(str(p.relative_to(ROOT)) for p in (ROOT / 'python').rglob('*') if p.is_file() and p.suffix in ('.dylib', '.so', '.h'))
    paths.update(str(p.relative_to(ROOT)) for p in Path(__file__).parent.glob('*') if p.is_file() and p.suffix in ('.md', '.py'))
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in sorted(paths) if (ROOT / p).is_file()}


def external_snapshot(argv, env):
    env = env.copy()
    if argv and Path(argv[0]).name == 'env':
        for value in argv[1:]:
            if '=' not in value:
                break
            key, value = value.split('=', 1)
            env[key] = value
    paths = {Path(v) for v in argv if Path(v).is_file()}
    paths.update(Path(v) for k, v in env.items() if k.startswith(('SPL_', 'PIP_')) and Path(v).is_file())
    paths.update(p for p in Path('/private/tmp/spl-toolkit-m5-broad-fix-1').glob('*') if p.is_file())
    paths.update(p for p in Path('/private/tmp/spl-toolkit-offline-wheelhouse').glob('*') if p.is_file())
    for name in ('go', 'clang', 'git'):
        executable = shutil.which(name, path=env.get('PATH'))
        if executable:
            paths.add(Path(executable).resolve())
    paths.update(Path(p) for p in ('/Users/jacobdelgado/.codex/AGENTS.md', '/Users/jacobdelgado/.codex/skills/efficient-delegation/SKILL.md', '/private/tmp/spl-toolkit-m5-final-go-transport.json', '/private/tmp/spl-toolkit-m5-broad-fix-1-release.json'))
    return {str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths) if p.is_file()}


name, *argv = sys.argv[1:]
env = os.environ.copy()
env.update(GOCACHE='/private/tmp/spl-toolkit-go-cache', GOMODCACHE='/private/tmp/spl-toolkit-remaining-gomodcache',
           GOPROXY='off', GOTOOLCHAIN='local', PIP_CACHE_DIR='/private/tmp/spl-toolkit-pip-cache')
record = {'argv': argv, 'cwd': str(ROOT), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
          'environment': {k:v for k,v in env.items() if k.startswith(('SPL_', 'PIP_', 'GO', 'PYTHON')) or k in ('PATH', 'JAVA_HOME')},
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'runner_source': Path(__file__).read_text(), 'before': snapshot(), 'external_before': external_snapshot(argv, env)}
destination = LOGS / (name + '.json')
if destination.exists():
    raise RuntimeError('refusing to overwrite evidence ' + str(destination))
destination.write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
with (LOGS / (name + '.log')).open('w') as output:
    result = subprocess.run(argv, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, text=True)
record.update(exit=result.returncode, elapsed_seconds=time.monotonic()-start, after=snapshot(), external_after=external_snapshot(argv, env))
record['changed_inputs'] = [p for p in sorted(record['before'].keys() | record['after'].keys()) if record['before'].get(p) != record['after'].get(p)]
record['external_delta'] = [p for p in sorted(record['external_before'].keys() | record['external_after'].keys()) if record['external_before'].get(p) != record['external_after'].get(p)]
destination.write_text(json.dumps(record, indent=2) + '\n')
print((LOGS / (name + '.log')).read_text())
sys.exit(result.returncode)
