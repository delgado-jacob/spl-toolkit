import hashlib, importlib.metadata, json, platform, subprocess, sys
from pathlib import Path
root=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commands=[['go','version'],['/private/tmp/spl-toolkit-floor-tools/gomodcache/golang.org/toolchain@v0.0.1-go1.22.12.darwin-arm64/bin/go','version'],['clang','--version'],['go','version','-m','build/spl-toolkit'],['go','version','-m','build/spl-toolkit-server'],['go','version','-m','build/libspl_toolkit.dylib']]
out={'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'packages':{n:importlib.metadata.version(n) for n in ['pip','setuptools','wheel','build','packaging','pyproject-hooks','pytest','pytest-mock','PyYAML']},'commands':[]}
for argv in commands:
 r=subprocess.run(argv,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);out['commands'].append({'argv':argv,'exit':r.returncode,'output':r.stdout});assert r.returncode==0
paths=list((root/'build').glob('*'))+list((root/'dist').glob('*'))+[root/'python/spl_toolkit/libspl_toolkit.h',Path(sys.executable).resolve(),Path('/private/tmp/spl-toolkit-remaining-tools/antlr-4.13.2-complete.jar')]
out['artifacts']={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths if p.is_file()}
out['wheelhouse']={p.name:sha(p) for p in sorted(Path('/private/tmp/spl-toolkit-offline-wheelhouse').glob('*.whl'))}
out['owned_source_hashes']={p:sha(root/p) for p in ['pkg/analysis/spl2_functions.go','pkg/analysis/spl2_functions_test.go','pkg/analysis/spl2_parse_test.go','pkg/analysis/spl2_recovery_test.go','pkg/analysis/spl2_syntax.go','pkg/validation/spl2_test.go']}
subprocess.run(['git','diff','--check'],check=True)
formatted=subprocess.check_output(['gofmt','-l',*out['owned_source_hashes']],text=True);assert not formatted,formatted
baseline=json.loads((root/'.superpowers/sdd/milestone-5-implementation-plan/broad-fix-1-logs/baseline.json').read_text())
allowed=set(out['owned_source_hashes'])
protected={p:h for p,h in baseline['files'].items() if p not in allowed and not p.startswith(('build/','dist/')) and p!='.superpowers/sdd/milestone-5-implementation-plan/broad-fix-1-run.py'}
assert all((root/p).is_file() and sha(root/p)==h for p,h in protected.items()),'protected input changed'
out['protected_continuity']=protected
out['historical_task11_report_sha256']=sha(root/'.superpowers/sdd/milestone-5-implementation-plan/task-11-report.md')
out['source_transport_sha256']=sha(Path('/private/tmp/spl-toolkit-m5-broad-fix-1/go-transport.json'))
package=json.loads(Path('/private/tmp/spl-toolkit-m5-broad-fix-1/package-evidence.json').read_text())
for kind,v in [('wheel',package),('rebuilt_sdist',package['rebuilt_sdist'])]:
    assert v['fixture_hashes']['spl2_go_transport']==out['source_transport_sha256']
    assert v['tests']['required_native']=={'collected':322,'failed':0,'passed':322,'skipped':0}
    assert v['tests']['surface_acceptance']=={'collected':102,'failed':0,'passed':102,'skipped':0}
    assert v['native_sha256']==v['wheel_payload_hashes']['spl_toolkit/libspl_toolkit.dylib']
out['installed']={kind:{k:v[k] for k in ('tests','native_sha256','wheel_sha256','source_header_sha256','python_version','python_runtime','required_test_files','fixture_hashes','wheel_payload_hashes','version_agreement')} for kind,v in [('wheel',package),('rebuilt_sdist',package['rebuilt_sdist'])]}
destination=root/'.superpowers/sdd/milestone-5-implementation-plan/broad-fix-1-logs/final-tool-artifact-identities.json';assert not destination.exists();destination.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'artifact_count':len(out['artifacts']),'packages':out['packages'],'python':out['python'],'platform':out['platform']}))
