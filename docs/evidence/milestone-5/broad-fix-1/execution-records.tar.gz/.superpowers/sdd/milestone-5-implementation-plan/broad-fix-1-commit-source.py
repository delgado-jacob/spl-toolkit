from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();logs=root/'.superpowers/sdd/milestone-5-implementation-plan/broad-fix-1-logs'
identities=json.loads((logs/'final-tool-artifact-identities.json').read_text());owned=identities['owned_source_hashes']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in owned.items())
subprocess.run(['git','add','--',*owned],check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines();assert set(staged)==set(owned)
subprocess.run(['git','commit','-m','fix(spl2): correct function result domains and module category'],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert all(hashlib.sha256(subprocess.check_output(['git','show',head+':'+p])).hexdigest()==h for p,h in owned.items())
receipt={'commit':head,'parent':subprocess.check_output(['git','rev-parse','HEAD^'],text=True).strip(),'owned_source_hashes':owned,'staged_paths':staged,'checked_source_identity':True,'runtime_checkout_head':identities['head'],'binding':'all checked modified blobs equal this exact-owned source commit; runtime/build receipts retain their actual fcbb dirty-tree HEAD'}
with (logs/'source-commit.json').open('x') as out:json.dump(receipt,out,indent=2);out.write('\n')
print(head)
