from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

ROOT=Path.cwd();SDD=ROOT/'.superpowers/sdd/milestone-5-implementation-plan';LOGS=SDD/'broad-fix-1-logs';DATA=Path('/private/tmp/spl-toolkit-m5-broad-fix-1');DEST=ROOT/'docs/evidence/milestone-5/broad-fix-1'
DEST.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((LOGS/'final-tool-artifact-identities.json').read_text())
commit=json.loads((LOGS/'source-commit.json').read_text())
delta=json.loads((DATA/'corpus-delta.json').read_text())
authority=json.loads((DATA/'category-authority-freeze.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==commit['commit']
assert not subprocess.check_output(['git','diff','--name-only'],text=True).strip()
for p,h in identity['owned_source_hashes'].items():
    assert sha(ROOT/p)==h
    assert hashlib.sha256(subprocess.check_output(['git','show',commit['commit']+':'+p])).hexdigest()==h
for p,h in identity['protected_continuity'].items():assert sha(ROOT/p)==h
checks=[]
for p in sorted(LOGS.glob('[0-9][0-9]-*.json')):
    r=json.loads(p.read_text());name=p.stem
    expected=1 if name.startswith(('01-','02-','04-')) else 0
    assert r['exit']==expected,(name,r['exit'])
    if 8<=int(name[:2])<=16:
        for k,h in identity['owned_source_hashes'].items():assert r['before'][k]==r['after'][k]==h
    checks.append({'name':name,'argv':r['argv'],'actual_checkout_head':r['head'],'exit':r['exit'],'expected_exit':expected,'elapsed_seconds':r['elapsed_seconds'],'checked_repository_inputs':len(r['before']),'repository_delta':r['changed_inputs'],'external_delta':r.get('external_delta',[]),'receipt_sha256':sha(p),'raw_log_sha256':sha(p.with_suffix('.log'))})
for name in ('category-authority-freeze.json','corpus-delta.json','historical-artifacts.json'):(DEST/name).write_bytes((DATA/name).read_bytes())
for source,name in [('go-transport.json','go-transport.json.gz'),('category-amended-transport-expectation.json','category-amended-transport-expectation.json.gz'),('source-spl2-evidence.json','source-spl2.json.gz'),('source-schema-evidence.json','source-schema.json.gz'),('package-evidence.json','package.json.gz')]:
    (DEST/name).write_bytes(gzip.compress((DATA/source).read_bytes(),mtime=0))
archive_inputs=list(sorted(LOGS.glob('*')))+list(sorted(SDD.glob('broad-fix-1-*.py')))+[SDD/'broad-fix-1-brief.md']
archive_manifest={str(p.relative_to(ROOT)):sha(p) for p in archive_inputs if p.is_file()}
with tarfile.open(DEST/'execution-records.tar.gz','w:gz') as archive:
    for p in archive_inputs:
        if p.is_file():archive.add(p,arcname=str(p.relative_to(ROOT)))
artifacts={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(DEST.iterdir())}
old_verification=json.loads((ROOT/'docs/evidence/milestone-5/verification.json').read_text())
record={'schema_version':1,'kind':'milestone-5-broad-fix-1-qualified-verification','base_commit':commit['parent'],'implementation_commit':commit['commit'],'assignment':'Explicit gpt-6-astra/xhigh/worker/fork-none; no role model override; creation-setting evidence, not backend attestation; no child delegation','scope':['M5-BR-01: known numeric len result; split does not claim scalar string domain','M5-BR-02: module declaration/suffix diagnostic category unsupported_syntax'],'source_identity':commit,'checks':checks,'corpus':old_verification['corpus'],'corpus_delta':delta,'category_authority':authority,'tool_and_artifact_identities':identity,'evidence_artifacts':artifacts,'execution_archive_manifest':archive_manifest,'reused_checks':{'basis':'All listed existing relevant inputs are unchanged under the complete protected_continuity map. Reused historical checks are not claimed as fresh runtime execution on the fix. The controller approved affected-only verification.','antlr_generation':{'historical':'Task11 final-spl2-generation; same grammar, generated parser, pinned JAR, generation helper, tool identity and dependencies'},'openapi_generation':{'historical':'Task11 final-openapi; API/public report types, generator, output documents, dependencies unchanged'},'tooling':{'historical':'Task11 final-tooling-complete; tools and their tests, fixtures, packaging helpers/configuration unchanged'},'docs':{'historical':'Task11 final-docs; maintained Markdown, documented examples, checker unchanged; executable documented CLI examples rerun in source/installed acceptance'}},'qualifications':['Runtime checks/builds retain actual fcbb HEAD with released dirty source; every final checked source/test blob equals the implementation commit. Evidence-only commit does not change those inputs.','Source Python uses absolute SPL_NATIVE_LIBRARY. Installed runs use packaged SPLMapper() outside checkout with copied fixtures; both generated/copied Go artifacts equal final transport hash.','Go transport and category-amended prior full reports are transport/regression evidence with zero conformance credit. All original compact canonical fixtures and normative assertions are unchanged.','Existing tools/check_package.py:540 tarfile Python 3.14 DeprecationWarning recurred; check passed.','Default sandbox blocked git index.lock before source staging (git exit128, wrapper exit1); same explicitly authorized exact-path commit succeeded with escalation. This was an environment limitation, not a product/test failure.','Early focused checks retain repository/test/helper source maps and per-check runner source; later expanded checks also bind external transport/helpers/tool binaries/wheelhouse/native inputs. Category authority and expected report hashes were frozen before fixed capture.','fcbb Task11/root/broad artifacts and six historical build/package payload bytes remain preserved; historical archive identity is recorded without reclassifying the old two findings.'],'remaining_gates':['Same broad reviewer scoped fix review','Root independent reacceptance on the final held candidate/builds, including its own amended category control and Python 3.14 scope as root directs','Controller-owned authored documentation closure and later platform/successor gates remain outside this worker fix'],'unclaimed':['Private root oracles were not read or run','No push, merge, cleanup, grammar/parser/shared-transfer/ABI expansion or broad unchanged-suite rerun']}
(DEST/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
summary=f'''# Milestone 5 broad fix 1

The scoped correction is committed as `{commit['commit']}` above `{commit['parent']}`. `len` now carries numeric result evidence; `split` retains supported presence but does not claim a scalar-string result. The two module exclusion sites now emit `SPL_UNSUPPORTED_MODULE` with category `unsupported_syntax`.

The exact nested-len failure and the module-category failures were reproduced before their fixes. The 17 focused analysis queries and six field-list/JSON-Schema validation compositions preserve source reads, nullability, unknown/named/arity boundaries, and the distinction between conditional presence and analysis completeness.

All 1,714 compact canonical cases passed without fixture changes: 732 independent expectations and 982 separately reviewed snapshots remain unchanged. Full reports differ from the prior accepted transport only at five pre-authorized category leaves, B08–B12. The other 1,709 reports, including nine len/split text candidates, are identical. Full reports provide no additional conformance credit.

Fresh verification passed Go 1.22 analysis/validation tests, current-Go vet/race for those packages, native/CLI/server builds, 339 source Python tests, and 78 source acceptance tests. Both the offline-built wheel and rebuilt sdist passed 322 native and 102 acceptance tests with zero skips, copied fixtures outside the checkout, and the packaged library. The existing tarfile Python 3.14 deprecation warning remains qualified.

[verification.json](verification.json) contains exact commands, exits, source/fixture/artifact/tool hashes, checked-input maps, continuity for reused generation/OpenAPI/tooling/docs checks, and open review/root gates. [corpus-delta.json](corpus-delta.json) and [category-authority-freeze.json](category-authority-freeze.json) bind the pre-capture category amendment. Compressed reports preserve complete transport/source/installed evidence; `execution-records.tar.gz` preserves RED/GREEN raw logs, per-check runner source, and source-commit binding. Historical Task11 evidence is unchanged.

Build/test receipts retain their actual `fcbb74a` dirty-tree HEAD. Their final source blobs equal the implementation commit exactly. Scoped review and root reacceptance are still required; this record does not claim them.
'''
(DEST/'README.md').write_text(summary)
print(json.dumps({'implementation_commit':commit['commit'],'files':len(list(DEST.iterdir())),'protected_unchanged':len(identity['protected_continuity']),'archive_inputs':len(archive_manifest),'verification_sha256':sha(DEST/'verification.json')}))
