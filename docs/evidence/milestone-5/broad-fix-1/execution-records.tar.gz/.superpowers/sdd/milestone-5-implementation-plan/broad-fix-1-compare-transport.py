from pathlib import Path
import hashlib
import json
import sys
ROOT = Path(__file__).resolve().parents[3]
DEST = Path('/private/tmp/spl-toolkit-m5-broad-fix-1')
sys.path.insert(0, str(ROOT/'tests/acceptance'))
from spl2_transport import load_transport

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
oldpath=Path('/private/tmp/spl-toolkit-m5-final-go-transport.json')
expectedpath=DEST/'category-amended-transport-expectation.json'
actualpath=DEST/'go-transport.json'
authority=json.loads((DEST/'category-authority-freeze.json').read_text())
assert digest(expectedpath)==authority['expected_transport_sha256']
actual,_=load_transport(actualpath,ROOT/'testdata/spl2',digest(actualpath),ROOT)
old=json.loads(oldpath.read_text());expected=json.loads(expectedpath.read_text())
assert actual['fixture_hashes']==old['fixture_hashes']
assert len(actual['reports'])==len(expected['reports'])==1714
assert [r['id'] for r in actual['reports']]==[r['id'] for r in expected['reports']]
failures=[a['id'] for a,e in zip(actual['reports'],expected['reports']) if a!=e]
changed=[a['id'] for a,o in zip(actual['reports'],old['reports']) if a!=o]
record={'old_transport_sha256':digest(oldpath),'category_authority_sha256':digest(DEST/'category-authority-freeze.json'),'expected_transport_sha256':digest(expectedpath),'actual_transport_sha256':digest(actualpath),'actual_bytes':actualpath.stat().st_size,'helper_sha256':digest(Path(__file__)),'records':1714,'changed_ids':changed,'unexpected_report_changes':failures,'unchanged_reports':1714-len(changed),'fixture_hashes_unchanged':True,'len_split_text_candidates_unchanged':all(e['id'] not in changed for e in authority['len_split_text_candidates']),'source_hash_changes':{p:{'before':old['source_hashes'].get(p),'after':v} for p,v in actual['source_hashes'].items() if old['source_hashes'].get(p)!=v}}
with (DEST/'corpus-delta.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record,indent=2))
assert not failures
assert changed==[entry['id'] for entry in authority['changes']]
