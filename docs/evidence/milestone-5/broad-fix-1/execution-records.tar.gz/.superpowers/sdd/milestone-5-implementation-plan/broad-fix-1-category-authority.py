"""Version only the root-approved category leaves in prior transport evidence."""
from pathlib import Path
import copy
import hashlib
import json
import re
ROOT = Path(__file__).resolve().parents[3]
DEST = Path('/private/tmp/spl-toolkit-m5-broad-fix-1')
oldpath = Path('/private/tmp/spl-toolkit-m5-final-go-transport.json')
def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()
def object_hash(value):
    return digest_bytes(json.dumps(value,sort_keys=True,separators=(',',':')).encode())
assert digest_bytes(oldpath.read_bytes()) == '053f87af1a35e1c2caa375f783668e44794114df045168ef1e5aa05ec956ce86'
old = json.loads(oldpath.read_text())
expected = copy.deepcopy(old)
changes = []
function_candidates = []
for entry in expected['reports']:
    if re.search(r'\b(?:len|split)\s*\(', entry['document']['text']):
        function_candidates.append({'id':entry['id'],'text':entry['document']['text']})
    before = object_hash(entry)
    leaves = []
    for i, diagnostic in enumerate(entry['report']['diagnostics']):
        if diagnostic['code'] == 'SPL_UNSUPPORTED_MODULE':
            assert diagnostic['category'] == 'unsupported'
            leaves.append({'path':f'/report/diagnostics/{i}/category','before':'unsupported','after':'unsupported_syntax','location':diagnostic['location']})
            diagnostic['category'] = 'unsupported_syntax'
    if leaves:
        changes.append({'id':entry['id'],'old_entry_sha256':before,'expected_entry_sha256':object_hash(entry),'leaves':leaves})
expectedpath = DEST/'category-amended-transport-expectation.json'
with expectedpath.open('x') as stream:
    json.dump(expected,stream,sort_keys=True,separators=(',',':'));stream.write('\n')
receipt = {'kind':'source-derived category-only transport amendment; zero conformance credit','basis':'root-approved M5-BR-02 and design-spec.md:77, SPL_UNSUPPORTED_MODULE category unsupported_syntax; all prior reviewed report values otherwise unchanged','old_transport_sha256':digest_bytes(oldpath.read_bytes()),'expected_transport_sha256':digest_bytes(expectedpath.read_bytes()),'source_contract_sha256':digest_bytes((ROOT/'_build_plan/milestones/5-standalone-spl2/design-spec.md').read_bytes()),'helper_sha256':digest_bytes(Path(__file__).read_bytes()),'records':len(expected['reports']),'changed_ids':len(changes),'changed_leaves':sum(len(c['leaves']) for c in changes),'changes':changes,'len_split_text_candidates':function_candidates,'fixture_hashes':old['fixture_hashes']}
with (DEST/'category-authority-freeze.json').open('x') as stream:
    json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({k:receipt[k] for k in ('records','changed_ids','changed_leaves','expected_transport_sha256')}))
print('len/split text candidates:',len(function_candidates))
