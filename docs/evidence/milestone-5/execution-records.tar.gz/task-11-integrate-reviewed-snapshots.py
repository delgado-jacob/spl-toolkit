"""Integrate reviewed regression representations without changing authority."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
LOGS = Path(__file__).with_name('task-11-logs')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest = lambda v: hashlib.sha256(json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
prior_path = Path('/private/tmp/spl-toolkit-m5-task11-capture-5.json')
current_path = Path('/private/tmp/spl-toolkit-m5-task11-capture-6.json')
prior, current = (json.loads(p.read_text()) for p in (prior_path, current_path))
assert sha(prior_path) == '62e1cbd9af3d4d22d9626eca2230861b6b4812d27913acbff504cf5b318714d8'
assert len(current) == 982 and current == prior
run = json.loads((LOGS / 'frozen-snapshot-capture-6.json').read_text())
freeze = json.loads((LOGS / 'normative-batch-6-freeze.json').read_text())
assert run['exit'] == 0 and run['before'] == run['after'] == freeze['checked_inputs']
manifest_path = ROOT / 'testdata/spl2/manifest.json'
manifest = json.loads(manifest_path.read_text())
assert manifest['enforce_final_floors'] is False
documents = {f: json.loads((ROOT / 'testdata/spl2' / f).read_text()) for f in manifest['case_files']}
cases = {c['id']: c for rows in documents.values() for c in rows}
assert {k for k, c in cases.items() if c.get('canonical_evidence') == 'regression_snapshot'} == set(current)
receipt = {'head': run['head'], 'capture5_sha256': sha(prior_path), 'capture6_sha256': sha(current_path),
           'capture6_exit': 0, 'freeze6_sha256': sha(LOGS / 'normative-batch-6-freeze.json'),
           'full_report_equality_to_independently_reviewed_capture5': 982, 'changed_reports': 0,
           'independent_exact_pass': 732, 'snapshot_predicates_pass': 982,
           'files_before': {f: sha(ROOT / 'testdata/spl2' / f) for f in manifest['case_files'] + ['manifest.json']},
           'records': {}}
for case_id, captured in current.items():
    case = cases[case_id]
    assert 'canonical' not in case and case['canonical_assertions']
    before = copy.deepcopy(case)
    case['canonical'] = captured['canonical']
    assert {k: v for k, v in case.items() if k != 'canonical'} == before
    receipt['records'][case_id] = {'authority_record_before_sha256': digest(before), 'canonical_sha256': digest(case['canonical']), 'integrated_record_sha256': digest(case)}
assert len(cases) == 1714 and all(c.get('canonical') for c in cases.values())
for f, rows in documents.items():
    (ROOT / 'testdata/spl2' / f).write_text(json.dumps(rows, indent=2, ensure_ascii=False) + '\n')
manifest['enforce_final_floors'] = True
manifest['evidence_layers']['canonical'] = 'Independently exact full canonical objects or explicitly labelled deterministic regression snapshots with independently frozen, executable semantic assertions; original syntax and provenance remain separate.'
manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
receipt.update(files_after={f: sha(ROOT / 'testdata/spl2' / f) for f in manifest['case_files'] + ['manifest.json']},
               script_sha256=sha(__file__), enforce_final_floors=True, original_records=1714,
               independent_exact=732, regression_snapshots=982, supplemental_independent_assertions=38)
out = LOGS / 'capture6-canonical-integration-receipt.json'
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'receipt_sha256': sha(out), 'capture6_sha256': sha(current_path), 'canonical_total': 1714,
                  'independent_exact': 732, 'regression_snapshots': 982, 'equal_reviewed_reports': 982}))
