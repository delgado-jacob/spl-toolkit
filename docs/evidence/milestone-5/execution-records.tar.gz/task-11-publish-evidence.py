import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path.cwd()
SDD = ROOT / '.superpowers/sdd/milestone-5-implementation-plan'
LOGS = SDD / 'task-11-logs'
DEST = ROOT / 'docs/evidence/milestone-5'
DEST.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
file_sha = lambda path: sha(path.read_bytes())
load = lambda path: json.loads(path.read_text())
commit = load(LOGS / 'implementation-commit-identity.json')
package_path = Path('/private/tmp/spl-toolkit-m5-package-evidence.json')
package = load(package_path)
corpus = load(LOGS / 'final-corpus-audit.json')
assert corpus['exit'] == 0
counts = json.loads((LOGS / 'final-corpus-audit.log').read_text().strip())
artifacts = {}
for name, source in {
    'go-transport.json.gz': Path('/private/tmp/spl-toolkit-m5-final-go-transport.json'),
    'source-spl2.json.gz': Path('/private/tmp/spl-toolkit-m5-source-spl2-evidence.json'),
    'source-schema.json.gz': Path('/private/tmp/spl-toolkit-m5-source-schema-evidence.json'),
    'package.json.gz': package_path,
    'conformance-capture6.json.gz': Path('/private/tmp/spl-toolkit-m5-task11-capture-6.json'),
    'conformance-authority6.json.gz': Path('/private/tmp/spl-toolkit-m5-task11-normative-combined-6.json'),
}.items():
    raw = source.read_bytes()
    encoded = gzip.compress(raw, compresslevel=9, mtime=0)
    assert gzip.decompress(encoded) == raw
    (DEST / name).write_bytes(encoded)
    artifacts[name] = {'sha256': sha(encoded), 'bytes': len(encoded), 'uncompressed_sha256': sha(raw), 'uncompressed_bytes': len(raw), 'original_path': str(source)}

checks = []
for receipt in sorted(LOGS.glob('*.json')):
    data = load(receipt)
    if not isinstance(data, dict) or not {'argv', 'before', 'after', 'exit'} <= data.keys():
        continue
    delta = {k: {'before': data['before'].get(k), 'after': data['after'].get(k)} for k in data['before'].keys() | data['after'].keys() if data['before'].get(k) != data['after'].get(k)}
    checks.append({'name': receipt.stem, 'argv': data['argv'], 'exit': data['exit'], 'elapsed_seconds': data.get('elapsed_seconds'), 'checkout_head': data['head'], 'receipt_sha256': file_sha(receipt), 'raw_log_sha256': file_sha(receipt.with_suffix('.log')), 'checked_inputs': len(data['before']), 'input_delta': delta})

# Preserve original unsuccessful attempts and their actual input hashes without
# rewriting history. The archive is evidence, not an executable dependency.
archive_files = sorted(p for p in LOGS.iterdir() if p.is_file())
archive_files += sorted(p for p in SDD.glob('task-11*.py') if p.is_file())
archive_files += [SDD / 'task-11-report.md']
stream = io.BytesIO()
with tarfile.open(fileobj=stream, mode='w') as archive:
    for path in archive_files:
        info = tarfile.TarInfo(str(path.relative_to(SDD)))
        raw = path.read_bytes()
        info.size, info.mtime, info.mode = len(raw), 0, 0o644
        archive.addfile(info, io.BytesIO(raw))
encoded = gzip.compress(stream.getvalue(), compresslevel=9, mtime=0)
(DEST / 'execution-records.tar.gz').write_bytes(encoded)
artifacts['execution-records.tar.gz'] = {'sha256': sha(encoded), 'bytes': len(encoded), 'files': len(archive_files), 'content_hashes': {str(p.relative_to(SDD)): file_sha(p) for p in archive_files}}

final_package_check = load(LOGS / 'final-package-check.json')
assert final_package_check['exit'] == 0 and final_package_check['before'] == final_package_check['after']
for data in (package, package['rebuilt_sdist']):
    assert data['tests']['required_native'] == {'collected':322,'passed':322,'failed':0,'skipped':0}
    assert data['tests']['surface_acceptance'] == {'collected':102,'passed':102,'failed':0,'skipped':0}
    assert len(data['spl2_surface_evidence']['corpus']) == 1714
    assert data['fixture_hashes']['spl2_go_transport'] == artifacts['go-transport.json.gz']['uncompressed_sha256']
    assert all(file_sha(ROOT/p) == digest for p,digest in data['documentation_hashes'].items())

identities = load(LOGS / 'final-tool-artifact-identities.json')
for path, identity in identities['artifacts'].items():
    assert file_sha(Path(path)) == identity['sha256']
summary = {
    'schema_version': 1, 'kind': 'milestone-5-task-11-local-verification',
    'implementation_commit': commit['implementation_commit'],
    'base_commit': commit['parent'],
    'verification_binding': 'Checks ran on the recorded base HEAD plus owned changes. Committed blobs equal their preserved working-tree hashes; the later evidence-only commit changes no executable, fixture, test, package or maintained guide input.',
    'owned_source_hashes': commit['owned_hashes'],
    'postcheck_test_only_change': 'Removed one trailing blank line in tools/tests/test_spl2_corpus.py after191 passing tooling tests to satisfy git diff --check. Both actual test versions remain in retained check/precommit hashes. No test logic changed.',
    'documentation_projection_sha256': '3345cf5712b1bdbf467d1651784fdb8bccc596805038da0d54e7a123384e3a4e',
    'corpus': counts | {'independent_with_supplemental_assertions':38, 'enforce_final_floors':True},
    'postintegration_canonical_execution': {'go_floor_analysis':'passed', 'full_go_race_analysis':'passed', 'independent_exact':732, 'independently_constrained_snapshots':982, 'canonical_documents':1714, 'snapshot_capture6_equals_independently_reviewed_capture5':True},
    'source_tests': {'tooling':191, 'python':339, 'documented_cli_schema_spl2_surfaces':78, 'required_skips':0},
    'installed': {label:{k:data[k] for k in ('python_version','python_runtime','installed_module','venv_prefix','loaded_library','native_sha256','wheel_sha256','source_header_sha256','wheel_payload_hashes','fixture_hashes','documentation_hashes','tests','required_test_files')} for label,data in [('wheel',package),('rebuilt_sdist',package['rebuilt_sdist'])]},
    'tool_and_artifact_identities':identities,
    'last_runtime_check_inputs':final_package_check['after'],
    'checks':checks,
    'evidence_artifacts':artifacts,
    'qualifications':[
        'Initial final Go1.22 API scope failed before assertions on sandbox loopback bind; only that scope was retried successfully with authorized loopback. Other five scopes retain their successful original execution.',
        'Go1.22 external linking is the verified floor path. Historical default-link LC_UUID failure was not rerun or claimed passing.',
        'Full race passed with the inherited LC_DYSYMTAB linker warning. OpenAPI emitted its existing root-package/no-Type/recursion generator notices and changed zero bytes.',
        'Installed checks passed with the preexisting Python3.14 tar-extraction deprecation warning; these environments actually ran Python3.12.6.',
        'Tool binary and wheelhouse identities were inspected after checks; earlier command/tool-version and locked dependency evidence is preserved, not reconstructed as a prior external-cache content hash.',
        'Runtime binaries were built before the implementation commit; embedded VCS metadata and full actual build inputs are retained, with committed-source byte equivalence independently checked.'
    ],
    'remaining_gates':['fresh independent immutable Task11 review','root final built/native/real-HTTP/installed/Python3.14 acceptance','broad read-only milestone review','root final milestone acceptance and controller authored-doc closure'],
    'unclaimed':['Linux/Windows or full Python release matrix','external Splunk execution/certification','new release, merge or push'],
    'handoff':{'data_model':'M6 consumes the M5 atomic tstats data_model dependency for its private render owner; do not duplicate extraction.', 'intentions':'search_job and output intention tokens alone are not rewrite permission or new mapping rule kinds.'}
}
(DEST / 'verification.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n')
print(json.dumps({'implementation_commit':commit['implementation_commit'],'checks':len(checks),'archive_files':len(archive_files),'compressed_bytes':sum(x['bytes'] for x in artifacts.values()),'verification_sha256':file_sha(DEST/'verification.json')}))
