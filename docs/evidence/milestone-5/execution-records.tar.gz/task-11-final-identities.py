import hashlib, importlib.metadata, json, platform, subprocess, sys
from pathlib import Path
root=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commands=[['go','version'],['/private/tmp/spl-toolkit-floor-tools/gomodcache/golang.org/toolchain@v0.0.1-go1.22.12.darwin-arm64/bin/go','version'],['clang','--version'],['java','-version'],['go','version','-m','build/spl-toolkit'],['go','version','-m','build/spl-toolkit-server'],['go','version','-m','build/libspl_toolkit.dylib']]
out={'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'machine':platform.machine(),'packages':{n:importlib.metadata.version(n) for n in ['pip','setuptools','wheel','build','packaging','pyproject-hooks','pytest','pytest-mock','PyYAML']},'commands':[]}
for argv in commands:
 r=subprocess.run(argv,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);out['commands'].append({'argv':argv,'exit':r.returncode,'output':r.stdout});assert r.returncode==0
paths=list((root/'build').glob('*'))+list((root/'dist').glob('*'))+[root/'python/spl_toolkit/libspl_toolkit.h',Path(sys.executable).resolve(),Path('/private/tmp/spl-toolkit-remaining-tools/antlr-4.13.2-complete.jar')]
out['artifacts']={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths if p.is_file()}
out['wheelhouse']={p.name:sha(p) for p in sorted(Path('/private/tmp/spl-toolkit-offline-wheelhouse').glob('*.whl'))}
destination=root/'.superpowers/sdd/milestone-5-implementation-plan/task-11-logs/final-tool-artifact-identities.json';assert not destination.exists();destination.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'artifact_count':len(out['artifacts']),'packages':out['packages'],'python':out['python'],'platform':out['platform']}))
