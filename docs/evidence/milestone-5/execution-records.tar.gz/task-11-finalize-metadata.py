import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
LOGS = Path(__file__).with_name('task-11-logs')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest = lambda v: hashlib.sha256(json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
authority = Path('/private/tmp/spl-toolkit-m5-xhigh-capture4-review/lexical-deferred/exact24-canonical-basis-replacements-v1.json')
assert sha(authority) == '795a97626ce2ddc2451f4b14f242d0876a90fcc8e7035879247704856d14d772'
replacement = json.loads(authority.read_text())
files = json.loads((ROOT / 'testdata/spl2/manifest.json').read_text())['case_files']
documents = {f: json.loads((ROOT / 'testdata/spl2' / f).read_text()) for f in files}
cases = {c['id']: c for rows in documents.values() for c in rows}
receipt = {'authority': str(authority), 'authority_sha256': sha(authority), 'changes': {}, 'files_before': {f: sha(ROOT / 'testdata/spl2' / f) for f in files}}
for case_id, update in replacement['replacements_by_id'].items():
    assert set(update) == {'canonical_basis'}
    case = cases[case_id]
    before = copy.deepcopy(case)
    check = replacement['per_id_preservation_checks'][case_id]
    assert case['document'] == check['document'] and digest(case) == check['inventory_record_before_sha256']
    assert digest(case['canonical']) == check['unchanged_independent_canonical_sha256']
    case.update(update)
    assert digest(case) == check['proposed_record_after_sha256']
    assert {k: v for k, v in case.items() if k != 'canonical_basis'} == {k: v for k, v in before.items() if k != 'canonical_basis'}
    receipt['changes'][case_id] = {'before': before, 'after': case}
assert len(receipt['changes']) == 24
stale = json.loads((LOGS / 'stale-basis-inventory-before.json').read_text())['observed_string']
assert not any(c.get('canonical_basis') == stale for c in cases.values())
for f, rows in documents.items():
    (ROOT / 'testdata/spl2' / f).write_text(json.dumps(rows, indent=2, ensure_ascii=False) + '\n')
receipt.update(files_after={f: sha(ROOT / 'testdata/spl2' / f) for f in files}, nonprose_authority_equal=True, stale_string_remaining=0, script_sha256=sha(__file__))
out = LOGS / 'capture4-exact24-metadata-correction-receipt.json'
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'changes': 24, 'stale_string_remaining': 0, 'receipt_sha256': sha(out)}))
