"""Required SPL2-only generation, pinned tools, two equal rounds."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
LOGS = Path(__file__).with_name('task-11-logs')
jar = Path('/private/tmp/spl-toolkit-remaining-tools/antlr-4.13.2-complete.jar')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(jar) == 'eae2dfa119a64327444672aff63e9ec35a20180dc5b8090b7a6ab85125df4d76'
version = subprocess.check_output(['java', '-version'], stderr=subprocess.STDOUT, text=True)
assert 'version "21.' in version
def generated():
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted((ROOT / 'parser/spl2').iterdir()) if p.is_file()}
before = generated()
commands = []
rounds = []
for _ in range(2):
    for grammar in ('SPL2Lexer.g4', 'SPL2Parser.g4'):
        argv = ['java', '-jar', str(jar), '-Dlanguage=Go', '-package', 'spl2', '-visitor', '-listener', '-Xexact-output-dir']
        if grammar == 'SPL2Parser.g4':
            argv += ['-lib', 'parser/spl2']
        argv += ['-o', 'parser/spl2', 'grammar/' + grammar]
        commands.append(argv)
        subprocess.run(argv, cwd=ROOT, check=True)
    rounds.append(generated())
record = {'java': version, 'jar': str(jar), 'jar_sha256': sha(jar), 'commands': commands,
          'before': before, 'rounds': rounds, 'deterministic': rounds[0] == rounds[1],
          'generated_inputs_unchanged': before == rounds[1]}
destination = LOGS / 'spl2-generation-identities.json'
assert not destination.exists()
destination.write_text(json.dumps(record, indent=2) + '\n')
assert record['deterministic'] and record['generated_inputs_unchanged'], record
print(json.dumps({'generated_files': len(before), 'deterministic': True, 'unchanged': True, 'receipt_sha256': sha(destination)}))
