"""Apply only controller-approved metadata and one scoped assertion supplement."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
LOGS = Path(__file__).with_name('task-11-logs')
SHA = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
metadata_path = Path('/private/tmp/spl-toolkit-m5-xhigh-capture4-review/lexical-deferred/metadata-finding-v1.json')
scope_path = Path('/private/tmp/spl-toolkit-m5-xhigh-capture4-review/pipeline-extended/T5.boundary.049-strengthening-v1.json')
assert SHA(metadata_path) == 'f0e99af74d9eac03790b00f84242371cd37ef75e8173d51984a2dfa4a02619b8'
assert SHA(scope_path) == '9c9adb689cb2619b198f84a62651cb9a4a21d19fbc7bf6f1c794ab16bc1a7bce'
metadata = json.loads(metadata_path.read_text())
supplement = json.loads(scope_path.read_text())
files = json.loads((ROOT / 'testdata/spl2/manifest.json').read_text())['case_files']
documents = {f: json.loads((ROOT / 'testdata/spl2' / f).read_text()) for f in files}
cases = {c['id']: c for rows in documents.values() for c in rows}
before = copy.deepcopy(cases)
receipt = {'approved_by': '/root/milestone5_xhigh', 'authorities': {str(p): SHA(p) for p in (metadata_path, scope_path)},
           'files_before': {f: SHA(ROOT / 'testdata/spl2' / f) for f in files}, 'changes': {}}
same = {k for k, c in cases.items() if c.get('canonical_basis') == metadata['observed_string']}
assert set(metadata['affected_ids']) <= same
receipt['stale_string_extra_ids_held'] = sorted(same - set(metadata['affected_ids']))
for case_id in metadata['affected_ids']:
    case = cases[case_id]
    basis = case['canonical_assertions']['basis']
    assert hashlib.sha256(json.dumps(basis, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest() == metadata['per_id_frozen_basis_sha256'][case_id]
    case['canonical_basis'] = basis
    assert {k: v for k, v in case.items() if k != 'canonical_basis'} == {k: v for k, v in before[case_id].items() if k != 'canonical_basis'}
for case_id, update in supplement.items():
    assert case_id == 'T5.boundary.049'
    old = before[case_id]['canonical_assertions']
    new = update['canonical_assertions']
    for key in ('status', 'syntax_complete', 'semantic_complete', 'required_codes', 'forbidden_codes', 'forbidden_references', 'required_fields', 'forbidden_field_names', 'final_state'):
        assert old[key] == new[key], key
    cases[case_id].update(update)
for case_id, case in cases.items():
    if case != before[case_id]:
        receipt['changes'][case_id] = {'before': before[case_id], 'after': case}
assert len(receipt['changes']) == 256
for f, rows in documents.items():
    (ROOT / 'testdata/spl2' / f).write_text(json.dumps(rows, indent=2, ensure_ascii=False) + '\n')
receipt['files_after'] = {f: SHA(ROOT / 'testdata/spl2' / f) for f in files}
receipt['nonprose_authority_equal_for_metadata_ids'] = True
receipt['script_sha256'] = SHA(__file__)
destination = LOGS / 'capture4-metadata-and-scope-correction-receipt.json'
assert not destination.exists()
destination.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'changes': len(receipt['changes']), 'held_extra_ids': receipt['stale_string_extra_ids_held'], 'receipt': str(destination), 'sha256': SHA(destination)}))
