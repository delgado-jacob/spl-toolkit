"""Freeze all semantic authority and executable inputs before capture5."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
LOGS = Path(__file__).with_name('task-11-logs')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
runner = Path(__file__).with_name('task-11-run.py')
namespace = {'__file__': str(runner)}
exec(runner.read_text().split('\nname, *argv')[0], namespace)
files = json.loads((ROOT / 'testdata/spl2/manifest.json').read_text())['case_files']
cases = [c for f in files for c in json.loads((ROOT / 'testdata/spl2' / f).read_text())]
assert len(cases) == len({c['id'] for c in cases}) == 1714
counts = {'original_cases': len(cases),
          'independent_exact': sum('canonical' in c and c.get('canonical_evidence', 'independent') == 'independent' for c in cases),
          'snapshot_authorities': sum(c.get('canonical_evidence') == 'regression_snapshot' for c in cases),
          'independent_supplemental_assertions': sum(c.get('canonical_evidence') == 'independent' and 'canonical_assertions' in c for c in cases)}
assert counts == {'original_cases': 1714, 'independent_exact': 732, 'snapshot_authorities': 982, 'independent_supplemental_assertions': 38}
assert all('canonical_assertions' in c and 'canonical' not in c for c in cases if c.get('canonical_evidence') == 'regression_snapshot')
authority = {c['id']: {k: v for k, v in c.items() if k.startswith('canonical')} for c in cases}
combined = Path('/private/tmp/spl-toolkit-m5-task11-normative-combined-5.json')
assert not combined.exists()
combined.write_text(json.dumps(authority, indent=2, ensure_ascii=False) + '\n')
checked = namespace['snapshot']()
archive = LOGS / 'capture5-analysis-inputs.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as out:
    for name in checked:
        if name.startswith(('pkg/analysis/', 'parser/', 'grammar/', 'testdata/', 'tests/acceptance/', 'tools/')) or name in ('go.mod', 'go.sum'):
            out.add(ROOT / name, arcname=name, recursive=False)
record = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'counts': counts,
          'checked_inputs': checked, 'checked_inputs_sha256': hashlib.sha256(json.dumps(checked, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
          'combined_authority': str(combined), 'combined_sha256': sha(combined), 'archive_sha256': sha(archive),
          'schema_sha256': sha('/private/tmp/spl-toolkit-m5-task11-normative-schema.json'),
          'versioned_correction_receipts': {str(p.relative_to(ROOT)): sha(p) for p in sorted(LOGS.glob('*correction-receipt.json'))},
          'prior_freeze_sha256': sha(LOGS / 'normative-batch-4-freeze.json')}
destination = LOGS / 'normative-batch-5-freeze.json'
assert not destination.exists()
destination.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'counts': counts, 'freeze_sha256': sha(destination), 'combined_sha256': sha(combined),
                  'checked_inputs_sha256': record['checked_inputs_sha256'], 'archive_sha256': sha(archive)}))
