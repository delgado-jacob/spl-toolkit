import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
LOGS = Path(__file__).with_name('task-11-logs')


def snapshot():
    paths = set(subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')) - {''}
    for directory in ('_build_plan', 'testdata', 'tests', 'tools', 'docs', 'build', 'dist'):
        paths.update(str(p.relative_to(ROOT)) for p in (ROOT / directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    paths.add('CLAUDE.md')
    paths.update(str(p.relative_to(ROOT)) for p in Path(__file__).parent.glob('*') if p.is_file() and p.suffix in ('.md', '.py'))
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in sorted(paths) if (ROOT / p).is_file()}


name, *argv = sys.argv[1:]
env = os.environ.copy()
env.update(GOCACHE='/private/tmp/spl-toolkit-go-cache', GOMODCACHE='/private/tmp/spl-toolkit-remaining-gomodcache',
           GOPROXY='off', GOTOOLCHAIN='local', PIP_CACHE_DIR='/private/tmp/spl-toolkit-pip-cache')
record = {'argv': argv, 'cwd': str(ROOT), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
          'environment': {k:v for k,v in env.items() if k.startswith(('SPL_', 'PIP_', 'GO', 'PYTHON')) or k in ('PATH', 'JAVA_HOME')},
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'before': snapshot()}
destination = LOGS / (name + '.json')
if destination.exists():
    raise RuntimeError('refusing to overwrite evidence ' + str(destination))
destination.write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
with (LOGS / (name + '.log')).open('w') as output:
    result = subprocess.run(argv, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, text=True)
record.update(exit=result.returncode, elapsed_seconds=time.monotonic()-start, after=snapshot())
destination.write_text(json.dumps(record, indent=2) + '\n')
print((LOGS / (name + '.log')).read_text())
sys.exit(result.returncode)
