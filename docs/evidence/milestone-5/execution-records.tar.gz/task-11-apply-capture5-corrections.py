import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
LOGS = Path(__file__).with_name('task-11-logs')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = Path('/private/tmp/spl-toolkit-m5-xhigh-capture5-review/two-record-corrections-v1/assertion-replacements.json')
assert sha(source) == 'd30db8810704410c953869b0bdd16e732282963c1656de8323870cf748d1ec39'
replacements = json.loads(source.read_text())
assert set(replacements) == {'E.L16.alias.P2', 'I.literal.P2'}
files = json.loads((ROOT / 'testdata/spl2/manifest.json').read_text())['case_files']
documents = {f: json.loads((ROOT / 'testdata/spl2' / f).read_text()) for f in files}
cases = {c['id']: c for rows in documents.values() for c in rows}
receipt = {'authority': str(source), 'authority_sha256': sha(source), 'changes': {}, 'files_before': {f: sha(ROOT / 'testdata/spl2' / f) for f in files}}
for case_id, update in replacements.items():
    before = copy.deepcopy(cases[case_id])
    old_assertion = copy.deepcopy(before['canonical_assertions'])
    new_assertion = copy.deepcopy(update['canonical_assertions'])
    assert old_assertion['final_state']['uncertain'] is True and new_assertion['final_state']['uncertain'] is False
    old_assertion.pop('basis')
    new_assertion.pop('basis')
    old_assertion['final_state']['uncertain'] = False
    assert old_assertion == new_assertion
    assert set(update) == {'canonical_evidence', 'canonical_assertions'} and update['canonical_evidence'] == before['canonical_evidence']
    cases[case_id].update(update)
    receipt['changes'][case_id] = {'before': before, 'after': cases[case_id]}
for f, rows in documents.items():
    (ROOT / 'testdata/spl2' / f).write_text(json.dumps(rows, indent=2, ensure_ascii=False) + '\n')
receipt.update(files_after={f: sha(ROOT / 'testdata/spl2' / f) for f in files}, script_sha256=sha(__file__))
out = LOGS / 'capture5-two-record-authority-correction-receipt.json'
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'changes': 2, 'receipt_sha256': sha(out)}))
